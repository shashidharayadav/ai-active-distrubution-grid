# GRIDMIND AI ⚡
### AI-Powered Active Distribution Grid Monitoring & Electricity Demand Prediction System

> **Hackathon Theme:** AI-Driven Active Distribution Grid  
> **Interface:** Modern, High-Performance Dark Theme Operations Console & Public Presentation Portal

---

## 📖 Project Overview

**GRIDMIND AI** is a state-of-the-art frontend application developed for modern electric distribution network operators (DSOs) and smart grid engineers. It solves the critical challenge of blind-spot operation in 11kV distribution networks by fusing real-time SCADA telemetry with **Random Forest Regression** demand forecasting.

By providing multi-horizon lookahead predictions (30 mins, 1 hour, 2 hours, 24 hours), transformer thermal degradation tracking, and automated tie-feeder load balancing advisories, GRIDMIND AI helps prevent blackouts, reduces transformer hot-spot damage, and eliminates costly peak tariff spikes.

---

## 🎨 Global UI/UX Color System

The application strictly adheres to the unified Smart Energy + AI palette:

| Element | Color Name | Hex Code | Purpose |
| :--- | :--- | :--- | :--- |
| **Main Background** | Midnight Navy | `#101C2C` | Base application canvas |
| **Sidebar** | Deep Slate Navy | `#152538` | Persistent control navigation |
| **Main Cards** | Blue Slate | `#1D3045` | Primary containers & metrics widgets |
| **Secondary Surfaces** | Soft Slate | `#263B50` | Input controls, hover surfaces, table headers |
| **Primary Accent** | Modern Teal | `#20A99E` | Primary actions, actual telemetry, active states |
| **Secondary Accent** | Emerald Green | `#35C99A` | Normal badges, frequency stability, optimal health |
| **AI Highlights** | Soft Violet | `#9585F5` | Random Forest curves, AI predictions, confidence intervals |
| **Primary Text** | Off White | `#F8FAFC` | High-contrast readable headings & values |
| **Secondary Text** | Cool Grey | `#A9B8C8` | Labels, axis units, captions |
| **Borders** | Muted Blue Grey | `#34495E` | Clean structural dividing borders |
| **Warning** | Warm Amber | `#F5B942` | ≥80% transformer loading, cautionary alarms |
| **Critical Alerts** | Coral Red | `#F16F75` | ≥90% trip thresholds, active feeder trips |

---

## 🚀 Key Features by Page

### 1. Direct Login Flow (`/login` & `/`)
- **Default Entry View**: Visitors land on the Login screen before accessing the operations console.
- **Form Controls**: Email, Password, Show/Hide password toggle, "Remember console" option, and simulated password recovery modal.
- **Hackathon Quick Demo**: 1-Click buttons for **Lead Dispatcher** and **Substation Engineer** for instant presentation login.

### 2. Registration (`/register`)
- Full operator onboarding with role selection (*Grid Dispatcher, Substation Engineer, Utility Analyst, System Admin*), email validation, and credential creation.

### 3. Public Presentation Landing Page (`/landing`)
- **Hero Banner**: Highlighting the hackathon theme, real-time telemetry metrics, and primary CTAs.
- **Operational Pipeline (4 Stages)**:
  1. *Edge Telemetry Ingestion* (smart meters, RTUs, IEC 61850 protocol)
  2. *Grid State Synchronization* (filtering, bus voltage regulation)
  3. *Random Forest Regression* (multi-horizon predictive ML)
  4. *Automated Dispatch Advisory* (BESS battery discharge, tap changers)
- **Model Accuracy Showcase**: $R^2 = 0.978$, $\text{RMSE} = 28.4\text{ kW}$, $\text{MAE} = 19.8\text{ kW}$.
- **Quantifiable Impact**: -38% unplanned outages, +22% transformer life extension, 97.8% peak forecast accuracy.

### 4. Operations Dashboard (`/dashboard`)
- **6 Key Telemetry Cards**:
  - Current Electricity Consumption (kW)
  - Predicted Electricity Demand (+30m with AI badge)
  - Active Transformers (18/18 Online)
  - Active Feeders (24/24 Operational)
  - Grid Health Score (98.4% Optimal)
  - Active Incident Queue (3 Warnings, 0 Critical)
- **Interactive Visualizations**:
  - 24-Hour Electricity Consumption Curve with seasonal baseline.
  - Current vs Predicted Demand Comparison with 95% confidence bands.
  - Transformer Loading Capacity Bar Chart with 80% warning and 90% critical trip lines.
- **Feeds**: Recent priority alerts queue with immediate acknowledgement actions, SCADA event logs, and quick navigation shortcuts.

### 5. Grid Monitoring & Topology (`/grid-monitoring`)
- Multi-bus primary voltage readings (11.04 kV) across 6 primary substations with deviation metrics.
- 3-Phase current balance (Phase A, B, C) and phase unbalance ratio (1.2%).
- **Interactive Distribution Grid Topology**: Clickable nodes (*Substations $\rightarrow$ Feeders $\rightarrow$ Transformers $\rightarrow$ Localities*) to inspect live telemetry.
- Real-time telemetry fluctuation simulation toggle.

### 6. Electricity Consumption Analytics (`/consumption`)
- Breakdown across 6 distribution localities (*Tech Park, Industrial Estate, Commercial Center, Residential Valley, Transit Depot, Healthcare City*).
- Locality consumption donut chart with center capacity readout.
- **Historical SCADA Records Table**: Filter by locality, search by ID, peak/off-peak indicators, and **one-click CSV dataset export**.

### 7. AI Demand Prediction (Random Forest) (`/demand-prediction`)
- **Random Forest Regression Focus**: Multi-horizon selector (**30 Mins**, **1 Hour**, **2 Hours**, **6 Hours**, **24 Hours**).
- **Interactive "What-If" Demand Sandbox**: Sliders for *Ambient Temperature (°C)*, *Industrial Activity Index (%)*, and *Solar PV Infeed Offset (%)* that dynamically recalculate the predicted load in real time on the UI.
- Gini feature importance breakdown (24h load lags, dry-bulb temperature, diurnal cycle, solar offset).
- Battery Energy Storage System (BESS) automated dispatch recommendation.

### 8. Transformer Fleet Thermal Monitoring (`/transformers`)
- Fleet roster with capacity (kVA), active load, loading percentage, winding hotspot temp, oil temp, and cooling fan states.
- Color-coded warning indicators when loading exceeds 80% (amber) or 90% (coral red).
- **SCADA Asset Inspector Modal**: Dissolved Gas Analysis (DGA: $\text{H}_2$, $\text{CH}_4$, $\text{CO}$) and nameplate technical parameters.

### 9. Feeder Operations & Load Balancing (`/feeders`)
- Roster of 8 distribution feeders (FDR-01 through FDR-08) with line currents, voltages, and power factors.
- **Interactive Vacuum Circuit Breaker Control**: Toggle breaker state (*CLOSED / OPEN*) with safety confirmation modals.
- Overcurrent (50/51) and Earth Fault (51N) protective relay monitoring.

### 10. Alerts & Incident Queue (`/alerts`)
- Categorized alarms with severity badges: Critical (`#F16F75`), Warning (`#F5B942`), and Informational (`#9585F5`).
- **Interactive Workflows**: "Acknowledge" and "Resolve Incident" buttons update in-memory state with dispatcher stamps.
- Status filters (*All, Active Unacknowledged, Acknowledged, Resolved*) and text search.

### 11. Reports & Analytical Intelligence (`/reports`)
- Comprehensive reports for *Electricity Consumption*, *AI Demand Accuracy*, *Transformer Thermal Loading*, and *Feeder Losses*.
- Evaluation table comparing actual vs forecasted load with absolute residual error.
- **Export Capabilities**: Client-side CSV file download and **Print / PDF Preview Modal** with certified SCADA documentation.

### 12. Settings & Operational Thresholds (`/settings`)
- Configurable transformer warning & critical trip thresholds.
- Voltage tolerance (±%) and frequency tolerance (±Hz).
- Random Forest forecast horizons, confidence interval settings, and SCADA telemetry refresh rates.

---

## 🛠️ Technology Stack

- **Frontend Core:** React 19, TypeScript, Vite
- **Styling Engine:** Tailwind CSS v4 with custom CSS variables
- **Charts:** Recharts
- **Icons:** Lucide React
- **Routing:** React Router DOM v7

---

## 💻 Getting Started

### Prerequisites
- Node.js (v18 or higher, tested on v24.21.0)
- npm or yarn

### Installation
```bash
# 1. Clone or navigate to the project directory
cd "gridmind frontened"

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

The application will be running locally at:
👉 **`http://localhost:5173/`**

### Production Build
```bash
# Compile TypeScript and generate optimized production bundle
npm run build

# Preview production build locally
npm run preview
```

---

## 🔑 Demo Access Credentials

| Role | Email | Password | Or Use |
| :--- | :--- | :--- | :--- |
| **Lead Dispatcher** | `dispatcher@gridmind.ai` | `DemoPass2026!` | 1-Click "Lead Dispatcher" Button |
| **Substation Engineer** | `engineer@gridmind.ai` | `DemoPass2026!` | 1-Click "Substation Engineer" Button |

---

## 🔮 Future Backend & AI Integration Roadmap

The frontend is organized cleanly with separate mock files in `src/data/mockData.ts` and strongly typed interfaces in `src/types/index.ts`:

- **FastAPI Backend Integration**: Direct replacement of mock data functions with async `fetch()` or `axios` API calls.
- **Live WebSocket SCADA Telemetry**: Connect `GridMonitoring.tsx` and `Dashboard.tsx` to a WebSocket feed emitting 500ms RTU packets.
- **Live Scikit-Learn Model Serving**: Connect `DemandPrediction.tsx` to a Python FastAPI endpoint serving `RandomForestRegressor.predict()`.
