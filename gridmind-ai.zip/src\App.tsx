import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AlertsProvider } from './context/AlertsContext';
import { AppLayout } from './components/layout/AppLayout';

// Pages
import { LandingLoginPage } from './pages/LandingLoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { Dashboard } from './pages/Dashboard';
import { GridMonitoring } from './pages/GridMonitoring';
import { Consumption } from './pages/Consumption';
import { DemandPrediction } from './pages/DemandPrediction';
import { Transformers } from './pages/Transformers';
import { Feeders } from './pages/Feeders';
import { EnergyBalance } from './pages/EnergyBalance';
import { SurplusManagement } from './pages/SurplusManagement';
import { BessMonitoring } from './pages/BessMonitoring';
import { WhatIfSimulator } from './pages/WhatIfSimulator';
import { Alerts } from './pages/Alerts';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';

// Root route handler: Displays the integrated interactive landing/login experience directly
const RootRoute: React.FC = () => {
  const { isAuthenticated, user } = useAuth();
  if (isAuthenticated) {
    const target = user?.role === 'Substation Engineer' ? '/grid-monitoring' : '/dashboard';
    return <Navigate to={target} replace />;
  }
  return <LandingLoginPage />;
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <AlertsProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Redesigned Integrated Entry Experience */}
            <Route path="/" element={<RootRoute />} />
            <Route path="/login" element={<LandingLoginPage />} />
            <Route path="/landing" element={<LandingLoginPage />} />
            <Route path="/register" element={<RegisterPage />} />

            {/* Protected Console Operations Routes */}
            <Route element={<AppLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/grid-monitoring" element={<GridMonitoring />} />
              <Route path="/consumption" element={<Consumption />} />
              <Route path="/demand-prediction" element={<DemandPrediction />} />
              <Route path="/transformers" element={<Transformers />} />
              <Route path="/feeders" element={<Feeders />} />
              <Route path="/energy-balance" element={<EnergyBalance />} />
              <Route path="/surplus-management" element={<SurplusManagement />} />
              <Route path="/bess" element={<BessMonitoring />} />
              <Route path="/what-if-simulator" element={<WhatIfSimulator />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/settings" element={<Settings />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AlertsProvider>
    </AuthProvider>
  );
};

export default App;
