"""
GRIDMIND AI - End-to-End Database Persistence Verification Test
1. Inserts a uniquely identified record into Supabase via repository.
2. Directly reads from Supabase to verify PostgreSQL storage.
3. Tests persistence through backend restart.
4. Cleans up only the temporary test record.
"""
import sys
import os
import uuid
import time
from datetime import datetime, timezone

# Add backend directory to sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.database.connection import get_supabase_client
from app.database.repositories.grid_repository import grid_repo

def run_persistence_test():
    print("=" * 65)
    print("GRIDMIND AI - SUPABASE PERSISTENCE & LIFECYCLE VERIFICATION")
    print("=" * 65)

    client = get_supabase_client()
    if not client:
        print("[FAIL] Supabase client could not be initialized.")
        sys.exit(1)

    unique_test_id = f"PERSIST-VERIFY-{uuid.uuid4().hex[:6].upper()}"
    test_scenario_name = f"Grid Stress Simulation ({unique_test_id})"

    print(f"\n[STEP 1] Inserting test record: {test_scenario_name}")
    record_payload = {
        "userId": "PersistenceTester",
        "scenarioName": test_scenario_name,
        "inputParams": {
            "test_marker": unique_test_id,
            "consumer_demand_pct": 112.5,
            "ambient_temperature_c": 36.2
        },
        "outputResults": {
            "net_grid_demand_kw": 4920.0,
            "balance_kw": 480.0,
            "status": "PERSISTENCE_CONFIRMED"
        }
    }

    grid_repo.add_simulation_record(record_payload)
    print("[STEP 1 SUCCESS] Record dispatched to repository.")

    print("\n[STEP 2] Verifying record existence directly in Supabase PostgreSQL...")
    time.sleep(1)
    res = client.table("simulation_history").select("*").ilike("scenario_name", f"%{unique_test_id}%").execute()

    if not res.data or len(res.data) == 0:
        print("[FAIL] Record not found in Supabase simulation_history table!")
        sys.exit(2)

    db_row = res.data[0]
    print(f"[STEP 2 SUCCESS] Record verified in Supabase! ID: {db_row['id']}, Created: {db_row['created_at']}")
    print(f"Stored output parameters: {db_row['output_results']}")

    print("\n[STEP 3] Simulating backend service restart / fresh connection...")
    # Re-instantiate repository to simulate completely fresh backend process state
    from app.database.repositories.grid_repository import GridRepository
    fresh_repo = GridRepository()
    records_after_restart = fresh_repo.get_simulation_history()

    found = any(unique_test_id in r["scenarioName"] for r in records_after_restart)
    if found:
        print("[STEP 3 SUCCESS] Record successfully retrieved from Supabase after restart!")
    else:
        print("[FAIL] Record missing after repository re-initialization!")
        sys.exit(3)

    print("\n[STEP 4] Cleaning up temporary test record...")
    client.table("simulation_history").delete().eq("id", db_row["id"]).execute()
    verify_cleanup = client.table("simulation_history").select("*").eq("id", db_row["id"]).execute()
    if len(verify_cleanup.data) == 0:
        print("[STEP 4 SUCCESS] Temporary test record cleanly removed from Supabase.")
    else:
        print("[WARN] Cleanup verification returned row count > 0.")

    print("\n" + "=" * 65)
    print("[FINAL RESULT] FULL DATABASE PERSISTENCE VERIFIED SUCCESSFULLY!")
    print("=" * 65)

if __name__ == "__main__":
    run_persistence_test()
