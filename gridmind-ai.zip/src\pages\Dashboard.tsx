import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Zap,
  BrainCircuit,
  Cpu,
  GitBranch,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  ChevronRight,
  Gauge,
  Activity,
  Scale,
  ArrowLeftRight,
  BatteryCharging,
  SlidersHorizontal,
  ArrowUpRight,
  RotateCcw
} from 'lucide-react';
import { MetricCard } from '../components/common/MetricCard';
import { Card } from '../components/common/Card';
import { StatusBadge } from '../components/common/StatusBadge';
import { LiveBadge } from '../components/common/LiveBadge';
import { Button } from '../components/common/Button';
import { ConsumptionChart } from '../components/charts/ConsumptionChart';
import { DemandComparisonChart } from '../components/charts/DemandComparisonChart';
import { TransformerLoadingChart } from '../components/charts/TransformerLoadingChart';
import {
  mockGridSummary,
  mockHourlyConsumption,
  mockPredictionTimeline,
  mockTransformers,
  mockRecentActivity,
} from '../data/mockData';
import { useAlerts } from '../context/AlertsContext';
import { gridmindApi, API_HOST_LABEL } from '../services/api';

export const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { activeAlerts, activeAlertsCount, criticalCount, warningCount, acknowledgeAlert } = useAlerts();

  const [overview, setOverview] = useState<any>(null);
  const [forecastTimeline, setForecastTimeline] = useState<any[]>(mockPredictionTimeline);
  const [backendOffline, setBackendOffline] = useState<boolean>(false);
  const [retryKey, setRetryKey] = useState<number>(0);

  useEffect(() => {
    let isMounted = true;
    gridmindApi
      .getDashboardOverview()
      .then((data) => {
        if (isMounted && data) {
          setOverview(data);
          setBackendOffline(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.warn('[Dashboard] Could not fetch live dashboard overview:', err);
          setBackendOffline(true);
        }
      });

    gridmindApi
      .getDemandForecast('30m')
      .then((data: any) => {
        if (isMounted && data?.forecast_timeline?.length > 0) {
          setForecastTimeline(data.forecast_timeline);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.warn('[Dashboard] Could not fetch live forecast for chart:', err);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [retryKey]);

  const summary = overview?.summary ?? (backendOffline ? null : mockGridSummary);
  const energyBalance = overview?.energy_balance;
  const surplusKw = energyBalance?.net_available_balance_kw ?? 472.0;

  return (
    <div className="space-y-6">
      {/* Top Banner: Grid Status and Quick Actions */}
      <div className="rounded-2xl bg-gradient-to-r from-[#1D3045] via-[#152538] to-[#1D3045] border border-[#34495E] p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5 min-w-0">
          <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-[#20A99E]/15 border border-[#20A99E]/30 flex items-center justify-center text-[#20A99E] shrink-0">
            <Gauge className="w-6 h-6 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-[#F8FAFC] tracking-tight">
                Active Distribution Grid Control Center
              </h2>
              <LiveBadge
                label={backendOffline ? 'BACKEND OFFLINE' : 'SCADA LIVE'}
                variant={backendOffline ? 'amber' : 'emerald'}
              />
            </div>
            <p className="text-xs text-[#A9B8C8] mt-1 leading-relaxed">
              {backendOffline ? (
                <span className="text-[#F16F75]">Live SCADA feed paused • FastAPI backend is unreachable</span>
              ) : (
                <>
                  Grid frequency synchronized at{' '}
                  <span className="text-[#35C99A] font-semibold">{summary?.frequencyHz ?? 50.02} Hz</span> •
                  11.04 kV Primary Bus • Power Factor{' '}
                  <span className="text-[#20A99E] font-semibold">{summary?.powerFactor ?? 0.98}</span>
                </>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0">
          <Button
            variant="secondary"
            size="sm"
            icon={Activity}
            onClick={() => navigate('/grid-monitoring')}
          >
            Topology View
          </Button>
          <Button
            variant="ai"
            size="sm"
            icon={BrainCircuit}
            onClick={() => navigate('/demand-prediction')}
          >
            AI Forecast Engine
          </Button>
        </div>
      </div>

      {/* Backend Offline Banner */}
      {backendOffline && (
        <div className="rounded-xl bg-[#F16F75]/15 border border-[#F16F75]/40 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#F16F75]/20 border border-[#F16F75]/40 flex items-center justify-center text-[#F16F75] shrink-0">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#F8FAFC]">FastAPI Backend Offline ({API_HOST_LABEL})</h4>
              <p className="text-xs text-[#A9B8C8] mt-0.5">
                Live SCADA telemetry and model predictions are paused. Start the FastAPI server and click Retry to resume live telemetry.
              </p>
            </div>
          </div>
          <button
            onClick={() => setRetryKey((k) => k + 1)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F16F75] hover:bg-[#d8585e] text-[#101C2C] text-xs font-bold transition-all shrink-0 cursor-pointer shadow"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retry Connection</span>
          </button>
        </div>
      )}

      {/* 6 Summary Cards: 3 columns on Laptop/Desktop for maximum readability, 6 on 2XL */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-6 gap-4">
        {/* 1. Current Electricity Consumption */}
        <MetricCard
          title="Current Electricity Consumption"
          value={summary ? summary.currentConsumptionKw.toLocaleString() : 'Unavailable'}
          unit={summary ? 'kW' : '(Offline)'}
          icon={Zap}
          trend={summary ? { value: '+4.2%', direction: 'up', label: 'vs previous hour' } : undefined}
          accent={summary ? 'teal' : 'amber'}
          onClick={() => navigate('/consumption')}
        />

        {/* 2. Random Forest Regression AI – Predicted Demand */}
        <MetricCard
          title="Predicted Demand (+30 Minutes)"
          value={summary ? summary.predictedDemandKw.toLocaleString() : 'Paused'}
          unit={summary ? 'kW' : '(Offline)'}
          icon={BrainCircuit}
          trend={summary ? { value: '+6.6%', direction: 'up', label: 'Forecast Increase' } : undefined}
          accent={summary ? 'violet' : 'amber'}
          isAi={true}
          aiBadgeText="RANDOM FOREST REGRESSION AI"
          onClick={() => navigate('/demand-prediction')}
        />

        {/* 3. Active Transformers */}
        <MetricCard
          title="Active Transformers"
          value={summary ? `${summary.activeTransformers}/${summary.totalTransformers}` : 'Fleet Offline'}
          unit="Fleet"
          icon={Cpu}
          subtitle={summary ? '2 Near 80% Capacity Warning' : 'Telemetry Paused'}
          accent={summary ? 'emerald' : 'amber'}
          onClick={() => navigate('/transformers')}
        />

        {/* 4. Active Feeders */}
        <MetricCard
          title="Active Feeders"
          value={summary ? `${summary.activeFeeders}/${summary.totalFeeders}` : 'Lines Offline'}
          unit="Lines"
          icon={GitBranch}
          subtitle={summary ? '0 Tripped • 1 Standby Line' : 'Telemetry Paused'}
          accent={summary ? 'teal' : 'amber'}
          onClick={() => navigate('/feeders')}
        />

        {/* 5. Grid Health Status */}
        <MetricCard
          title="Grid Health Index"
          value={summary ? `${summary.gridHealthScore}%` : 'Offline'}
          unit={summary ? 'Optimal' : ''}
          icon={ShieldCheck}
          trend={summary ? { value: 'Stable', direction: 'neutral', label: 'Nominal State' } : undefined}
          accent={summary ? 'emerald' : 'amber'}
          onClick={() => navigate('/grid-monitoring')}
        />

        {/* 6. Active Alerts */}
        <MetricCard
          title="Active Alerts"
          value={activeAlertsCount}
          unit="Events"
          icon={AlertTriangle}
          subtitle={`${criticalCount} Critical • ${warningCount} Warnings`}
          accent="amber"
          onClick={() => navigate('/alerts')}
        />
      </div>

      {/* Energy Balance & Active Grid Optimization Strip */}
      <div className="rounded-xl bg-[#152538] border border-[#20A99E]/40 p-4 sm:p-5 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#34495E]">
          <div>
            <div className="flex items-center gap-2">
              <Scale className="w-5 h-5 text-[#20A99E]" />
              <h3 className="text-sm sm:text-base font-bold text-[#F8FAFC] tracking-tight">
                Active Energy Balance & Substation Dispatch Overview
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#35C99A]/15 text-[#35C99A] border border-[#35C99A]/30">
                {surplusKw >= 0 ? `+${surplusKw.toLocaleString()} kW SURPLUS` : `${surplusKw.toLocaleString()} kW DEFICIT`}
              </span>
            </div>
            <p className="text-xs text-[#A9B8C8] mt-1">
              Net Available Power ({energyBalance?.incoming_supply_kw ?? 5400} kW Supply − {energyBalance?.consumer_demand_kw ?? summary?.currentConsumptionKw ?? 4820} kW Demand − {energyBalance?.network_losses_kw ?? 108} kW Technical Losses)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
            <button
              onClick={() => navigate('/energy-balance')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1D3045] hover:bg-[#263B50] text-[#20A99E] border border-[#20A99E]/40 text-xs font-semibold transition-colors"
            >
              <Scale className="w-3.5 h-3.5" />
              <span>Energy Balance</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => navigate('/surplus-management')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1D3045] hover:bg-[#263B50] text-[#35C99A] border border-[#35C99A]/40 text-xs font-semibold transition-colors"
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>Surplus Routing</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => navigate('/bess')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1D3045] hover:bg-[#263B50] text-[#9585F5] border border-[#9585F5]/40 text-xs font-semibold transition-colors"
            >
              <BatteryCharging className="w-3.5 h-3.5" />
              <span>BESS Unit (68.4% SOC)</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => navigate('/what-if-simulator')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#20A99E] hover:bg-[#1b8e85] text-[#101C2C] text-xs font-bold transition-colors shadow-sm"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>What-If Simulator</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3.5 text-xs">
          <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
            <span className="text-[10px] text-[#A9B8C8] uppercase font-semibold">Incoming Feed</span>
            <div className="font-mono text-sm font-bold text-[#F8FAFC] mt-0.5">5,400 kW</div>
            <div className="text-[10px] text-[#35C99A]">110kV Transmission Grid</div>
          </div>

          <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
            <span className="text-[10px] text-[#A9B8C8] uppercase font-semibold">Technical Losses</span>
            <div className="font-mono text-sm font-bold text-[#F5B942] mt-0.5">108.0 kW</div>
            <div className="text-[10px] text-[#A9B8C8]">2.0% I²R & Transformer Core</div>
          </div>

          <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
            <span className="text-[10px] text-[#A9B8C8] uppercase font-semibold">BESS State of Charge</span>
            <div className="font-mono text-sm font-bold text-[#35C99A] mt-0.5">68.4% (6.84 MWh)</div>
            <div className="text-[10px] text-[#20A99E]">Absorbing 1,200 kW Surplus</div>
          </div>

          <div className="bg-[#101C2C] p-2.5 rounded-lg border border-[#34495E]">
            <span className="text-[10px] text-[#A9B8C8] uppercase font-semibold">Shortage Locality</span>
            <div className="font-mono text-sm font-bold text-[#F16F75] mt-0.5">FDR-03 (-54 kW)</div>
            <div className="text-[10px] text-[#A9B8C8]">Tie-Transfer Ready</div>
          </div>
        </div>
      </div>

      {/* Primary Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Electricity Consumption Trend */}
        <Card
          title="24-Hour Electricity Consumption Trend"
          subtitle="Actual telemetry (kW) with AI peak projections"
          action={
            <Button
              variant="ghost"
              size="sm"
              icon={ChevronRight}
              iconPosition="right"
              onClick={() => navigate('/consumption')}
            >
              Detailed Analytics
            </Button>
          }
        >
          <ConsumptionChart data={mockHourlyConsumption} height={310} />
        </Card>

        {/* Current vs Predicted Demand (Random Forest) */}
        <Card
          title={
            <div className="flex flex-wrap items-center gap-2">
              <span>Current vs Predicted Demand</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#9585F5]/20 text-[#9585F5] border border-[#9585F5]/40 tracking-wider">
                RANDOM FOREST REGRESSION AI
              </span>
            </div>
          }
          subtitle="Real-time horizon prediction with 95% confidence bounds"
          highlight="violet"
          action={
            <Button
              variant="outline"
              size="sm"
              icon={Sparkles}
              onClick={() => navigate('/demand-prediction')}
            >
              Horizon Simulation
            </Button>
          }
        >
          <DemandComparisonChart data={forecastTimeline} height={310} />
        </Card>
      </div>

      {/* Secondary Row: Transformer Fleet & Grid Status Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Transformer Loading Chart (2 Cols) */}
        <div className="lg:col-span-2">
          <Card
            title="Transformer Loading Capacity (%)"
            subtitle="Real-time loading ratio vs 80% warning and 90% critical trip thresholds"
            action={
              <Button
                variant="ghost"
                size="sm"
                icon={ChevronRight}
                iconPosition="right"
                onClick={() => navigate('/transformers')}
              >
                View Fleet
              </Button>
            }
          >
            <TransformerLoadingChart data={mockTransformers} height={260} />
            <div className="mt-3 pt-3 border-t border-[#34495E] flex flex-wrap items-center justify-between gap-2 text-xs text-[#A9B8C8]">
              <div className="flex flex-wrap items-center gap-4">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-[#20A99E]" />
                  <span>Normal (&lt;80%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-[#F5B942]" />
                  <span>Warning (&ge;80%)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-[#F16F75]" />
                  <span>Critical (&ge;90%)</span>
                </span>
              </div>
              <span className="font-medium text-[#F8FAFC]">Total Fleet Capacity: 8,500 kVA</span>
            </div>
          </Card>
        </div>

        {/* Grid Status Overview (1 Col) */}
        <Card title="Distribution Grid Overview" subtitle="Substation telemetry health">
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
              <div className="flex justify-between items-center mb-1.5 text-xs gap-2">
                <span className="text-[#A9B8C8]">Frequency Stability</span>
                <span className="text-[#35C99A] font-semibold shrink-0">50.02 Hz (±0.04 Hz)</span>
              </div>
              <div className="h-1.5 w-full bg-[#101C2C] rounded-full overflow-hidden">
                <div className="h-full bg-[#35C99A] rounded-full" style={{ width: '99%' }} />
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
              <div className="flex justify-between items-center mb-1.5 text-xs gap-2">
                <span className="text-[#A9B8C8]">Bus Voltage Balance</span>
                <span className="text-[#20A99E] font-semibold shrink-0">11.04 kV (Nominal 11.0)</span>
              </div>
              <div className="h-1.5 w-full bg-[#101C2C] rounded-full overflow-hidden">
                <div className="h-full bg-[#20A99E] rounded-full" style={{ width: '96%' }} />
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
              <div className="flex justify-between items-center mb-1.5 text-xs gap-2">
                <span className="text-[#A9B8C8]">Feeder Load Balance</span>
                <span className="text-[#F5B942] font-semibold shrink-0">81.3% Peak FDR-03</span>
              </div>
              <div className="h-1.5 w-full bg-[#101C2C] rounded-full overflow-hidden">
                <div className="h-full bg-[#F5B942] rounded-full" style={{ width: '81.3%' }} />
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E]">
              <div className="flex justify-between items-center mb-1.5 text-xs gap-2">
                <span className="text-[#A9B8C8]">Total Harmonic Distortion (THD)</span>
                <span className="text-[#35C99A] font-semibold shrink-0">1.8% (&lt; 5% Limit)</span>
              </div>
              <div className="h-1.5 w-full bg-[#101C2C] rounded-full overflow-hidden">
                <div className="h-full bg-[#35C99A] rounded-full" style={{ width: '36%' }} />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Row: Recent Alerts & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts Card */}
        <Card
          title="Recent Operational Alerts"
          subtitle="Priority incidents requiring operator acknowledgement"
          action={
            <Button
              variant="ghost"
              size="sm"
              icon={ChevronRight}
              iconPosition="right"
              onClick={() => navigate('/alerts')}
            >
              All Alerts
            </Button>
          }
        >
          <div className="divide-y divide-[#34495E]/60">
            {activeAlerts.length === 0 ? (
              <div className="py-8 text-center text-xs text-[#35C99A] flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4" />
                <span>All active grid issues resolved. No open alerts.</span>
              </div>
            ) : (
              activeAlerts.slice(0, 3).map((alert) => (
                <div key={alert.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusBadge status={alert.severity} size="sm" />
                      <span className="text-xs font-semibold text-[#F8FAFC]">{alert.title}</span>
                    </div>
                    <p className="text-xs text-[#A9B8C8] line-clamp-1 leading-relaxed">{alert.description}</p>
                    <div className="flex flex-wrap items-center gap-3 text-[10px] text-[#A9B8C8]">
                      <span>Source: {alert.sourceName}</span>
                      <span>•</span>
                      <span>{alert.timestamp}</span>
                    </div>
                  </div>

                  <Button
                    variant={alert.isAcknowledged ? 'ghost' : 'outline'}
                    size="sm"
                    className="shrink-0 self-start sm:self-auto"
                    onClick={() => {
                      if (!alert.isAcknowledged) {
                        acknowledgeAlert(alert.id);
                      } else {
                        navigate('/alerts');
                      }
                    }}
                  >
                    {alert.isAcknowledged ? 'Acked' : 'Acknowledge'}
                  </Button>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Recent Activity Log */}
        <Card
          title="System & SCADA Activity"
          subtitle="Automated events, telemetry updates, and AI forecasts"
        >
          <div className="space-y-3.5">
            {mockRecentActivity.slice(0, 4).map((act) => (
              <div key={act.id} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#20A99E] mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-1 text-xs">
                    <span className="font-semibold text-[#F8FAFC]">{act.action}</span>
                    <span className="text-[10px] text-[#A9B8C8]">{act.timestamp}</span>
                  </div>
                  <p className="text-xs text-[#A9B8C8] mt-0.5 leading-relaxed">{act.details}</p>
                  <span className="text-[10px] text-[#20A99E] block mt-0.5">By {act.user}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Quick Navigation Footer Row */}
      <div className="rounded-xl bg-[#152538] border border-[#34495E] p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
        <span className="text-[#A9B8C8] font-medium">Quick Access Operations Modules:</span>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => navigate('/grid-monitoring')}>
            Topology Monitor
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate('/consumption')}>
            Locality Loads
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate('/demand-prediction')}>
            Random Forest AI
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate('/transformers')}>
            Transformer Fleet
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate('/feeders')}>
            Feeders
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigate('/reports')}>
            Export Reports
          </Button>
        </div>
      </div>
    </div>
  );
};
