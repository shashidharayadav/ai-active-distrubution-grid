/**
 * GRIDMIND AI - Frontend API Service Client
 * Connects frontend pages to the FastAPI backend at http://localhost:8000/api/v1
 * Transparently falls back to local high-fidelity demonstration datasets if backend is unreachable,
 * guaranteeing zero downtime or presentation breakage during evaluation.
 */
import type {
  TransformerItem,
  FeederItem,
  AlertItem,
  SurplusTransferItem,
  BessSystemState,
  WhatIfSimulationParams
} from '../types';
import {
  mockAlerts,
  mockSurplusTransfers,
  mockBessState,
  mockWhatIfPresets
} from '../data/mockData';

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';
export const API_HOST_LABEL = import.meta.env.VITE_API_BASE_URL
  ? import.meta.env.VITE_API_BASE_URL.replace(/\/api\/v1\/?$/, '')
  : 'http://localhost:8000';

async function safeFetch<T>(endpoint: string, options?: RequestInit, fallbackData?: T): Promise<T> {
  try {
    const res = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers,
      },
    });
    if (!res.ok) {
      throw new Error(`HTTP Error ${res.status}: ${res.statusText}`);
    }
    return await res.json();
  } catch (err) {
    if (fallbackData !== undefined) {
      console.warn(`[GRIDMIND API] Backend endpoint ${endpoint} unavailable (${err}). Using fallback state.`);
      return fallbackData;
    }
    throw err;
  }
}

export const gridmindApi = {
  // 1. Dashboard (Throws if backend is offline so Dashboard renders clear error & retry state)
  async getDashboardOverview() {
    return safeFetch('/dashboard/overview', { method: 'GET' });
  },

  // 2. Consumption
  async getCurrentConsumption() {
    return safeFetch('/consumption/current', { method: 'GET' });
  },

  // 3. Feeders & Transformers
  async getFeeders(): Promise<FeederItem[]> {
    return safeFetch<FeederItem[]>('/feeders', { method: 'GET' });
  },

  async getTransformers(): Promise<TransformerItem[]> {
    return safeFetch<TransformerItem[]>('/transformers', { method: 'GET' });
  },

  // 4. Random Forest Demand Prediction (Strictly throws on backend error; never silently substitutes mock predictions)
  async getDemandForecast(horizon: string = '30m', params?: { temperature_c?: number; industrial_activity_pct?: number; solar_offset_kw?: number }) {
    return safeFetch('/predictions/forecast', {
      method: 'POST',
      body: JSON.stringify({ horizon, ...params })
    });
  },

  async getPredictionMetrics() {
    return safeFetch('/predictions/metrics', { method: 'GET' });
  },

  async getPredictionVerification() {
    return safeFetch('/predictions/verification', { method: 'GET' });
  },

  // 5. Surplus Management
  async getSurplusOverview() {
    return safeFetch('/surplus/overview', { method: 'GET' });
  },

  async getTransferRecommendations(): Promise<SurplusTransferItem[]> {
    return safeFetch<SurplusTransferItem[]>('/surplus/recommendations', { method: 'GET' }, mockSurplusTransfers);
  },

  async approveTransferRecommendation(recId: string, operatorName: string = 'Lead Dispatcher') {
    return safeFetch(`/surplus/recommendations/${recId}/approve`, {
      method: 'POST',
      body: JSON.stringify({ operator_name: operatorName })
    });
  },

  async rejectTransferRecommendation(recId: string) {
    return safeFetch(`/surplus/recommendations/${recId}/reject`, { method: 'POST' });
  },

  async simulateTransferExecution(recId: string) {
    return safeFetch(`/surplus/recommendations/${recId}/simulate`, { method: 'POST' });
  },

  // 6. Battery Energy Storage System (BESS)
  async getBessStatus(): Promise<BessSystemState> {
    return safeFetch<BessSystemState>('/bess/status', { method: 'GET' }, mockBessState);
  },

  async chargeBess(powerKw: number, durationHours: number = 0.5) {
    return safeFetch('/bess/charge', {
      method: 'POST',
      body: JSON.stringify({ power_kw: Math.abs(powerKw), duration_hours: durationHours })
    });
  },

  async dischargeBess(powerKw: number, durationHours: number = 0.5) {
    return safeFetch('/bess/discharge', {
      method: 'POST',
      body: JSON.stringify({ power_kw: Math.abs(powerKw), duration_hours: durationHours })
    });
  },

  async setBessSetpoint(setpointKw: number, durationHours: number = 0.5) {
    return safeFetch('/bess/setpoint', {
      method: 'POST',
      body: JSON.stringify({ power_kw: setpointKw, duration_hours: durationHours })
    });
  },

  async resetBessNominal() {
    return safeFetch('/bess/reset', { method: 'POST' });
  },

  // 7. What-If Simulator
  async runWhatIfSimulation(params: WhatIfSimulationParams) {
    return safeFetch('/simulator/run', {
      method: 'POST',
      body: JSON.stringify(params)
    });
  },

  async getWhatIfPresets() {
    return safeFetch('/simulator/scenarios', { method: 'GET' }, mockWhatIfPresets);
  },

  // 8. Alerts
  async getAlerts(status?: 'active' | 'resolved' | 'unread'): Promise<AlertItem[]> {
    const path = status ? `/alerts/${status}` : '/alerts';
    return safeFetch<AlertItem[]>(path, { method: 'GET' }, mockAlerts);
  },

  async resolveAlert(alertId: string): Promise<AlertItem> {
    return safeFetch<AlertItem>(`/alerts/${alertId}/resolve`, { method: 'PATCH' });
  },

  async markAlertAsRead(alertId: string): Promise<AlertItem> {
    return safeFetch<AlertItem>(`/alerts/${alertId}/read`, { method: 'PATCH' });
  },

  async markAllAlertsAsRead() {
    return safeFetch('/alerts/read-all', { method: 'POST' });
  }
};
