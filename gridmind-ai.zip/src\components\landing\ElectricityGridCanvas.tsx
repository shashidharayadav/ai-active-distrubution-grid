import React, { useEffect, useRef } from 'react';

interface ElectricityGridCanvasProps {
  mousePos: { x: number; y: number }; // Normalized -1 to 1
}

interface Node {
  id: string;
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  type: 'substation' | 'transformer' | 'hub';
  label: string;
  radius: number;
  pulsePhase: number;
}

interface Connection {
  from: number;
  to: number;
  load: number;
}

interface EnergyPacket {
  connectionIndex: number;
  progress: number;
  speed: number;
  size: number;
  color: string;
}

export const ElectricityGridCanvas: React.FC<ElectricityGridCanvasProps> = ({ mousePos }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initNetwork();
    };

    window.addEventListener('resize', handleResize);

    // Network Topology Definition
    let nodes: Node[] = [];
    let connections: Connection[] = [];
    let packets: EnergyPacket[] = [];

    const initNetwork = () => {
      nodes = [
        // Primary Substations
        { id: 'SUB-01', x: width * 0.12, y: height * 0.22, baseX: width * 0.12, baseY: height * 0.22, type: 'substation', label: '110kV North Sub', radius: 7, pulsePhase: 0 },
        { id: 'SUB-02', x: width * 0.38, y: height * 0.18, baseX: width * 0.38, baseY: height * 0.18, type: 'substation', label: 'Bulk Grid Tie', radius: 6, pulsePhase: 1.5 },
        // Distribution Hubs
        { id: 'HUB-01', x: width * 0.24, y: height * 0.45, baseX: width * 0.24, baseY: height * 0.45, type: 'hub', label: 'Tech Corridor Hub', radius: 5, pulsePhase: 3.1 },
        { id: 'HUB-02', x: width * 0.08, y: height * 0.68, baseX: width * 0.08, baseY: height * 0.68, type: 'hub', label: 'West Industrial Hub', radius: 5, pulsePhase: 4.2 },
        { id: 'HUB-03', x: width * 0.42, y: height * 0.62, baseX: width * 0.42, baseY: height * 0.62, type: 'hub', label: 'Central Switchyard', radius: 5.5, pulsePhase: 2.2 },
        // Transformers
        { id: 'TR-101', x: width * 0.28, y: height * 0.82, baseX: width * 0.28, baseY: height * 0.82, type: 'transformer', label: 'TR-101 1600kVA', radius: 4, pulsePhase: 0.8 },
        { id: 'TR-102', x: width * 0.16, y: height * 0.88, baseX: width * 0.16, baseY: height * 0.88, type: 'transformer', label: 'TR-102 1250kVA', radius: 4, pulsePhase: 2.7 },
        { id: 'TR-103', x: width * 0.48, y: height * 0.40, baseX: width * 0.48, baseY: height * 0.40, type: 'transformer', label: 'TR-103 2000kVA', radius: 4.5, pulsePhase: 1.1 },
        // Background peripheral nodes across screen for depth
        { id: 'GEN-01', x: width * 0.62, y: height * 0.15, baseX: width * 0.62, baseY: height * 0.15, type: 'substation', label: 'Solar Infeed', radius: 5, pulsePhase: 0.4 },
        { id: 'HUB-04', x: width * 0.72, y: height * 0.35, baseX: width * 0.72, baseY: height * 0.35, type: 'hub', label: 'East Ring Bus', radius: 4.5, pulsePhase: 2.0 },
        { id: 'TR-104', x: width * 0.88, y: height * 0.22, baseX: width * 0.88, baseY: height * 0.22, type: 'transformer', label: 'TR-104 1000kVA', radius: 3.5, pulsePhase: 3.5 },
        { id: 'HUB-05', x: width * 0.68, y: height * 0.78, baseX: width * 0.68, baseY: height * 0.78, type: 'hub', label: 'BESS Storage Hub', radius: 5, pulsePhase: 1.8 },
        { id: 'TR-105', x: width * 0.84, y: height * 0.85, baseX: width * 0.84, baseY: height * 0.85, type: 'transformer', label: 'TR-105 1250kVA', radius: 4, pulsePhase: 4.0 },
      ];

      connections = [
        { from: 0, to: 1, load: 0.8 },
        { from: 0, to: 2, load: 0.75 },
        { from: 1, to: 2, load: 0.65 },
        { from: 2, to: 3, load: 0.7 },
        { from: 2, to: 4, load: 0.82 },
        { from: 3, to: 5, load: 0.6 },
        { from: 3, to: 6, load: 0.55 },
        { from: 4, to: 5, load: 0.72 },
        { from: 1, to: 7, load: 0.68 },
        { from: 4, to: 7, load: 0.78 },
        { from: 1, to: 8, load: 0.5 },
        { from: 8, to: 9, load: 0.65 },
        { from: 9, to: 10, load: 0.58 },
        { from: 7, to: 11, load: 0.62 },
        { from: 11, to: 12, load: 0.54 },
        { from: 9, to: 11, load: 0.7 },
      ];

      // Spawn energy packets that flow along feeder paths
      packets = [];
      const packetCount = 28;
      for (let i = 0; i < packetCount; i++) {
        packets.push({
          connectionIndex: Math.floor(Math.random() * connections.length),
          progress: Math.random(),
          speed: 0.003 + Math.random() * 0.004,
          size: 2 + Math.random() * 2,
          color: Math.random() > 0.4 ? '#20A99E' : '#35C99A',
        });
      }
    };

    initNetwork();

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Render loop
    let tick = 0;

    const render = () => {
      tick += 0.02;
      ctx.clearRect(0, 0, width, height);

      // Parallax smooth offset calculation
      const parallaxX = mousePos.x * 24;
      const parallaxY = mousePos.y * 18;

      // Update node positions with gentle mouse parallax
      nodes.forEach((n, idx) => {
        // Subtle depth based on index
        const depth = 0.5 + (idx % 3) * 0.3;
        n.x = n.baseX + parallaxX * depth;
        n.y = n.baseY + parallaxY * depth;
      });

      // 1. Draw Connection Lines (Feeders)
      connections.forEach((conn) => {
        const fromNode = nodes[conn.from];
        const toNode = nodes[conn.to];
        if (!fromNode || !toNode) return;

        // Gradient line
        const grad = ctx.createLinearGradient(fromNode.x, fromNode.y, toNode.x, toNode.y);
        grad.addColorStop(0, 'rgba(32, 169, 158, 0.28)');
        grad.addColorStop(0.5, 'rgba(53, 201, 154, 0.35)');
        grad.addColorStop(1, 'rgba(32, 169, 158, 0.2)');

        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        ctx.strokeStyle = grad;
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // Subtle glowing outer stroke
        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        ctx.strokeStyle = 'rgba(32, 169, 158, 0.06)';
        ctx.lineWidth = 4;
        ctx.stroke();
      });

      // 2. Draw Moving Energy Packets (Power Flow)
      if (!prefersReducedMotion) {
        packets.forEach((pkt) => {
          pkt.progress += pkt.speed;
          if (pkt.progress >= 1) {
            pkt.progress = 0;
            pkt.connectionIndex = Math.floor(Math.random() * connections.length);
          }

          const conn = connections[pkt.connectionIndex];
          if (!conn) return;
          const fromNode = nodes[conn.from];
          const toNode = nodes[conn.to];
          if (!fromNode || !toNode) return;

          const currX = fromNode.x + (toNode.x - fromNode.x) * pkt.progress;
          const currY = fromNode.y + (toNode.y - fromNode.y) * pkt.progress;

          // Energy Packet Core
          ctx.beginPath();
          ctx.arc(currX, currY, pkt.size, 0, Math.PI * 2);
          ctx.fillStyle = pkt.color;
          ctx.shadowColor = pkt.color;
          ctx.shadowBlur = 10;
          ctx.fill();
          ctx.shadowBlur = 0;

          // Trailing pulse
          const trailLength = 0.08;
          const trailStart = Math.max(0, pkt.progress - trailLength);
          const trailX = fromNode.x + (toNode.x - fromNode.x) * trailStart;
          const trailY = fromNode.y + (toNode.y - fromNode.y) * trailStart;

          ctx.beginPath();
          ctx.moveTo(trailX, trailY);
          ctx.lineTo(currX, currY);
          ctx.strokeStyle = pkt.color;
          ctx.lineWidth = pkt.size * 0.7;
          ctx.globalAlpha = 0.4;
          ctx.stroke();
          ctx.globalAlpha = 1.0;
        });
      }

      // 3. Draw Nodes (Substations, Hubs, Transformers)
      nodes.forEach((n) => {
        const pulse = Math.sin(tick + n.pulsePhase) * 0.5 + 0.5;

        // Outer pulsing ring
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius + 6 + pulse * 4, 0, Math.PI * 2);
        ctx.strokeStyle =
          n.type === 'substation'
            ? `rgba(32, 169, 158, ${0.15 + pulse * 0.2})`
            : n.type === 'hub'
            ? `rgba(53, 201, 154, ${0.12 + pulse * 0.18})`
            : `rgba(149, 133, 245, ${0.12 + pulse * 0.15})`;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Node Glow Halo
        const glowGrad = ctx.createRadialGradient(n.x, n.y, 1, n.x, n.y, n.radius * 3.5);
        if (n.type === 'substation') {
          glowGrad.addColorStop(0, 'rgba(32, 169, 158, 0.45)');
          glowGrad.addColorStop(1, 'rgba(32, 169, 158, 0)');
        } else if (n.type === 'hub') {
          glowGrad.addColorStop(0, 'rgba(53, 201, 154, 0.4)');
          glowGrad.addColorStop(1, 'rgba(53, 201, 154, 0)');
        } else {
          glowGrad.addColorStop(0, 'rgba(149, 133, 245, 0.35)');
          glowGrad.addColorStop(1, 'rgba(149, 133, 245, 0)');
        }
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius * 3.5, 0, Math.PI * 2);
        ctx.fillStyle = glowGrad;
        ctx.fill();

        // Solid Node Core
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
        ctx.fillStyle =
          n.type === 'substation'
            ? '#20A99E'
            : n.type === 'hub'
            ? '#35C99A'
            : '#9585F5';
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Inner white dot for precision instrumentation feel
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = '#F8FAFC';
        ctx.fill();

        // Substation/Transformer Icon Label (for prominent nodes)
        if (width > 768 && (n.type === 'substation' || n.type === 'hub')) {
          ctx.font = '10px Inter, system-ui, sans-serif';
          ctx.fillStyle = 'rgba(169, 184, 200, 0.75)';
          ctx.fillText(n.label, n.x + n.radius + 6, n.y + 3);
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [mousePos]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none z-0"
      style={{ opacity: 0.9 }}
    />
  );
};
