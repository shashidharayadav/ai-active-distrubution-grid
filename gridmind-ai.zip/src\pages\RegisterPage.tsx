import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Zap,
  Lock,
  Mail,
  User as UserIcon,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowRight,
  Briefcase
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/common/Button';
import type { User } from '../types';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register } = useAuth();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<User['role']>('Grid Dispatcher');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please provide your full operator name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid work or engineering email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters in length.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      register(name, email, role);
      setIsLoading(false);
      navigate('/dashboard');
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#101C2C] text-[#F8FAFC] flex flex-col justify-center items-center px-4 py-8 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 grid-pattern-bg opacity-30 pointer-events-none" />
      <div className="absolute top-10 right-10 w-80 h-80 bg-[#35C99A]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-[#9585F5]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Brand Header */}
      <div className="w-full max-w-md mb-4 flex items-center justify-between z-10">
        <Link to="/login" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#20A99E] to-[#9585F5] p-0.5 flex items-center justify-center">
            <div className="w-full h-full bg-[#152538] rounded-md flex items-center justify-center">
              <Zap className="w-4 h-4 text-[#20A99E]" />
            </div>
          </div>
          <span className="font-bold text-sm tracking-wider text-[#F8FAFC]">
            GRID<span className="text-[#20A99E]">MIND</span> AI
          </span>
        </Link>
        <span className="text-xs text-[#A9B8C8]">System Registration</span>
      </div>

      <div className="w-full max-w-md z-10">
        <div className="rounded-2xl bg-[#1D3045] border border-[#34495E] p-8 shadow-2xl relative">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold tracking-tight text-[#F8FAFC]">
              Operator Registration
            </h2>
            <p className="text-xs text-[#A9B8C8] mt-1.5">
              Request access credentials for GRIDMIND AI Active Grid Operations
            </p>
          </div>

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-[#F16F75]/15 border border-[#F16F75]/30 text-xs text-[#F16F75] flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F16F75]" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                Full Legal / Operator Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Shashidhara Yadav"
                  className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                Authorized Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="shashidhara@gridmind.ai"
                  className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                Grid Operations Role
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                  <Briefcase className="w-4 h-4" />
                </div>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as User['role'])}
                  className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] transition-colors"
                >
                  <option value="Grid Dispatcher">Grid Dispatcher (Distribution Control)</option>
                  <option value="Substation Engineer">Substation Electrical Engineer</option>
                  <option value="Utility Analyst">Utility Demand Forecasting Analyst</option>
                  <option value="System Admin">SCADA & AI System Administrator</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="flex items-center gap-1.5 text-[#A9B8C8] hover:text-[#F8FAFC]"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showPassword ? 'Hide passwords' : 'Show passwords'}</span>
              </button>
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              loading={isLoading}
              icon={ArrowRight}
              iconPosition="right"
              className="w-full mt-2"
            >
              Register & Launch Console
            </Button>
          </form>

          <div className="mt-5 pt-4 border-t border-[#34495E] text-center text-xs text-[#A9B8C8]">
            <span>Already have an authorized operator profile? </span>
            <Link to="/login" className="text-[#20A99E] font-medium hover:underline">
              Sign In
            </Link>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-[11px] text-[#A9B8C8]/70">
          <ShieldCheck className="w-3.5 h-3.5 text-[#35C99A]" />
          <span>Active Grid Distribution Protocols & IEC 61850 Compliant Mock System</span>
        </div>
      </div>
    </div>
  );
};
