"""
GRIDMIND AI - Historical Records & Exports API Routes
"""
from fastapi import APIRouter
from typing import List, Dict, Any

router = APIRouter(prefix="/history", tags=["History"])


@router.get("/telemetry")
def get_historical_telemetry():
    return [
        {"id": "HIST-01", "date": "2026-11-16", "time": "15:00", "locality": "Tech Park Cyber Corridor", "consumptionKw": 1350, "peakStatus": "Peak", "powerFactor": 0.98, "frequencyHz": 50.02},
        {"id": "HIST-02", "date": "2026-11-16", "time": "14:00", "locality": "Heavy Industrial Estate", "consumptionKw": 1220, "peakStatus": "Normal", "powerFactor": 0.95, "frequencyHz": 50.01},
        {"id": "HIST-03", "date": "2026-11-16", "time": "13:00", "locality": "Downtown Commercial Center", "consumptionKw": 840, "peakStatus": "Normal", "powerFactor": 0.97, "frequencyHz": 50.03},
        {"id": "HIST-04", "date": "2026-11-16", "time": "12:00", "locality": "North Residential Valley", "consumptionKw": 650, "peakStatus": "Normal", "powerFactor": 0.99, "frequencyHz": 50.00},
        {"id": "HIST-05", "date": "2026-11-16", "time": "11:00", "locality": "Metro Transit & Railway Depot", "consumptionKw": 480, "peakStatus": "Peak", "powerFactor": 0.98, "frequencyHz": 49.98},
        {"id": "HIST-06", "date": "2026-11-16", "time": "10:00", "locality": "Greenfield Health Care City", "consumptionKw": 280, "peakStatus": "Normal", "powerFactor": 0.99, "frequencyHz": 50.02}
    ]


@router.get("/transfers")
def get_transfer_history():
    return [
        {
            "id": "HIST-TR-01",
            "timestamp": "2026-11-16 11:20:00",
            "source_feeder": "FDR-04 (Residential Valley)",
            "dest_feeder": "FDR-03 (Heavy Industrial Line)",
            "transferred_kw": 160.0,
            "delivered_kw": 155.2,
            "losses_kw": 4.8,
            "status": "COMPLETED",
            "resolution": "FULLY_RESOLVED",
            "dispatcher": "AI Dispatch Agent"
        }
    ]
