"""
GRIDMIND AI - Feeders Operations API Routes
"""
from fastapi import APIRouter, HTTPException
from typing import List
from app.database.repositories.grid_repository import grid_repo
from app.schemas.grid_schemas import FeederItemSchema

router = APIRouter(prefix="/feeders", tags=["Feeders"])


@router.get("", response_model=List[FeederItemSchema])
def list_feeders():
    return [FeederItemSchema(**f) for f in grid_repo.get_feeders()]


@router.get("/{feeder_id}", response_model=FeederItemSchema)
def get_feeder(feeder_id: str):
    f = grid_repo.get_feeder_by_id(feeder_id)
    if not f:
        raise HTTPException(status_code=404, detail=f"Feeder '{feeder_id}' not found")
    return FeederItemSchema(**f)
