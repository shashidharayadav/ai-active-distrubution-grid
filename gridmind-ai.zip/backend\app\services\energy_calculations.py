"""
GRIDMIND AI - Centralized Electrical Calculations Service
Strictly implements the physics and engineering calculations for:
- Interval Energy (kWh = kW * h)
- Net Grid Demand & Net Available Energy Balance
- Three-Phase Line Losses & Transformer Apparent Power
- Feeder & Transformer Loading
- Phase Imbalance & Permissible Voltage Bands
- Transformer Thermal Degradation Estimation
- BESS Charging & Discharging Physics (SOC tracking with 93.8% efficiency)
- Inter-Feeder Transfer Delivered Power & Deficit Resolution
"""
import math
from typing import Dict, Any, Optional


def calculate_interval_energy(average_power_kw: float, duration_hours: float) -> float:
    """
    Energy (kWh) = Average Power (kW) * Duration (hours).
    Example: 500 kW for 1 hour = 500 kWh.
    500 kW for 0.5 hours = 250 kWh.
    """
    if duration_hours < 0:
        raise ValueError("Duration cannot be negative")
    return round(average_power_kw * duration_hours, 4)


def calculate_meter_delta_energy(current_meter_kwh: float, previous_meter_kwh: float) -> float:
    """
    Interval Energy = Current Meter Reading - Previous Meter Reading.
    """
    if current_meter_kwh < previous_meter_kwh:
        raise ValueError("Current meter reading cannot be less than previous meter reading without rollover handling")
    return round(current_meter_kwh - previous_meter_kwh, 4)


def calculate_energy_balance(
    incoming_supply_kw: float,
    consumer_demand_kw: float,
    solar_generation_kw: float,
    network_losses_kw: float,
    bess_charging_kw: float = 0.0,
    bess_discharging_kw: float = 0.0
) -> Dict[str, Any]:
    """
    Grid Energy Balance Calculation:
    Net Grid Demand = Total Consumer Demand - Solar Generation.
    Adjusted Grid Demand = Net Grid Demand + BESS Charging Power - BESS Discharging Power.
    Net Available Balance = Incoming Supply - Adjusted Grid Demand - Network Losses.

    Standard Hackathon Example (without BESS):
    Supply = 5,400 kW, Consumer Demand = 4,820 kW, Solar = 350 kW, Losses = 93 kW.
    Net Grid Demand = 4,820 - 350 = 4,470 kW.
    Net Available Balance = 5,400 - 4,470 - 93 = +837 kW (Surplus).
    """
    net_grid_demand_kw = round(consumer_demand_kw - solar_generation_kw, 2)
    adjusted_grid_demand_kw = round(net_grid_demand_kw + bess_charging_kw - bess_discharging_kw, 2)
    net_available_balance_kw = round(incoming_supply_kw - adjusted_grid_demand_kw - network_losses_kw, 2)

    if net_available_balance_kw > 0:
        status = "SURPLUS"
    elif net_available_balance_kw < 0:
        status = "DEFICIT"
    else:
        status = "BALANCED"

    return {
        "incoming_supply_kw": incoming_supply_kw,
        "consumer_demand_kw": consumer_demand_kw,
        "solar_generation_kw": solar_generation_kw,
        "net_grid_demand_kw": net_grid_demand_kw,
        "bess_charging_kw": bess_charging_kw,
        "bess_discharging_kw": bess_discharging_kw,
        "adjusted_grid_demand_kw": adjusted_grid_demand_kw,
        "network_losses_kw": network_losses_kw,
        "net_available_balance_kw": net_available_balance_kw,
        "status": status,
        "is_surplus": net_available_balance_kw > 0,
        "is_deficit": net_available_balance_kw < 0,
    }


def calculate_three_phase_line_losses(
    active_power_kw: float,
    line_to_line_voltage_v: float,
    power_factor: float,
    line_resistance_ohm: float
) -> float:
    """
    Line Current: I = P / (sqrt(3) * V_LL * Power Factor)
    Three-phase resistive line losses: P_loss = 3 * I^2 * R_phase
    Returns losses in kW.
    """
    if line_to_line_voltage_v <= 0 or power_factor <= 0:
        return 0.0

    p_watts = active_power_kw * 1000.0
    current_a = p_watts / (math.sqrt(3) * line_to_line_voltage_v * power_factor)
    losses_watts = 3.0 * (current_a ** 2) * line_resistance_ohm
    return round(losses_watts / 1000.0, 3)


def calculate_feeder_loading(actual_load_kw: float, rated_capacity_kw: float) -> float:
    """
    Feeder Loading (%) = Actual Feeder Load / Feeder Rated Capacity * 100.
    Example: 745 kW / 1,000 kW * 100 = 74.5%.
    """
    if rated_capacity_kw <= 0:
        return 0.0
    return round((actual_load_kw / rated_capacity_kw) * 100.0, 2)


def calculate_transformer_loading(
    active_power_kw: float,
    reactive_power_kvar: float,
    rated_capacity_kva: float
) -> Dict[str, Any]:
    """
    Apparent Power S (kVA) = sqrt(P^2 + Q^2)
    Transformer Loading (%) = Actual Apparent Power / Rated kVA * 100
    """
    apparent_power_kva = math.sqrt(active_power_kw ** 2 + reactive_power_kvar ** 2)
    loading_pct = (apparent_power_kva / rated_capacity_kva * 100.0) if rated_capacity_kva > 0 else 0.0

    if loading_pct >= 90.0:
        status = "CRITICAL"
    elif loading_pct >= 80.0:
        status = "WARNING"
    else:
        status = "NORMAL"

    return {
        "apparent_power_kva": round(apparent_power_kva, 2),
        "rated_capacity_kva": rated_capacity_kva,
        "loading_percentage": round(loading_pct, 2),
        "status": status
    }


def calculate_phase_imbalance(phase_a_current: float, phase_b_current: float, phase_c_current: float) -> float:
    """
    Average Current = (IA + IB + IC) / 3
    Phase Imbalance (%) = Max absolute deviation from average / Average Current * 100
    """
    avg_current = (phase_a_current + phase_b_current + phase_c_current) / 3.0
    if avg_current <= 0:
        return 0.0
    max_dev = max(
        abs(phase_a_current - avg_current),
        abs(phase_b_current - avg_current),
        abs(phase_c_current - avg_current)
    )
    return round((max_dev / avg_current) * 100.0, 2)


def calculate_voltage_status(
    voltage_kv: float,
    nominal_kv: float = 11.0,
    tolerance_pct: float = 6.0
) -> Dict[str, Any]:
    """
    For 11 kV with +/- 6% permissible band:
    Lower limit = 10.34 kV. Upper limit = 11.66 kV.
    """
    lower_limit = round(nominal_kv * (1.0 - tolerance_pct / 100.0), 3)
    upper_limit = round(nominal_kv * (1.0 + tolerance_pct / 100.0), 3)
    deviation_pct = round(((voltage_kv - nominal_kv) / nominal_kv) * 100.0, 2)

    is_under_voltage = voltage_kv < lower_limit
    is_over_voltage = voltage_kv > upper_limit
    is_normal = not (is_under_voltage or is_over_voltage)

    return {
        "voltage_kv": voltage_kv,
        "nominal_kv": nominal_kv,
        "lower_limit_kv": lower_limit,
        "upper_limit_kv": upper_limit,
        "deviation_pct": deviation_pct,
        "status": "NORMAL" if is_normal else ("UNDER_VOLTAGE" if is_under_voltage else "OVER_VOLTAGE")
    }


def calculate_transformer_thermal_estimate(
    ambient_temp_c: float,
    loading_pct: float,
    rated_top_oil_rise_c: float = 55.0,
    rated_hotspot_rise_c: float = 65.0
) -> Dict[str, float]:
    """
    Configurable thermal estimation for transformers according to IEEE/IEC 60076 loading guide:
    Top oil rise = Rated Oil Rise * (Loading / 100) ^ 0.8
    Winding hotspot rise = Rated Hotspot Rise * (Loading / 100) ^ 1.6
    """
    load_ratio = max(0.0, loading_pct / 100.0)
    top_oil_rise = rated_top_oil_rise_c * (load_ratio ** 0.8)
    oil_temp_c = ambient_temp_c + top_oil_rise
    hotspot_rise = rated_hotspot_rise_c * (load_ratio ** 1.6)
    winding_temp_c = ambient_temp_c + hotspot_rise

    return {
        "oil_temp_c": round(oil_temp_c, 1),
        "winding_temp_c": round(winding_temp_c, 1),
        "ambient_temp_c": ambient_temp_c,
        "is_overheating": winding_temp_c >= 95.0
    }


def calculate_bess_charge(
    capacity_kwh: float,
    current_stored_kwh: float,
    charging_power_kw: float,
    duration_hours: float,
    charging_efficiency: float = 0.9380
) -> Dict[str, Any]:
    """
    BESS Charging calculation:
    Energy Input = Charging Power * Duration
    Stored Energy Increase = Energy Input * Charging Efficiency
    New Stored Energy = Previous Stored Energy + Stored Energy Increase
    New SOC = New Stored Energy / Capacity * 100
    """
    energy_input_kwh = charging_power_kw * duration_hours
    stored_increase_kwh = energy_input_kwh * charging_efficiency
    new_stored_kwh = min(capacity_kwh, current_stored_kwh + stored_increase_kwh)
    new_soc_pct = (new_stored_kwh / capacity_kwh) * 100.0

    return {
        "charging_power_kw": charging_power_kw,
        "duration_hours": duration_hours,
        "energy_input_kwh": round(energy_input_kwh, 3),
        "stored_energy_increase_kwh": round(stored_increase_kwh, 3),
        "previous_stored_kwh": current_stored_kwh,
        "new_stored_kwh": round(new_stored_kwh, 3),
        "previous_soc_pct": round((current_stored_kwh / capacity_kwh) * 100.0, 3),
        "new_soc_pct": round(new_soc_pct, 3),
        "charging_efficiency": charging_efficiency
    }


def calculate_bess_discharge(
    capacity_kwh: float,
    current_stored_kwh: float,
    discharge_power_kw: float,
    duration_hours: float,
    discharge_efficiency: float = 0.9380
) -> Dict[str, Any]:
    """
    BESS Discharging calculation:
    Energy Delivered = Discharging Power * Duration
    Stored Energy Decrease = Energy Delivered / Discharge Efficiency
    New Stored Energy = Previous Stored Energy - Stored Energy Decrease
    New SOC = New Stored Energy / Capacity * 100
    """
    energy_delivered_kwh = discharge_power_kw * duration_hours
    stored_decrease_kwh = energy_delivered_kwh / discharge_efficiency
    new_stored_kwh = max(0.0, current_stored_kwh - stored_decrease_kwh)
    new_soc_pct = (new_stored_kwh / capacity_kwh) * 100.0

    return {
        "discharge_power_kw": discharge_power_kw,
        "duration_hours": duration_hours,
        "energy_delivered_kwh": round(energy_delivered_kwh, 3),
        "stored_energy_decrease_kwh": round(stored_decrease_kwh, 3),
        "previous_stored_kwh": current_stored_kwh,
        "new_stored_kwh": round(new_stored_kwh, 3),
        "previous_soc_pct": round((current_stored_kwh / capacity_kwh) * 100.0, 3),
        "new_soc_pct": round(new_soc_pct, 3),
        "discharge_efficiency": discharge_efficiency
    }


def calculate_transfer_delivered_and_deficit(
    destination_deficit_kw: float,
    sending_power_kw: float,
    transfer_losses_kw: float
) -> Dict[str, Any]:
    """
    Inter-feeder power transfer delivery & remaining deficit calculation:
    Delivered Power = Sending Power - Transfer Losses.
    Remaining Deficit = max(0, Original Deficit - Delivered Power).

    Example from prompt:
    Destination Deficit = 60 kW, Sending Power = 40 kW, Transfer Losses = 2 kW.
    Delivered Power = 38 kW.
    Remaining Deficit = 60 - 38 = 22 kW.
    Deficit Resolution = PARTIALLY_RESOLVED.
    """
    delivered_power_kw = max(0.0, sending_power_kw - transfer_losses_kw)
    remaining_deficit_kw = max(0.0, destination_deficit_kw - delivered_power_kw)

    if remaining_deficit_kw == 0.0:
        resolution_status = "FULLY_RESOLVED"
    elif delivered_power_kw > 0.0:
        resolution_status = "PARTIALLY_RESOLVED"
    else:
        resolution_status = "UNRESOLVED"

    return {
        "original_deficit_kw": destination_deficit_kw,
        "sending_power_kw": sending_power_kw,
        "transfer_losses_kw": transfer_losses_kw,
        "delivered_power_kw": round(delivered_power_kw, 2),
        "remaining_deficit_kw": round(remaining_deficit_kw, 2),
        "resolution_status": resolution_status
    }
