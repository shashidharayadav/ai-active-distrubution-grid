"""
GRIDMIND AI - Grid Telemetry & Ingestion API Routes
Supports both simulated telemetry generation and authorized SCADA RTU packet ingestion.
"""
from fastapi import APIRouter
from typing import List, Dict, Any
from datetime import datetime, timezone
from app.schemas.grid_schemas import TelemetryIngestRequest

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])


@router.get("/latest")
def get_latest_telemetry() -> Dict[str, Any]:
    """
    Returns latest real-time distribution bus telemetry.
    """
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "primary_bus_voltage_kv": 11.04,
        "grid_frequency_hz": 50.02,
        "power_factor": 0.98,
        "total_active_power_kw": 4820.0,
        "total_reactive_power_kvar": 980.0,
        "phase_a_current_a": 142.5,
        "phase_b_current_a": 144.1,
        "phase_c_current_a": 141.2,
        "phase_unbalance_pct": 1.2,
        "thd_pct": 2.1,
        "source_type": "SIMULATED_SCADA_RTU"
    }


@router.post("/ingest")
def ingest_telemetry(payload: TelemetryIngestRequest) -> Dict[str, Any]:
    """
    Ingests electrical telemetry records into storage.
    Validates physical parameters and timestamps.
    """
    count = len(payload.records)
    return {
        "status": "INGESTED",
        "records_processed": count,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
