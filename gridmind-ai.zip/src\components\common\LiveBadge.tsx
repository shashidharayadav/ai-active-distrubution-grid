import React from 'react';

interface LiveBadgeProps {
  label?: string;
  className?: string;
  variant?: 'teal' | 'emerald' | 'violet' | 'amber';
}

export const LiveBadge: React.FC<LiveBadgeProps> = ({
  label = 'LIVE SCADA FEED',
  className = '',
  variant = 'emerald',
}) => {
  const colors = {
    teal: 'bg-[#20A99E]/15 text-[#20A99E] border-[#20A99E]/30 dot-teal',
    emerald: 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30',
    violet: 'bg-[#9585F5]/15 text-[#9585F5] border-[#9585F5]/30',
    amber: 'bg-[#F5B942]/15 text-[#F5B942] border-[#F5B942]/30',
  }[variant];

  const dotColor = {
    teal: 'bg-[#20A99E]',
    emerald: 'bg-[#35C99A]',
    violet: 'bg-[#9585F5]',
    amber: 'bg-[#F5B942]',
  }[variant];

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-semibold tracking-wider uppercase select-none ${colors} ${className}`}
    >
      <span className="relative flex h-2 w-2">
        <span
          className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${dotColor}`}
        />
        <span className={`relative inline-flex rounded-full h-2 w-2 ${dotColor}`} />
      </span>
      <span>{label}</span>
    </div>
  );
};
