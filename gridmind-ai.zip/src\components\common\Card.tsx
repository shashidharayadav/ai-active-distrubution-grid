import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: React.ReactNode;
  subtitle?: string;
  action?: React.ReactNode;
  highlight?: 'none' | 'teal' | 'violet' | 'amber' | 'emerald';
  noPadding?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = '',
  title,
  subtitle,
  action,
  highlight = 'none',
  noPadding = false,
}) => {
  const highlightBorder = {
    none: 'border-[#34495E]',
    teal: 'border-[#20A99E]/40',
    violet: 'border-[#9585F5]/40 shadow-[0_0_15px_-4px_rgba(149,133,245,0.2)]',
    amber: 'border-[#F5B942]/40',
    emerald: 'border-[#35C99A]/40',
  }[highlight];

  return (
    <div
      className={`rounded-xl bg-[#1D3045] border transition-all duration-200 ${highlightBorder} ${className}`}
    >
      {(title || action || subtitle) && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#34495E] px-5 py-4">
          <div>
            {typeof title === 'string' ? (
              <h3 className="text-base font-semibold text-[#F8FAFC] tracking-wide flex items-center gap-2">
                {title}
              </h3>
            ) : (
              title
            )}
            {subtitle && <p className="text-xs text-[#A9B8C8] mt-0.5">{subtitle}</p>}
          </div>
          {action && <div className="flex items-center gap-2 self-start sm:self-auto">{action}</div>}
        </div>
      )}
      <div className={noPadding ? '' : 'p-5'}>{children}</div>
    </div>
  );
};
