"""
GRIDMIND AI - Battery Energy Storage System (BESS) Service
Strictly implements:
- 10 MWh (10,000 kWh) utility-scale BESS physics
- Power sign convention: Negative = Charging, Positive = Discharging, 0 = Idle
- Efficiency-corrected SOC calculations (93.8% round-trip efficiency)
- Intelligent Solar / Grid Surplus Absorption (capped by available surplus & max charge power)
- Peak Shaving Discharge Dispatch (capped by reserve SOC & max discharge power)
- Operational safety bounds: 15.0% min reserve SOC, 95.0% max SOC, cell thermal limits
"""
from typing import Dict, Any, Optional
from datetime import datetime, timezone
from app.services.energy_calculations import calculate_bess_charge, calculate_bess_discharge
from app.database.repositories.grid_repository import grid_repo
import logging

logger = logging.getLogger("gridmind.services.bess")


class BessService:
    def __init__(self):
        self.capacity_kwh: float = 10000.0  # 10 MWh
        self.efficiency: float = 0.9380     # 93.8%
        self.min_soc_pct: float = 15.0
        self.max_soc_pct: float = 95.0
        self.max_charge_power_kw: float = 2000.0
        self.max_discharge_power_kw: float = 2000.0

    def get_status(self) -> Dict[str, Any]:
        return grid_repo.get_bess_state()

    def get_history(self) -> list:
        return grid_repo.get_bess_history()

    def charge(
        self,
        requested_power_kw: float,
        duration_hours: float = 0.5,
        available_surplus_kw: Optional[float] = None,
        operator_name: str = "Lead Dispatcher",
        event_name: str = "Active Grid Surplus Charging"
    ) -> Dict[str, Any]:
        """
        Charges BESS within available surplus and equipment constraints.
        Power requested must be positive magnitude, internally applied as charging.
        """
        current_state = grid_repo.get_bess_state()
        current_stored = current_state["currentEnergyKwh"]

        # 1. Cap charging power by available surplus if specified
        allowed_power = min(requested_power_kw, self.max_charge_power_kw)
        if available_surplus_kw is not None and available_surplus_kw > 0:
            allowed_power = min(allowed_power, available_surplus_kw)

        # 2. Check max SOC constraint (95%)
        max_storable = (self.capacity_kwh * (self.max_soc_pct / 100.0)) - current_stored
        if max_storable <= 0:
            raise ValueError(f"BESS is already at or above maximum permissible SOC ({self.max_soc_pct}%)")

        result = calculate_bess_charge(
            capacity_kwh=self.capacity_kwh,
            current_stored_kwh=current_stored,
            charging_power_kw=allowed_power,
            duration_hours=duration_hours,
            charging_efficiency=self.efficiency
        )

        # Update repository state
        new_stored = result["new_stored_kwh"]
        new_soc = result["new_soc_pct"]
        # Negative power represents charging in telemetry conventions
        grid_repo.update_bess_state({
            "currentEnergyKwh": new_stored,
            "stateOfChargePct": new_soc,
            "currentPowerKw": -abs(allowed_power),
            "operatingMode": "MANUAL_CHARGE" if "Manual" in event_name else "AUTO_AI"
        })

        # Record event log
        event = {
            "id": f"EVT-BESS-{int(datetime.now(timezone.utc).timestamp()) % 10000:04d}",
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "event": event_name,
            "type": "CHARGE",
            "powerKw": -abs(allowed_power),
            "durationMinutes": int(duration_hours * 60),
            "energyKwh": result["energy_input_kwh"],
            "initialSocPct": result["previous_soc_pct"],
            "finalSocPct": new_soc,
            "dispatcher": operator_name
        }
        grid_repo.add_bess_event(event)

        return {
            "bess_state": grid_repo.get_bess_state(),
            "charge_details": result,
            "event": event
        }

    def discharge(
        self,
        requested_power_kw: float,
        duration_hours: float = 0.5,
        operator_name: str = "Lead Dispatcher",
        event_name: str = "Peak Tariff Demand Shaving"
    ) -> Dict[str, Any]:
        """
        Discharges BESS within reserve SOC and discharge power limits.
        """
        current_state = grid_repo.get_bess_state()
        current_stored = current_state["currentEnergyKwh"]

        # Check reserve SOC constraint (15%)
        usable_stored = current_stored - (self.capacity_kwh * (self.min_soc_pct / 100.0))
        if usable_stored <= 0:
            raise ValueError(f"BESS cannot discharge below reserve threshold ({self.min_soc_pct}% SOC)")

        allowed_power = min(requested_power_kw, self.max_discharge_power_kw)

        result = calculate_bess_discharge(
            capacity_kwh=self.capacity_kwh,
            current_stored_kwh=current_stored,
            discharge_power_kw=allowed_power,
            duration_hours=duration_hours,
            discharge_efficiency=self.efficiency
        )

        new_stored = result["new_stored_kwh"]
        new_soc = result["new_soc_pct"]

        grid_repo.update_bess_state({
            "currentEnergyKwh": new_stored,
            "stateOfChargePct": new_soc,
            "currentPowerKw": abs(allowed_power),
            "operatingMode": "MANUAL_DISCHARGE" if "Manual" in event_name else "AUTO_AI"
        })

        event = {
            "id": f"EVT-BESS-{int(datetime.now(timezone.utc).timestamp()) % 10000:04d}",
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "event": event_name,
            "type": "DISCHARGE",
            "powerKw": abs(allowed_power),
            "durationMinutes": int(duration_hours * 60),
            "energyKwh": result["energy_delivered_kwh"],
            "initialSocPct": result["previous_soc_pct"],
            "finalSocPct": new_soc,
            "dispatcher": operator_name
        }
        grid_repo.add_bess_event(event)

        return {
            "bess_state": grid_repo.get_bess_state(),
            "discharge_details": result,
            "event": event
        }

    def set_dispatch_setpoint(
        self,
        setpoint_kw: float,
        duration_hours: float = 0.5,
        operator_name: str = "Lead Dispatcher"
    ) -> Dict[str, Any]:
        """
        Unified setpoint handler:
        - Negative setpoint: Charge
        - Positive setpoint: Discharge
        - Zero setpoint: Standby / Idle
        """
        if setpoint_kw < 0:
            return self.charge(
                requested_power_kw=abs(setpoint_kw),
                duration_hours=duration_hours,
                operator_name=operator_name,
                event_name="Dispatch Setpoint (Charge)"
            )
        elif setpoint_kw > 0:
            return self.discharge(
                requested_power_kw=abs(setpoint_kw),
                duration_hours=duration_hours,
                operator_name=operator_name,
                event_name="Dispatch Setpoint (Discharge)"
            )
        else:
            grid_repo.update_bess_state({
                "currentPowerKw": 0.0,
                "operatingMode": "STANDBY"
            })
            return {
                "bess_state": grid_repo.get_bess_state(),
                "status": "STANDBY",
                "message": "BESS setpoint set to 0 kW (Standby / Idle)"
            }

    def reset_to_nominal(self) -> Dict[str, Any]:
        """
        Resets BESS state to standard 68.4% SOC (6,840 kWh) nominal baseline.
        """
        grid_repo.update_bess_state({
            "currentEnergyKwh": 6840.0,
            "stateOfChargePct": 68.4,
            "currentPowerKw": -420.0,
            "operatingMode": "AUTO_AI"
        })
        return grid_repo.get_bess_state()


# Singleton instance
bess_service = BessService()
