import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import type { HourlyConsumption } from '../../types';

interface ConsumptionChartProps {
  data: HourlyConsumption[];
  height?: number;
  showBaseline?: boolean;
}

export const ConsumptionChart: React.FC<ConsumptionChartProps> = ({
  data,
  height = 320,
  showBaseline = true,
}) => {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <AreaChart data={data} margin={{ top: 15, right: 15, left: 10, bottom: 5 }}>
          <defs>
            <linearGradient id="consumptionGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#20A99E" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#20A99E" stopOpacity={0.0} />
            </linearGradient>
            <linearGradient id="predictedGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#9585F5" stopOpacity={0.3} />
              <stop offset="95%" stopColor="#9585F5" stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#34495E" opacity={0.6} vertical={false} />
          <XAxis
            dataKey="time"
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            minTickGap={25}
          />
          <YAxis
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            domain={['auto', 'auto']}
            tickFormatter={(val) => `${val}`}
            width={48}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1D3045',
              borderColor: '#34495E',
              borderRadius: '8px',
              color: '#F8FAFC',
              fontSize: '12px',
              boxShadow: '0 8px 16px rgba(0,0,0,0.4)',
            }}
            labelStyle={{ color: '#20A99E', fontWeight: 600, marginBottom: '4px' }}
            formatter={(value: any, name: any) => {
              if (name === 'consumption') return [`${value} kW`, 'Actual Consumption'];
              if (name === 'predicted') return [`${value} kW`, 'AI Predicted Demand'];
              if (name === 'baseline') return [`${value} kW`, 'Historical Baseline'];
              return [value, name];
            }}
          />
          <Legend
            verticalAlign="top"
            align="right"
            iconType="circle"
            wrapperStyle={{ paddingBottom: '16px', fontSize: '11px' }}
            formatter={(value) => {
              if (value === 'consumption') return <span className="text-[#F8FAFC]">Actual Load (kW)</span>;
              if (value === 'predicted') return <span className="text-[#9585F5]">AI Predicted (kW)</span>;
              if (value === 'baseline') return <span className="text-[#A9B8C8]">Seasonal Baseline (kW)</span>;
              return value;
            }}
          />
          <Area
            type="monotone"
            dataKey="consumption"
            stroke="#20A99E"
            strokeWidth={2.5}
            fillOpacity={1}
            fill="url(#consumptionGradient)"
          />
          <Area
            type="monotone"
            dataKey="predicted"
            stroke="#9585F5"
            strokeWidth={2}
            strokeDasharray="4 4"
            fillOpacity={1}
            fill="url(#predictedGradient)"
          />
          {showBaseline && (
            <Area
              type="monotone"
              dataKey="baseline"
              stroke="#A9B8C8"
              strokeWidth={1.5}
              strokeDasharray="2 2"
              fill="transparent"
            />
          )}
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
