import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Activity,
  Zap,
  BrainCircuit,
  Cpu,
  GitBranch,
  Bell,
  Settings,
  Globe,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Scale,
  ArrowLeftRight,
  BatteryCharging,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useAlerts } from '../../context/AlertsContext';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const { unreadCount } = useAlerts();

  const navItems = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: LayoutDashboard,
    },
    {
      name: 'Grid Monitoring',
      path: '/grid-monitoring',
      icon: Activity,
    },
    {
      name: 'Energy Balance',
      path: '/energy-balance',
      icon: Scale,
      badge: 'AUDIT',
      badgeColor: 'bg-[#20A99E]/20 text-[#20A99E] border-[#20A99E]/40',
    },
    {
      name: 'Surplus Management',
      path: '/surplus-management',
      icon: ArrowLeftRight,
      badge: 'DISPATCH',
      badgeColor: 'bg-[#35C99A]/20 text-[#35C99A] border-[#35C99A]/40',
    },
    {
      name: 'Battery Storage (BESS)',
      path: '/bess',
      icon: BatteryCharging,
      badge: '10 MWh',
      badgeColor: 'bg-[#35C99A]/20 text-[#35C99A] border-[#35C99A]/40',
    },
    {
      name: 'What-If Simulator',
      path: '/what-if-simulator',
      icon: SlidersHorizontal,
      badge: 'SIM',
      badgeColor: 'bg-[#9585F5]/20 text-[#9585F5] border-[#9585F5]/40',
    },
    {
      name: 'Electricity Consumption',
      path: '/consumption',
      icon: Zap,
    },
    {
      name: 'Demand Prediction',
      path: '/demand-prediction',
      icon: BrainCircuit,
      badge: 'AI',
      badgeColor: 'bg-[#9585F5]/20 text-[#9585F5] border-[#9585F5]/40',
    },
    {
      name: 'Transformers',
      path: '/transformers',
      icon: Cpu,
    },
    {
      name: 'Feeders',
      path: '/feeders',
      icon: GitBranch,
    },
    {
      name: 'Alerts & Events',
      path: '/alerts',
      icon: Bell,
      badge: unreadCount > 0 ? `${unreadCount}` : undefined,
      badgeColor: 'bg-[#F16F75]/20 text-[#F16F75] border-[#F16F75]/40',
    },
    {
      name: 'Settings',
      path: '/settings',
      icon: Settings,
    },
  ];

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#152538] border-r border-[#34495E]">
      {/* Brand Header */}
      <div className="flex items-center justify-between px-5 h-16 border-b border-[#34495E] shrink-0">
        <NavLink to="/dashboard" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#20A99E] via-[#35C99A] to-[#9585F5] p-0.5 flex items-center justify-center shadow-[0_0_15px_rgba(32,169,158,0.3)] group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#152538] rounded-[10px] flex items-center justify-center">
              <Zap className="w-5 h-5 text-[#20A99E]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-wider text-[#F8FAFC]">
                GRID<span className="text-[#20A99E]">MIND</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-[#9585F5]/20 text-[#9585F5] border border-[#9585F5]/30">
                AI
              </span>
            </div>
            <p className="text-[9px] text-[#A9B8C8] tracking-widest uppercase">Active Grid Ops</p>
          </div>
        </NavLink>

        {/* Mobile close button */}
        <button
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Grid Status Quick Pill */}
      <div className="px-4 py-3 border-b border-[#34495E]/50 shrink-0">
        <div className="rounded-lg bg-[#101C2C] border border-[#34495E] p-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#35C99A] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#35C99A]" />
            </span>
            <span className="text-[11px] font-medium text-[#A9B8C8]">Grid State:</span>
          </div>
          <span className="text-[11px] font-semibold text-[#35C99A]">SYNCED 50.02 Hz</span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold tracking-wider text-[#A9B8C8]/60 uppercase">
          OPERATIONS CONTROL
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onCloseMobile}
              className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                isActive
                  ? 'bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30 font-semibold'
                  : 'text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-[#20A99E]' : 'text-[#A9B8C8] group-hover:text-[#F8FAFC]'
                  }`}
                />
                <span>{item.name}</span>
              </div>
              <div className="flex items-center gap-1.5">
                {item.badge && (
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-[#20A99E]" />}
              </div>
            </NavLink>
          );
        })}

        <div className="pt-4 px-3 pb-2 text-[10px] font-semibold tracking-wider text-[#A9B8C8]/60 uppercase">
          PORTAL
        </div>
        <NavLink
          to="/landing"
          onClick={onCloseMobile}
          className="flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50]/60 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Globe className="w-4 h-4 text-[#9585F5]" />
            <span>Public Presentation</span>
          </div>
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#9585F5]/10 text-[#9585F5] border border-[#9585F5]/20">
            VIEW
          </span>
        </NavLink>
      </nav>

      {/* User Section & Logout */}
      <div className="p-3 border-t border-[#34495E] shrink-0 bg-[#101C2C]/50">
        <div className="flex items-center justify-between p-2 rounded-lg bg-[#1D3045] border border-[#34495E]">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-[#20A99E]/20 border border-[#20A99E]/40 flex items-center justify-center text-xs font-bold text-[#20A99E] shrink-0">
              {user?.name ? user.name.slice(0, 2).toUpperCase() : 'OP'}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-[#F8FAFC] truncate">
                {user?.name || 'Grid Operator'}
              </p>
              <div className="flex items-center gap-1 text-[10px] text-[#A9B8C8] truncate">
                <ShieldCheck className="w-3 h-3 text-[#35C99A]" />
                <span className="truncate">{user?.role || 'Dispatcher'}</span>
              </div>
            </div>
          </div>
          <button
            onClick={logout}
            title="Sign Out"
            className="p-1.5 text-[#A9B8C8] hover:text-[#F16F75] hover:bg-[#263B50] rounded-md transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile drawer backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-[#101C2C]/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Mobile drawer */}
      <div
        className={`fixed inset-y-0 left-0 w-72 z-50 transform transition-transform duration-300 ease-in-out lg:hidden ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {sidebarContent}
      </div>
    </>
  );
};
