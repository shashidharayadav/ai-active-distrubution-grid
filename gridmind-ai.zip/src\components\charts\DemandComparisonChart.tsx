import React from 'react';
import {
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine,
} from 'recharts';
import type { PredictionDataPoint } from '../../types';

interface DemandComparisonChartProps {
  data: PredictionDataPoint[];
  height?: number;
}

export const DemandComparisonChart: React.FC<DemandComparisonChartProps> = ({
  data,
  height = 340,
}) => {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <AreaChart data={data} margin={{ top: 15, right: 15, left: 10, bottom: 5 }}>
          <defs>
            <linearGradient id="bandGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#9585F5" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#9585F5" stopOpacity={0.03} />
            </linearGradient>
            <linearGradient id="actualLineGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#20A99E" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#20A99E" stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#34495E" opacity={0.6} vertical={false} />
          <XAxis
            dataKey="time"
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            minTickGap={25}
          />
          <YAxis
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            domain={['dataMin - 300', 'dataMax + 300']}
            tickFormatter={(val) => `${val}`}
            width={48}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1D3045',
              borderColor: '#34495E',
              borderRadius: '8px',
              color: '#F8FAFC',
              fontSize: '12px',
              boxShadow: '0 8px 20px rgba(0,0,0,0.4)',
            }}
            labelStyle={{ color: '#9585F5', fontWeight: 600, marginBottom: '4px' }}
            formatter={(value: any, name: any) => {
              if (name === 'actual') return [`${value ?? 'N/A'} kW`, 'Actual Telemetry'];
              if (name === 'predicted') return [`${value} kW`, 'Random Forest Prediction'];
              if (name === 'upperBound') return [`${value} kW`, '95% Confidence Upper'];
              if (name === 'lowerBound') return [`${value} kW`, '95% Confidence Lower'];
              return [value, name];
            }}
          />
          <Legend
            verticalAlign="top"
            align="right"
            iconType="circle"
            wrapperStyle={{ paddingBottom: '16px', fontSize: '11px' }}
            formatter={(value) => {
              if (value === 'actual') return <span className="text-[#20A99E] font-medium">Actual Telemetry (kW)</span>;
              if (value === 'predicted') return <span className="text-[#9585F5] font-medium">Random Forest Forecast (kW)</span>;
              if (value === 'upperBound') return <span className="text-[#A9B8C8]">95% Confidence Bounds</span>;
              return value;
            }}
          />
          <ReferenceLine
            x="23:00 (Now)"
            stroke="#F5B942"
            strokeDasharray="3 3"
            strokeWidth={1.5}
            label={{
              value: 'NOW',
              fill: '#F5B942',
              fontSize: 10,
              position: 'insideTopLeft',
            }}
          />

          {/* Confidence interval area */}
          <Area
            type="monotone"
            dataKey="upperBound"
            stroke="transparent"
            fill="url(#bandGradient)"
            fillOpacity={1}
          />
          {/* Hide lowerBound from legend */}
          <Area
            type="monotone"
            dataKey="lowerBound"
            stroke="transparent"
            fill="#1D3045"
            fillOpacity={1}
            legendType="none"
          />

          {/* Actual line (ends at current time) */}
          <Line
            type="monotone"
            dataKey="actual"
            stroke="#20A99E"
            strokeWidth={3}
            dot={{ r: 4, fill: '#20A99E', strokeWidth: 0 }}
            activeDot={{ r: 6, fill: '#20A99E', stroke: '#F8FAFC', strokeWidth: 2 }}
            connectNulls={false}
          />

          {/* Predicted line */}
          <Line
            type="monotone"
            dataKey="predicted"
            stroke="#9585F5"
            strokeWidth={2.5}
            strokeDasharray="4 4"
            dot={{ r: 3, fill: '#9585F5' }}
            activeDot={{ r: 6, fill: '#9585F5', stroke: '#F8FAFC', strokeWidth: 2 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
