import React, { useState } from 'react';
import {
  Zap,
  TrendingUp,
  Clock,
  MapPin,
  Download,
  Search,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  GitBranch,
  Cpu
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { Button } from '../components/common/Button';
import { LocalityPieChart } from '../components/charts/LocalityPieChart';
import {
  mockLocalityConsumption,
  mockHistoricalRecords,
  mockFeeders,
  mockTransformers,
} from '../data/mockData';

export const Consumption: React.FC = () => {
  const [selectedLocality, setSelectedLocality] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDateFilter] = useState<string>('2026-11-14');
  const [feederFilter, setFeederFilter] = useState<'ALL' | 'ONLINE' | 'STANDBY'>('ALL');

  // Filter historical records
  const filteredRecords = mockHistoricalRecords.filter((rec) => {
    const matchesLocality = selectedLocality === 'ALL' || rec.locality.includes(selectedLocality);
    const matchesSearch =
      rec.locality.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLocality && matchesSearch;
  });

  // Filter feeders
  const filteredFeeders = mockFeeders.filter((f) => {
    if (feederFilter === 'ALL') return true;
    return f.status === feederFilter;
  });

  // Client-side CSV export simulation
  const handleExportCsv = () => {
    const headers = 'Record ID,Date,Time,Locality,Consumption (kW),Peak Status,Power Factor,Frequency (Hz)\n';
    const rows = filteredRecords
      .map(
        (r) =>
          `${r.id},${r.date},${r.time},"${r.locality}",${r.consumptionKw},${r.peakStatus},${r.powerFactor},${r.frequencyHz}`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `gridmind_consumption_report_${selectedDateFilter}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            Electricity Consumption Analytics
          </h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Aggregated distribution load profiles, feeder/transformer loading shares, and historical demand logs
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            icon={Download}
            onClick={handleExportCsv}
          >
            Export CSV Dataset
          </Button>
        </div>
      </div>

      {/* Key Consumption Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Current System Load"
          value="4,820"
          unit="kW"
          icon={Zap}
          trend={{ value: '+4.2%', direction: 'up', label: 'vs baseline' }}
          accent="teal"
        />
        <MetricCard
          title="Daily Peak Demand"
          value="5,490"
          unit="kW"
          icon={TrendingUp}
          subtitle="Observed at 19:00 PM"
          accent="amber"
        />
        <MetricCard
          title="Base Minimum Load"
          value="1,980"
          unit="kW"
          icon={Clock}
          subtitle="Observed at 04:00 AM"
          accent="emerald"
        />
        <MetricCard
          title="Total Daily Energy"
          value="98.4"
          unit="MWh"
          icon={Layers}
          trend={{ value: '-1.8%', direction: 'down', label: 'energy saving' }}
          accent="teal"
        />
      </div>

      {/* Locality Breakdown: Donut Chart & Locality Table (Duplicate 24-hr graph removed) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Donut Chart */}
        <Card
          title="Locality Demand Share"
          subtitle="Percentage distribution of active 4,820 kW load"
        >
          <LocalityPieChart data={mockLocalityConsumption} height={230} />
          <div className="mt-4 space-y-1.5 text-xs">
            {mockLocalityConsumption.slice(0, 4).map((loc) => (
              <div key={loc.id} className="flex items-center justify-between py-1 text-xs">
                <span className="text-[#A9B8C8] truncate max-w-[180px]">{loc.name}</span>
                <span className="text-[#F8FAFC] font-semibold">{loc.currentKw} kW ({loc.percentage}%)</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Locality Table */}
        <div className="lg:col-span-2">
          <Card
            title="Distribution Locality Demand Breakdown"
            subtitle="Real-time loading, connected feeders and transformers"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                    <th className="pb-2.5 font-medium">Locality Area</th>
                    <th className="pb-2.5 font-medium">Feeder</th>
                    <th className="pb-2.5 font-medium">Transformer</th>
                    <th className="pb-2.5 font-medium">Active Load</th>
                    <th className="pb-2.5 font-medium text-right">Trend</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#34495E]/60">
                  {mockLocalityConsumption.map((loc) => (
                    <tr key={loc.id} className="hover:bg-[#263B50]/30 transition-colors">
                      <td className="py-2.5 font-medium text-[#F8FAFC] flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#20A99E]" />
                        <span>{loc.name}</span>
                      </td>
                      <td className="py-2.5 font-mono text-[#A9B8C8]">{loc.feederId}</td>
                      <td className="py-2.5 font-mono text-[#A9B8C8]">{loc.transformerId}</td>
                      <td className="py-2.5 font-semibold text-[#20A99E]">
                        {loc.currentKw} kW ({loc.percentage}%)
                      </td>
                      <td className="py-2.5 text-right">
                        {loc.trend === 'up' && (
                          <span className="inline-flex items-center text-[#F16F75] font-semibold">
                            <ArrowUpRight className="w-3.5 h-3.5" /> Rising
                          </span>
                        )}
                        {loc.trend === 'down' && (
                          <span className="inline-flex items-center text-[#35C99A] font-semibold">
                            <ArrowDownRight className="w-3.5 h-3.5" /> Easing
                          </span>
                        )}
                        {loc.trend === 'stable' && (
                          <span className="text-[#A9B8C8]">Stable</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>

      {/* Feeder & Transformer Consumption Loading Analysis (Rich granular breakdown replacing duplicate chart) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Feeder-wise Consumption Share */}
        <Card
          title={
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-[#20A99E]" />
                Feeder-wise Consumption & Loading
              </span>
              <div className="flex items-center gap-1">
                {(['ALL', 'ONLINE', 'STANDBY'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setFeederFilter(st)}
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                      feederFilter === st
                        ? 'bg-[#20A99E] text-[#101C2C]'
                        : 'text-[#A9B8C8] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
          }
          subtitle="Real-time demand (kW), feeder ampacity, and loading percentage"
        >
          <div className="space-y-3 pt-1">
            {filteredFeeders.slice(0, 5).map((fdr) => (
              <div key={fdr.id} className="p-2.5 rounded-lg bg-[#152538] border border-[#34495E]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-[#F8FAFC]">{fdr.name}</span>
                    <span className="text-[10px] text-[#A9B8C8]">{fdr.locality}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold text-[#20A99E]">{fdr.demandKw} kW</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold border ${
                      fdr.status === 'ONLINE' ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30' : 'bg-[#A9B8C8]/15 text-[#A9B8C8] border-[#A9B8C8]/30'
                    }`}>
                      {fdr.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#A9B8C8] mt-1 mb-1">
                  <span>Loading: {fdr.feederLoadingPercentage}%</span>
                  <span>PF: {fdr.powerFactor} • {fdr.voltageKv} kV</span>
                </div>
                <div className="w-full bg-[#101C2C] rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      fdr.feederLoadingPercentage > 80 ? 'bg-[#F16F75]' : fdr.feederLoadingPercentage > 65 ? 'bg-[#F5B942]' : 'bg-[#35C99A]'
                    }`}
                    style={{ width: `${Math.min(100, fdr.feederLoadingPercentage)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Transformer-wise Consumption & Thermal Margin */}
        <Card
          title={
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#9585F5]" />
              <span>Transformer Substation Demand Load</span>
            </div>
          }
          subtitle="MVA loading, winding temperature, and tap positions"
        >
          <div className="space-y-3 pt-1">
            {mockTransformers.slice(0, 5).map((tr) => (
              <div key={tr.id} className="p-2.5 rounded-lg bg-[#152538] border border-[#34495E]">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-mono font-bold text-[#F8FAFC]">{tr.name}</span>
                  <span className="font-mono font-semibold text-[#9585F5]">{tr.currentLoadKva} kVA</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#A9B8C8] mb-1">
                  <span>Capacity: {tr.capacityKva} kVA ({tr.loadingPercentage}%)</span>
                  <span>Winding: {tr.windingTempC}°C • Oil: {tr.oilTempC}°C</span>
                </div>
                <div className="w-full bg-[#101C2C] rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      tr.loadingPercentage > 80 ? 'bg-[#F16F75]' : tr.loadingPercentage > 65 ? 'bg-[#F5B942]' : 'bg-[#20A99E]'
                    }`}
                    style={{ width: `${Math.min(100, tr.loadingPercentage)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Historical Consumption Records with Search & Filter */}
      <Card
        title="Historical Consumption Telemetry Logs"
        subtitle="Individual 15-minute interval power meter telemetry"
        action={
          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#A9B8C8]" />
              <input
                type="text"
                placeholder="Search locality..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-[#152538] border border-[#34495E] rounded-lg text-[#F8FAFC] placeholder-[#A9B8C8]/60 focus:outline-none focus:border-[#20A99E] w-40 sm:w-52"
              />
            </div>

            {/* Locality Dropdown Filter */}
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-[#152538] border border-[#34495E] rounded-lg text-[#F8FAFC] focus:outline-none focus:border-[#20A99E]"
            >
              <option value="ALL">All Localities</option>
              {mockLocalityConsumption.map((l) => (
                <option key={l.id} value={l.name}>
                  {l.name}
                </option>
              ))}
            </select>
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                <th className="pb-2.5 font-medium">Record ID</th>
                <th className="pb-2.5 font-medium">Timestamp</th>
                <th className="pb-2.5 font-medium">Locality Area</th>
                <th className="pb-2.5 font-medium">Consumption</th>
                <th className="pb-2.5 font-medium">Status</th>
                <th className="pb-2.5 font-medium text-right">Power Factor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#34495E]/60">
              {filteredRecords.slice(0, 10).map((rec) => (
                <tr key={rec.id} className="hover:bg-[#263B50]/30 transition-colors">
                  <td className="py-2.5 font-mono text-[#A9B8C8]">{rec.id}</td>
                  <td className="py-2.5 text-[#F8FAFC] font-medium">
                    {rec.date} {rec.time}
                  </td>
                  <td className="py-2.5 text-[#F8FAFC]">{rec.locality}</td>
                  <td className="py-2.5 font-mono font-semibold text-[#20A99E]">
                    {rec.consumptionKw.toLocaleString()} kW
                  </td>
                  <td className="py-2.5">
                    <span
                      className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold ${
                        rec.peakStatus === 'Peak'
                          ? 'bg-[#F16F75]/15 text-[#F16F75] border border-[#F16F75]/30'
                          : rec.peakStatus === 'Normal'
                          ? 'bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30'
                          : 'bg-[#35C99A]/15 text-[#35C99A] border border-[#35C99A]/30'
                      }`}
                    >
                      {rec.peakStatus}
                    </span>
                  </td>
                  <td className="py-2.5 font-mono text-right text-[#A9B8C8]">
                    {rec.powerFactor} ({rec.frequencyHz} Hz)
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
