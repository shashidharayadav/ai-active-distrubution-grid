"""
GRIDMIND AI - Interactive What-If Simulator API Routes
"""
from fastapi import APIRouter
from typing import List, Dict, Any
from app.services.simulator_service import simulator_service
from app.database.repositories.grid_repository import grid_repo
from app.schemas.grid_schemas import WhatIfRequest, WhatIfResponse

router = APIRouter(prefix="/simulator", tags=["What-If Simulator"])


@router.post("/run", response_model=WhatIfResponse)
def run_simulation(payload: WhatIfRequest):
    """
    Executes the What-If simulation engine with physical category modeling,
    ambient thermal sensitivity, solar PV offset, and BESS dispatch setpoints.
    """
    result = simulator_service.calculate_simulation(
        demand_change_pct=payload.demandChangePct,
        solar_pv_generation_kw=payload.solarPvGenerationKw,
        industrial_activity_pct=payload.industrialActivityPct,
        ambient_temperature_c=payload.ambientTemperatureC,
        grid_supply_kw=payload.gridSupplyKw,
        bess_dispatch_kw=payload.bessDispatchKw
    )
    # Record history
    grid_repo.add_simulation_record({
        "inputs": payload.model_dump(),
        "outputs": result
    })
    return WhatIfResponse(**result)


@router.get("/scenarios")
def get_scenario_presets() -> List[Dict[str, Any]]:
    """
    Returns the 5 defined simulation presets with dynamically calculated outcomes.
    """
    return simulator_service.get_presets()


@router.get("/history")
def get_simulation_history() -> List[Dict[str, Any]]:
    return grid_repo.get_simulation_history()
