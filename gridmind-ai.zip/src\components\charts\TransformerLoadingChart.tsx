import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Cell,
} from 'recharts';
import type { TransformerItem } from '../../types';

interface TransformerLoadingChartProps {
  data: TransformerItem[];
  height?: number;
}

export const TransformerLoadingChart: React.FC<TransformerLoadingChartProps> = ({
  data,
  height = 260,
}) => {
  const chartData = data.map((t) => ({
    id: t.id,
    name: t.id,
    fullName: t.name,
    loadingPercentage: t.loadingPercentage,
    capacityKva: t.capacityKva,
    currentLoadKva: t.currentLoadKva,
    status: t.status,
  }));

  const getBarColor = (pct: number) => {
    if (pct >= 90) return '#F16F75'; // Critical Coral Red
    if (pct >= 80) return '#F5B942'; // Warning Amber
    return '#20A99E'; // Normal Modern Teal
  };

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <BarChart data={chartData} margin={{ top: 15, right: 65, left: 10, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#34495E" opacity={0.6} vertical={false} />
          <XAxis
            dataKey="name"
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            minTickGap={10}
          />
          <YAxis
            stroke="#A9B8C8"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#34495E' }}
            domain={[0, 100]}
            unit="%"
            width={40}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1D3045',
              borderColor: '#34495E',
              borderRadius: '8px',
              color: '#F8FAFC',
              fontSize: '12px',
              boxShadow: '0 8px 16px rgba(0,0,0,0.4)',
            }}
            formatter={(value: any, _: any, item: any) => {
              const p = item.payload;
              return [
                `${value}% (${p.currentLoadKva} / ${p.capacityKva} kVA)`,
                p.fullName,
              ];
            }}
          />
          <ReferenceLine
            y={80}
            stroke="#F5B942"
            strokeDasharray="3 3"
            strokeWidth={1}
            label={{ value: 'Warning 80%', fill: '#F5B942', fontSize: 10, position: 'right' }}
          />
          <ReferenceLine
            y={90}
            stroke="#F16F75"
            strokeDasharray="3 3"
            strokeWidth={1}
            label={{ value: 'Critical 90%', fill: '#F16F75', fontSize: 10, position: 'right' }}
          />
          <Bar dataKey="loadingPercentage" radius={[4, 4, 0, 0]}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getBarColor(entry.loadingPercentage)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
