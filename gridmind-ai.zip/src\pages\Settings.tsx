import React, { useState } from 'react';
import {
  Save,
  CheckCircle2,
  ShieldCheck,
  BrainCircuit,
  Bell,
  Cpu
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { useAuth } from '../context/AuthContext';

export const Settings: React.FC = () => {
  const { user } = useAuth();

  // Settings State
  const [warningThreshold, setWarningThreshold] = useState<number>(80);
  const [criticalThreshold, setCriticalThreshold] = useState<number>(90);
  const [voltageTolerance, setVoltageTolerance] = useState<number>(2.5);
  const [frequencyTolerance, setFrequencyTolerance] = useState<number>(0.2);
  const [refreshInterval, setRefreshInterval] = useState<number>(5);
  const [defaultHorizon, setDefaultHorizon] = useState<string>('30m');
  const [confidenceLevel, setConfidenceLevel] = useState<number>(95);
  const [emailAlerts, setEmailAlerts] = useState<boolean>(true);
  const [criticalSms, setCriticalSms] = useState<boolean>(true);
  const [showSavedToast, setShowSavedToast] = useState<boolean>(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">System & Operational Thresholds</h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Configure SCADA telemetry trip limits, Random Forest model parameters, and alert dispatch rules
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          icon={Save}
          onClick={handleSave}
        >
          Save Configurations
        </Button>
      </div>

      {showSavedToast && (
        <div className="p-3.5 rounded-xl bg-[#35C99A]/15 border border-[#35C99A]/40 text-[#35C99A] text-xs font-semibold flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Configuration parameters updated and applied to grid simulation models.</span>
        </div>
      )}

      {/* Grid Electrical & SCADA Alarm Thresholds */}
      <Card
        title={
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#20A99E]" />
            <span>Grid Electrical & Asset Protection Limits</span>
          </div>
        }
        subtitle="Configures when transformers and feeders enter Warning or Critical alarm states"
        highlight="teal"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Transformer Warning Loading Threshold (%)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="70"
                max="85"
                value={warningThreshold}
                onChange={(e) => setWarningThreshold(Number(e.target.value))}
                className="flex-1 accent-[#F5B942]"
              />
              <span className="font-mono text-[#F5B942] font-bold w-12 text-right">
                {warningThreshold}%
              </span>
            </div>
            <p className="text-[10px] text-[#A9B8C8] mt-1">Triggers forced auxiliary cooling fans</p>
          </div>

          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Transformer Critical Trip Threshold (%)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="85"
                max="95"
                value={criticalThreshold}
                onChange={(e) => setCriticalThreshold(Number(e.target.value))}
                className="flex-1 accent-[#F16F75]"
              />
              <span className="font-mono text-[#F16F75] font-bold w-12 text-right">
                {criticalThreshold}%
              </span>
            </div>
            <p className="text-[10px] text-[#A9B8C8] mt-1">Triggers automated tie-switch load shedding advisory</p>
          </div>

          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Primary Bus Voltage Tolerance (± %)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                step="0.1"
                min="1.0"
                max="5.0"
                value={voltageTolerance}
                onChange={(e) => setVoltageTolerance(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg bg-[#152538] border border-[#34495E] text-[#F8FAFC] focus:outline-none focus:border-[#20A99E]"
              />
            </div>
            <p className="text-[10px] text-[#A9B8C8] mt-1">Target 11.00 kV (Tolerance ±{voltageTolerance}%)</p>
          </div>

          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Grid Frequency Fluctuation Tolerance (± Hz)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                step="0.05"
                min="0.1"
                max="0.5"
                value={frequencyTolerance}
                onChange={(e) => setFrequencyTolerance(Number(e.target.value))}
                className="w-full px-3 py-1.5 rounded-lg bg-[#152538] border border-[#34495E] text-[#F8FAFC] focus:outline-none focus:border-[#20A99E]"
              />
            </div>
            <p className="text-[10px] text-[#A9B8C8] mt-1">Target 50.00 Hz (Allowed range 49.80 – 50.20 Hz)</p>
          </div>
        </div>
      </Card>

      {/* AI Machine Learning Prediction Engine Settings */}
      <Card
        title={
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-4 h-4 text-[#9585F5]" />
            <span>Random Forest Prediction Engine Settings</span>
          </div>
        }
        subtitle="Tune inference horizon, retraining cycles, and confidence bands"
        highlight="violet"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Default Operational Forecast Horizon
            </label>
            <select
              value={defaultHorizon}
              onChange={(e) => setDefaultHorizon(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-[#152538] border border-[#34495E] text-[#F8FAFC] focus:outline-none focus:border-[#9585F5]"
            >
              <option value="30m">30 Minutes (Fast Dispatch)</option>
              <option value="1h">1 Hour (Peaking Advisory)</option>
              <option value="2h">2 Hours (Switch Planning)</option>
              <option value="24h">24 Hours (Day-Ahead Market)</option>
            </select>
          </div>

          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              Prediction Confidence Band Level
            </label>
            <select
              value={confidenceLevel}
              onChange={(e) => setConfidenceLevel(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-[#152538] border border-[#34495E] text-[#F8FAFC] focus:outline-none focus:border-[#9585F5]"
            >
              <option value={90}>90% Confidence Interval</option>
              <option value={95}>95% Standard Confidence</option>
              <option value={99}>99% Conservative Boundary</option>
            </select>
          </div>

          <div>
            <label className="block text-[#F8FAFC] font-medium mb-1">
              SCADA Telemetry Refresh Interval
            </label>
            <select
              value={refreshInterval}
              onChange={(e) => setRefreshInterval(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-[#152538] border border-[#34495E] text-[#F8FAFC] focus:outline-none focus:border-[#9585F5]"
            >
              <option value={5}>Every 5 Seconds (Real-time)</option>
              <option value={10}>Every 10 Seconds</option>
              <option value={30}>Every 30 Seconds</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Notification Preferences & Operator Profile */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card
          title={
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-[#F5B942]" />
              <span>Notification & Dispatch Alerts</span>
            </div>
          }
          subtitle="Routing channels for priority distribution alarms"
        >
          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-2.5 rounded-lg bg-[#152538] border border-[#34495E] cursor-pointer">
              <span className="text-[#F8FAFC]">Email Dispatch Advisories</span>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="rounded accent-[#20A99E]"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-lg bg-[#152538] border border-[#34495E] cursor-pointer">
              <span className="text-[#F8FAFC]">Emergency SMS for Critical Overloads</span>
              <input
                type="checkbox"
                checked={criticalSms}
                onChange={(e) => setCriticalSms(e.target.checked)}
                className="rounded accent-[#F16F75]"
              />
            </label>
          </div>
        </Card>

        <Card
          title={
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#35C99A]" />
              <span>Operator Profile Session</span>
            </div>
          }
          subtitle="Authenticated session details"
        >
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-[#34495E]/60">
              <span className="text-[#A9B8C8]">Logged Operator:</span>
              <span className="text-[#F8FAFC] font-semibold">{user?.name || 'Chief Operator'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#34495E]/60">
              <span className="text-[#A9B8C8]">Access Role:</span>
              <span className="text-[#35C99A] font-semibold">{user?.role || 'Grid Dispatcher'}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#34495E]/60">
              <span className="text-[#A9B8C8]">Security Clearance:</span>
              <span className="text-[#20A99E] font-semibold">Tier 3 (Active Grid Switching)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#A9B8C8]">System Version:</span>
              <span className="text-[#A9B8C8] font-mono">GRIDMIND v2.4.2-PROD</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
