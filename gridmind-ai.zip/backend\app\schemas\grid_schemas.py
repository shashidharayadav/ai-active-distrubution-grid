"""
GRIDMIND AI - Pydantic Request & Response Schemas
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


# =============================================================================
# Dashboard & Overview
# =============================================================================
class MetricSummarySchema(BaseModel):
    currentConsumptionKw: float
    predictedDemandKw: float
    activeTransformers: int
    totalTransformers: int
    activeFeeders: int
    totalFeeders: int
    gridHealthScore: float
    frequencyHz: float
    voltageKv: float
    powerFactor: float
    activeAlertsCount: int
    criticalAlertsCount: int
    warningAlertsCount: int


class DashboardOverviewResponse(BaseModel):
    summary: MetricSummarySchema
    energy_balance: Dict[str, Any]
    active_alerts: List[Dict[str, Any]]
    recent_activity: List[Dict[str, Any]]
    system_status: str = "ONLINE"
    model_version: str = "RF-FORECAST v2.4"


# =============================================================================
# Energy Consumption
# =============================================================================
class HourlyConsumptionItem(BaseModel):
    time: str
    consumption: float
    predicted: Optional[float] = None
    baseline: Optional[float] = None
    isPeak: bool = False


class LocalityConsumptionItem(BaseModel):
    id: str
    name: str
    currentKw: float
    percentage: float
    trend: str = "stable"
    feederId: str
    transformerId: str


class ConsumptionCurrentResponse(BaseModel):
    totalCurrentKw: float
    baselineAverageKw: float
    peakStatus: str
    localities: List[LocalityConsumptionItem]
    hourlyCurve: List[HourlyConsumptionItem]


# =============================================================================
# Telemetry Ingestion & Query
# =============================================================================
class TelemetryRecord(BaseModel):
    substation_id: Optional[str] = None
    feeder_id: Optional[str] = None
    transformer_id: Optional[str] = None
    locality_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    active_power_kw: float
    reactive_power_kvar: float = 0.0
    voltage_kv: float = 11.0
    current_a: float = 0.0
    frequency_hz: float = 50.0
    power_factor: float = 0.98
    thd_percent: float = 2.1
    solar_generation_kw: float = 0.0
    source_type: str = "SIMULATED"


class TelemetryIngestRequest(BaseModel):
    records: List[TelemetryRecord]


# =============================================================================
# Equipment: Feeders & Transformers
# =============================================================================
class FeederItemSchema(BaseModel):
    id: str
    name: str
    substation: str
    locality: str
    demandKw: float
    voltageKv: float
    currentA: float
    feederLoadingPercentage: float
    powerFactor: float
    status: str  # ONLINE, STANDBY, TRIPPED
    breakerState: str  # CLOSED, OPEN
    protectionStatus: str  # NORMAL, ARMED, TRIPPED


class TransformerItemSchema(BaseModel):
    id: str
    name: str
    substation: str
    capacityKva: float
    currentLoadKva: float
    loadingPercentage: float
    voltageV: float
    currentA: float
    oilTempC: float
    windingTempC: float
    status: str  # normal, warning, critical
    coolingStatus: str  # AUTO, ON, STANDBY
    tapPosition: int
    lastInspection: str


# =============================================================================
# Machine Learning: Demand Prediction
# =============================================================================
class ForecastRequest(BaseModel):
    horizon: str = Field(default="30m", description="Lookahead: 15m, 30m, 1h, 2h, 6h, 24h")
    target_id: Optional[str] = "GRID_TOTAL"
    target_type: Optional[str] = "SUBSTATION"  # SUBSTATION, FEEDER, LOCALITY
    temperature_c: Optional[float] = 28.5
    industrial_activity_pct: Optional[float] = 100.0
    solar_offset_kw: Optional[float] = 350.0


class ForecastDataPoint(BaseModel):
    time: str
    actual: Optional[float] = None
    predicted: float
    upperBound: float
    lowerBound: float


class ForecastResponse(BaseModel):
    horizon: str
    predicted_demand_kw: float
    baseline_demand_kw: float
    growth_rate_pct: float
    model_version: str
    confidence_level: str
    r2_score: float
    mae_kw: float
    rmse_kw: float
    mape_pct: float
    conformal_quantile_kw: Optional[float] = None
    empirical_coverage_pct: Optional[float] = None
    data_sufficiency: Optional[str] = None
    forecast_timeline: List[ForecastDataPoint]


class PredictionVerificationLog(BaseModel):
    timestamp: str
    horizon: str
    actualKw: float
    predictedKw: float
    residualErrorKw: float
    mapePct: float
    status: str


# =============================================================================
# Machine Learning: Anomaly Detection
# =============================================================================
class AnomalyDetectRequest(BaseModel):
    feeder_id: Optional[str] = None
    transformer_id: Optional[str] = None
    active_power_kw: float
    voltage_kv: float
    current_a: float
    frequency_hz: float
    thd_percent: float


class AnomalyDetectResponse(BaseModel):
    is_anomaly: bool
    anomaly_score: float
    severity: str
    contributing_factors: List[str]
    equipment_code: str
    timestamp: str


# =============================================================================
# Surplus Management & Inter-Feeder Transfer
# =============================================================================
class TransferRecommendationSchema(BaseModel):
    id: str
    timestamp: str
    surplusLocality: str
    surplusFeeder: str
    availableSurplusKw: float
    shortageLocality: str
    shortageFeeder: str
    shortageDemandKw: float
    recommendedTransferKw: float
    transferRoute: str
    tieLineCapacityKw: float
    estimatedLossIncreaseKw: float
    voltageImpactDeltaV: float
    thermalHeadroomPercent: float
    status: str  # PENDING_APPROVAL, APPROVED, TRANSFER_INITIATED, ACTIVE_TRANSFER, COMPLETED, REJECTED
    deficitResolution: str  # FULLY_RESOLVED, PARTIALLY_RESOLVED, UNRESOLVED
    remainingDeficitKw: float
    approvedBy: Optional[str] = None
    approvedAt: Optional[str] = None


class TransferApprovalRequest(BaseModel):
    operator_name: str = "Lead Dispatcher"
    comments: Optional[str] = None
    override_constraints: bool = False


# =============================================================================
# BESS (Battery Energy Storage System)
# =============================================================================
class BessStateSchema(BaseModel):
    id: str
    name: str
    substation: str
    totalCapacityKwh: float = 10000.0  # 10 MWh
    currentEnergyKwh: float = 6840.0
    stateOfChargePct: float = 68.4
    stateOfHealthPct: float = 99.1
    currentPowerKw: float = -420.0  # Negative = Charging, Positive = Discharging
    maxChargePowerKw: float = 2000.0
    maxDischargePowerKw: float = 2000.0
    cellTemperatureC: float = 27.4
    operatingMode: str = "AUTO_AI"
    cycleCount: int = 142
    efficiencyPct: float = 93.8
    inverterStatus: str = "OPTIMAL"


class BessDispatchActionRequest(BaseModel):
    power_kw: float = Field(..., description="Positive for discharge (kW), Negative for charge (kW)")
    duration_hours: float = Field(default=0.5, ge=0.05, le=4.0)
    operator_name: str = "Lead Dispatcher"
    mode: Optional[str] = "MANUAL"


# =============================================================================
# What-If Simulator
# =============================================================================
class WhatIfRequest(BaseModel):
    demandChangePct: float = Field(default=0.0, ge=-40.0, le=40.0)
    solarPvGenerationKw: float = Field(default=350.0, ge=0.0, le=2500.0)
    industrialActivityPct: float = Field(default=100.0, ge=40.0, le=160.0)
    ambientTemperatureC: float = Field(default=28.5, ge=15.0, le=45.0)
    gridSupplyKw: float = Field(default=5400.0, ge=3000.0, le=8000.0)
    bessDispatchKw: float = Field(default=-420.0, ge=-2000.0, le=2000.0)


class WhatIfResponse(BaseModel):
    baseline_demand_kw: float
    adjusted_residential_kw: float
    adjusted_industrial_kw: float
    adjusted_commercial_kw: float
    total_consumer_demand_kw: float
    solar_pv_generation_kw: float
    net_grid_demand_kw: float
    incoming_grid_supply_kw: float
    network_losses_kw: float
    bess_power_kw: float
    net_usable_balance_kw: float
    grid_balance_status: str  # SURPLUS, DEFICIT, BALANCED
    feeder_loading_pct: float
    transformer_loading_pct: float
    grid_health_score: float
    dispatch_recommendation: str
    active_warnings: List[str]


# =============================================================================
# Alerts
# =============================================================================
class AlertSchema(BaseModel):
    id: str
    title: str
    description: str
    severity: str  # critical, warning, info
    timestamp: str
    sourceType: str
    sourceId: str
    sourceName: str
    isAcknowledged: bool
    isResolved: bool
    isRead: bool = False
    acknowledgedBy: Optional[str] = None
    resolvedAt: Optional[str] = None
    readAt: Optional[str] = None
