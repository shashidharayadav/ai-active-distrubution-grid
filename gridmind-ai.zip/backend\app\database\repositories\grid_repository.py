"""
GRIDMIND AI - In-Memory & Supabase Unified Repository
Provides high-fidelity operational storage for equipment, telemetry, alerts, transfers, BESS, and simulation.
When Supabase is connected, seamlessly synchronizes with Supabase PostgreSQL tables;
otherwise operates as a persistent in-memory repository store with BESCOM 11kV topology.
"""
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import copy
from app.database.connection import get_supabase_client
import logging

logger = logging.getLogger("gridmind.repository")


class GridRepository:
    def __init__(self):
        self._init_demo_data()

    def _init_demo_data(self):
        self.substations: List[Dict[str, Any]] = [
            {
                "id": "SUB-01",
                "substation_code": "BESCOM-110-N",
                "substation_name": "North Distribution Hub (110kV/11kV)",
                "location": "North Division Grid Sector 4",
                "nominal_voltage_kv": 11.04,
                "incoming_capacity_kw": 12000.0,
                "operational_status": "OPERATIONAL"
            },
            {
                "id": "SUB-02",
                "substation_code": "BESCOM-66-CYBER",
                "substation_name": "Cyber Corridor Substation (66kV/11kV)",
                "location": "Tech Park Industrial Corridor",
                "nominal_voltage_kv": 10.98,
                "incoming_capacity_kw": 8000.0,
                "operational_status": "OPERATIONAL"
            }
        ]

        self.feeders: List[Dict[str, Any]] = [
            {
                "id": "FDR-01",
                "name": "Feeder FDR-01 (Tech Park Primary)",
                "substation": "North Distribution Hub (110kV/11kV)",
                "locality": "Tech Park Cyber Corridor",
                "demandKw": 1350.0,
                "voltageKv": 11.02,
                "currentA": 71.5,
                "feederLoadingPercentage": 67.5,
                "powerFactor": 0.98,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "NORMAL",
                "rated_capacity_kw": 2000.0
            },
            {
                "id": "FDR-02",
                "name": "Feeder FDR-02 (Commercial Ring)",
                "substation": "North Distribution Hub (110kV/11kV)",
                "locality": "Downtown Commercial Center",
                "demandKw": 840.0,
                "voltageKv": 10.96,
                "currentA": 44.8,
                "feederLoadingPercentage": 56.0,
                "powerFactor": 0.97,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "NORMAL",
                "rated_capacity_kw": 1500.0
            },
            {
                "id": "FDR-03",
                "name": "Feeder FDR-03 (Heavy Industrial Line)",
                "substation": "Cyber Corridor Substation",
                "locality": "Heavy Industrial Estate",
                "demandKw": 1220.0,
                "voltageKv": 10.88,
                "currentA": 65.2,
                "feederLoadingPercentage": 81.3,
                "powerFactor": 0.95,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "ARMED",
                "rated_capacity_kw": 1500.0
            },
            {
                "id": "FDR-04",
                "name": "Feeder FDR-04 (Residential Valley)",
                "substation": "North Distribution Hub (110kV/11kV)",
                "locality": "North Residential Valley",
                "demandKw": 650.0,
                "voltageKv": 11.04,
                "currentA": 34.2,
                "feederLoadingPercentage": 54.2,
                "powerFactor": 0.99,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "NORMAL",
                "rated_capacity_kw": 1200.0
            },
            {
                "id": "FDR-05",
                "name": "Feeder FDR-05 (Transit & Depot)",
                "substation": "Cyber Corridor Substation",
                "locality": "Metro Transit & Railway Depot",
                "demandKw": 480.0,
                "voltageKv": 11.01,
                "currentA": 25.3,
                "feederLoadingPercentage": 48.0,
                "powerFactor": 0.98,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "NORMAL",
                "rated_capacity_kw": 1000.0
            },
            {
                "id": "FDR-06",
                "name": "Feeder FDR-06 (Healthcare City Express)",
                "substation": "North Distribution Hub (110kV/11kV)",
                "locality": "Greenfield Health Care City",
                "demandKw": 280.0,
                "voltageKv": 11.05,
                "currentA": 14.7,
                "feederLoadingPercentage": 35.0,
                "powerFactor": 0.99,
                "status": "ONLINE",
                "breakerState": "CLOSED",
                "protectionStatus": "NORMAL",
                "rated_capacity_kw": 800.0
            }
        ]

        self.transformers: List[Dict[str, Any]] = [
            {
                "id": "TR-101",
                "name": "North Substation Primary TR-1",
                "substation": "North Distribution Hub (110kV/11kV)",
                "capacityKva": 1250.0,
                "currentLoadKva": 890.0,
                "loadingPercentage": 71.2,
                "voltageV": 11020,
                "currentA": 46.7,
                "oilTempC": 54.2,
                "windingTempC": 62.1,
                "status": "normal",
                "coolingStatus": "AUTO",
                "tapPosition": 4,
                "lastInspection": "2026-10-28"
            },
            {
                "id": "TR-102",
                "name": "Tech Hub Distribution TR-2",
                "substation": "Cyber Corridor Substation",
                "capacityKva": 1600.0,
                "currentLoadKva": 1360.0,
                "loadingPercentage": 85.0,
                "voltageV": 10980,
                "currentA": 71.5,
                "oilTempC": 68.4,
                "windingTempC": 79.5,
                "status": "warning",
                "coolingStatus": "ON",
                "tapPosition": 5,
                "lastInspection": "2026-11-04"
            },
            {
                "id": "TR-103",
                "name": "Industrial Furnace Unit TR-3",
                "substation": "Cyber Corridor Substation",
                "capacityKva": 1500.0,
                "currentLoadKva": 1230.0,
                "loadingPercentage": 82.0,
                "voltageV": 10880,
                "currentA": 65.2,
                "oilTempC": 66.8,
                "windingTempC": 76.2,
                "status": "warning",
                "coolingStatus": "ON",
                "tapPosition": 3,
                "lastInspection": "2026-11-10"
            },
            {
                "id": "TR-104",
                "name": "Metro Rail Traction TR-4",
                "substation": "Cyber Corridor Substation",
                "capacityKva": 1000.0,
                "currentLoadKva": 520.0,
                "loadingPercentage": 52.0,
                "voltageV": 11010,
                "currentA": 27.3,
                "oilTempC": 48.3,
                "windingTempC": 54.0,
                "status": "normal",
                "coolingStatus": "AUTO",
                "tapPosition": 4,
                "lastInspection": "2026-10-15"
            },
            {
                "id": "TR-105",
                "name": "Valley Residential Unit TR-5",
                "substation": "North Distribution Hub (110kV/11kV)",
                "capacityKva": 1000.0,
                "currentLoadKva": 680.0,
                "loadingPercentage": 68.0,
                "voltageV": 11040,
                "currentA": 35.7,
                "oilTempC": 52.0,
                "windingTempC": 58.7,
                "status": "normal",
                "coolingStatus": "AUTO",
                "tapPosition": 4,
                "lastInspection": "2026-11-01"
            },
            {
                "id": "TR-106",
                "name": "Downtown Commercial TR-6",
                "substation": "North Distribution Hub (110kV/11kV)",
                "capacityKva": 1250.0,
                "currentLoadKva": 880.0,
                "loadingPercentage": 70.4,
                "voltageV": 10960,
                "currentA": 46.2,
                "oilTempC": 53.8,
                "windingTempC": 61.2,
                "status": "normal",
                "coolingStatus": "AUTO",
                "tapPosition": 4,
                "lastInspection": "2026-10-20"
            }
        ]

        self.localities: List[Dict[str, Any]] = [
            {"id": "LOC-01", "name": "Tech Park Cyber Corridor", "currentKw": 1350.0, "percentage": 28.0, "trend": "up", "feederId": "FDR-01", "transformerId": "TR-102"},
            {"id": "LOC-02", "name": "Heavy Industrial Estate", "currentKw": 1220.0, "percentage": 25.3, "trend": "stable", "feederId": "FDR-03", "transformerId": "TR-103"},
            {"id": "LOC-03", "name": "Downtown Commercial Center", "currentKw": 840.0, "percentage": 17.4, "trend": "up", "feederId": "FDR-02", "transformerId": "TR-106"},
            {"id": "LOC-04", "name": "North Residential Valley", "currentKw": 650.0, "percentage": 13.5, "trend": "down", "feederId": "FDR-04", "transformerId": "TR-105"},
            {"id": "LOC-05", "name": "Metro Transit & Railway Depot", "currentKw": 480.0, "percentage": 10.0, "trend": "stable", "feederId": "FDR-05", "transformerId": "TR-104"},
            {"id": "LOC-06", "name": "Greenfield Health Care City", "currentKw": 280.0, "percentage": 5.8, "trend": "up", "feederId": "FDR-06", "transformerId": "TR-101"}
        ]

        # 10 MWh BESS Unit
        self.bess_state: Dict[str, Any] = {
            "id": "BESS-01",
            "name": "Substation Central 10 MWh BESS Unit",
            "substation": "North Distribution Hub (110kV/11kV)",
            "totalCapacityKwh": 10000.0,
            "currentEnergyKwh": 6840.0,
            "stateOfChargePct": 68.4,
            "stateOfHealthPct": 99.1,
            "currentPowerKw": -420.0,  # Negative = Charging from active surplus
            "maxChargePowerKw": 2000.0,
            "maxDischargePowerKw": 2000.0,
            "cellTemperatureC": 27.4,
            "operatingMode": "AUTO_AI",
            "cycleCount": 142,
            "efficiencyPct": 93.8,
            "inverterStatus": "OPTIMAL"
        }

        self.bess_history: List[Dict[str, Any]] = [
            {
                "id": "EVT-BESS-001",
                "timestamp": "2026-11-16 14:00",
                "event": "Automated Solar Surplus Absorption",
                "type": "CHARGE",
                "powerKw": -420.0,
                "durationMinutes": 60,
                "energyKwh": 252.0,
                "initialSocPct": 65.9,
                "finalSocPct": 68.4,
                "dispatcher": "AI Dispatch Agent (Surplus Optimizer)"
            },
            {
                "id": "EVT-BESS-002",
                "timestamp": "2026-11-16 11:30",
                "event": "Peak Tariff Demand Shaving",
                "type": "DISCHARGE",
                "powerKw": 500.0,
                "durationMinutes": 45,
                "energyKwh": 375.0,
                "initialSocPct": 72.1,
                "finalSocPct": 68.4,
                "dispatcher": "AI Dispatch Agent (Peak Shaver)"
            }
        ]

        # Alerts (with strict ACTIVE -> RESOLVED -> READ lifecycle)
        self.alerts: List[Dict[str, Any]] = [
            {
                "id": "ALT-3091",
                "title": "Transformer TR-102 High Winding Temperature",
                "description": "Winding temperature reached 79.5°C approaching the 80°C threshold under 85% loading.",
                "severity": "warning",
                "timestamp": "12 mins ago",
                "sourceType": "TRANSFORMER",
                "sourceId": "TR-102",
                "sourceName": "Tech Hub Distribution TR-2",
                "isAcknowledged": False,
                "isResolved": False,
                "isRead": False
            },
            {
                "id": "ALT-3088",
                "title": "Feeder FDR-03 Peak Demand Surge",
                "description": "Feeder loading surged to 81.3% (1,220 kW) due to simultaneous industrial shift starts.",
                "severity": "warning",
                "timestamp": "28 mins ago",
                "sourceType": "FEEDER",
                "sourceId": "FDR-03",
                "sourceName": "Feeder FDR-03 (Heavy Industrial Line)",
                "isAcknowledged": False,
                "isResolved": False,
                "isRead": False
            },
            {
                "id": "ALT-3085",
                "title": "Transformer TR-103 Thermal Pre-Warning",
                "description": "Cooling fans activated automatically at 66.8°C oil temperature.",
                "severity": "warning",
                "timestamp": "45 mins ago",
                "sourceType": "TRANSFORMER",
                "sourceId": "TR-103",
                "sourceName": "Industrial Furnace Unit TR-3",
                "isAcknowledged": True,
                "isResolved": False,
                "isRead": False,
                "acknowledgedBy": "Lead Dispatcher"
            },
            {
                "id": "ALT-3079",
                "title": "Feeder FDR-06 Voltage Fluctuation",
                "description": "Voltage dipped to 10.82 kV temporarily before tap position adjustment restored 11.05 kV.",
                "severity": "info",
                "timestamp": "2 hours ago",
                "sourceType": "FEEDER",
                "sourceId": "FDR-06",
                "sourceName": "Feeder FDR-06 (Healthcare City Express)",
                "isAcknowledged": True,
                "isResolved": True,
                "isRead": True,
                "acknowledgedBy": "System Automation",
                "resolvedAt": "2 hours ago",
                "readAt": "1 hour ago"
            }
        ]

        # Transfer Recommendations
        self.transfer_recommendations: List[Dict[str, Any]] = [
            {
                "id": "REC-01",
                "timestamp": "22:50:00",
                "surplusLocality": "North Residential Valley",
                "surplusFeeder": "FDR-04 (Residential Valley)",
                "availableSurplusKw": 472.0,
                "shortageLocality": "Heavy Industrial Estate",
                "shortageFeeder": "FDR-03 (Heavy Industrial Line)",
                "shortageDemandKw": 160.0,
                "recommendedTransferKw": 160.0,
                "transferRoute": "FDR-04 (Tie Breaker T-1) → Tie Bus-B → FDR-03 Bus",
                "tieLineCapacityKw": 800.0,
                "estimatedLossIncreaseKw": 4.8,
                "voltageImpactDeltaV": 0.08,
                "thermalHeadroomPercent": 34.5,
                "status": "PENDING_APPROVAL",
                "deficitResolution": "FULLY_RESOLVED",
                "remainingDeficitKw": 0.0
            },
            {
                "id": "REC-02",
                "timestamp": "22:45:00",
                "surplusLocality": "Greenfield Health Care City",
                "surplusFeeder": "FDR-06 (Healthcare Express)",
                "availableSurplusKw": 120.0,
                "shortageLocality": "Downtown Commercial Center",
                "shortageFeeder": "FDR-02 (Commercial Ring)",
                "shortageDemandKw": 180.0,
                "recommendedTransferKw": 120.0,
                "transferRoute": "FDR-06 → Tie Breaker T-3 → Commercial Ring FDR-02",
                "tieLineCapacityKw": 600.0,
                "estimatedLossIncreaseKw": 3.2,
                "voltageImpactDeltaV": 0.05,
                "thermalHeadroomPercent": 42.0,
                "status": "APPROVED",
                "deficitResolution": "PARTIALLY_RESOLVED",
                "remainingDeficitKw": 60.0,
                "approvedBy": "Lead Dispatcher",
                "approvedAt": "22:46:12"
            }
        ]

        # Simulation History
        self.simulation_history: List[Dict[str, Any]] = []

    # Getters with live Supabase Persistence & Fallback
    def get_feeders(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("feeders").select("*").order("feeder_code").execute()
                if res.data:
                    # Update local state cache with database values
                    code_to_db = {r["feeder_code"]: r for r in res.data}
                    for f in self.feeders:
                        if f["id"] in code_to_db:
                            row = code_to_db[f["id"]]
                            f["name"] = row.get("feeder_name", f["name"])
                            f["status"] = row.get("operational_status", f["status"])
                            f["breakerState"] = row.get("breaker_state", f["breakerState"])
                            f["rated_capacity_kw"] = float(row.get("rated_capacity_kw", f.get("rated_capacity_kw", 2000.0)))
                    return copy.deepcopy(self.feeders)
            except Exception as e:
                logger.warning("Supabase get_feeders query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.feeders)

    def get_feeder_by_id(self, feeder_id: str) -> Optional[Dict[str, Any]]:
        feeders = self.get_feeders()
        for f in feeders:
            if f["id"] == feeder_id:
                return copy.deepcopy(f)
        return None

    def get_transformers(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("transformers").select("*").order("transformer_code").execute()
                if res.data:
                    code_to_db = {r["transformer_code"]: r for r in res.data}
                    for t in self.transformers:
                        if t["id"] in code_to_db:
                            row = code_to_db[t["id"]]
                            t["name"] = row.get("transformer_name", t["name"])
                            t["status"] = "CRITICAL" if row.get("operational_status") == "CRITICAL" else ("WARNING" if row.get("operational_status") == "WARNING" else "NORMAL")
                            t["tapPosition"] = int(row.get("tap_position", t["tapPosition"]))
                    return copy.deepcopy(self.transformers)
            except Exception as e:
                logger.warning("Supabase get_transformers query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.transformers)

    def get_transformer_by_id(self, transformer_id: str) -> Optional[Dict[str, Any]]:
        transformers = self.get_transformers()
        for t in transformers:
            if t["id"] == transformer_id:
                return copy.deepcopy(t)
        return None

    def get_localities(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("localities").select("*").order("locality_code").execute()
                if res.data:
                    code_to_db = {r["locality_code"]: r for r in res.data}
                    for l in self.localities:
                        if l["id"] in code_to_db:
                            row = code_to_db[l["id"]]
                            l["name"] = row.get("locality_name", l["name"])
                            l["contractedDemandKw"] = float(row.get("contracted_demand_kw", l.get("contractedDemandKw", 1000.0)))
                    return copy.deepcopy(self.localities)
            except Exception as e:
                logger.warning("Supabase get_localities query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.localities)

    def get_substations(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("substations").select("*").order("substation_code").execute()
                if res.data:
                    return [
                        {
                            "id": row["substation_code"],
                            "substation_code": row["substation_code"],
                            "substation_name": row["substation_name"],
                            "location": row["location"],
                            "nominal_voltage_kv": float(row["nominal_voltage_kv"]),
                            "incoming_capacity_kw": float(row["incoming_capacity_kw"]),
                            "operational_status": row["operational_status"]
                        }
                        for row in res.data
                    ]
            except Exception as e:
                logger.warning("Supabase get_substations query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.substations)

    def get_bess_state(self) -> Dict[str, Any]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("bess_units").select("*").limit(1).execute()
                if res.data:
                    b_row = res.data[0]
                    self.bess_state["name"] = b_row["bess_name"]
                    self.bess_state["totalCapacityKwh"] = float(b_row["capacity_kwh"])
                    self.bess_state["stateOfChargePct"] = float(b_row["current_soc_percent"])
                    self.bess_state["currentEnergyKwh"] = float(b_row["capacity_kwh"]) * float(b_row["current_soc_percent"]) / 100.0
                    self.bess_state["stateOfHealthPct"] = float(b_row["state_of_health_percent"])
                    self.bess_state["cellTemperatureC"] = float(b_row["temperature_c"])
                    self.bess_state["operatingMode"] = b_row["operating_mode"]
                    self.bess_state["efficiencyPct"] = float(b_row["charge_efficiency"]) * 100.0
            except Exception as e:
                logger.warning("Supabase get_bess_state query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.bess_state)

    def update_bess_state(self, updates: Dict[str, Any]) -> Dict[str, Any]:
        self.bess_state.update(updates)
        supabase = get_supabase_client()
        if supabase:
            try:
                db_updates = {}
                if "stateOfChargePct" in updates:
                    db_updates["current_soc_percent"] = updates["stateOfChargePct"]
                if "cellTemperatureC" in updates:
                    db_updates["temperature_c"] = updates["cellTemperatureC"]
                if "operatingMode" in updates:
                    db_updates["operating_mode"] = updates["operatingMode"]
                if db_updates:
                    supabase.table("bess_units").update(db_updates).neq("bess_name", "").execute()
            except Exception as e:
                logger.warning("Supabase update_bess_state failed (%s).", e)
        return copy.deepcopy(self.bess_state)

    def add_bess_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        self.bess_history.insert(0, event)
        supabase = get_supabase_client()
        if supabase:
            try:
                bess_res = supabase.table("bess_units").select("id").limit(1).execute()
                if bess_res.data:
                    bess_id = bess_res.data[0]["id"]
                    supabase.table("bess_events").insert({
                        "bess_id": bess_id,
                        "event_type": event.get("type", "CHARGE"),
                        "power_kw": float(event.get("powerKw", 0.0)),
                        "energy_kwh": float(event.get("energyKwh", 0.0)),
                        "previous_soc": float(event.get("initialSocPct", 60.0)),
                        "updated_soc": float(event.get("finalSocPct", 65.0)),
                        "duration_minutes": float(event.get("durationMinutes", 30.0)),
                        "event_source": event.get("dispatcher", "AI_DISPATCHER"),
                        "event_status": "COMPLETED"
                    }).execute()
            except Exception as e:
                logger.warning("Supabase add_bess_event insert failed (%s).", e)
        return event

    def get_bess_history(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("bess_events").select("*").order("timestamp", desc=True).limit(50).execute()
                if res.data:
                    events = []
                    for r in res.data:
                        events.append({
                            "id": str(r["id"])[:8],
                            "timestamp": r["timestamp"],
                            "event": f"BESS {r['event_type']} ({abs(float(r['power_kw']))} kW)",
                            "type": r["event_type"],
                            "powerKw": float(r["power_kw"]),
                            "durationMinutes": float(r["duration_minutes"]),
                            "energyKwh": float(r["energy_kwh"]),
                            "initialSocPct": float(r["previous_soc"]),
                            "finalSocPct": float(r["updated_soc"]),
                            "dispatcher": r.get("event_source", "AI_DISPATCHER")
                        })
                    return events
            except Exception as e:
                logger.warning("Supabase get_bess_history query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.bess_history)

    # Alerts Operations with Live Supabase Persistence
    def get_alerts(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        supabase_alerts = []
        supabase = get_supabase_client()
        if supabase:
            try:
                query = supabase.table("alerts").select("*")
                if status == "ACTIVE":
                    query = query.eq("status", "ACTIVE")
                elif status == "RESOLVED":
                    query = query.eq("status", "RESOLVED")
                res = query.order("detected_at", desc=True).execute()
                if res.data:
                    for r in res.data:
                        severity_str = r.get("severity", "warning").lower()
                        supabase_alerts.append({
                            "id": r["alert_code"],
                            "title": r["title"],
                            "description": r["description"],
                            "severity": severity_str if severity_str in ["critical", "warning", "info"] else "warning",
                            "timestamp": r["detected_at"],
                            "sourceType": r.get("alert_type", "SYSTEM").split("_")[0] if "_" in r.get("alert_type", "") else "SYSTEM",
                            "sourceId": str(r.get("feeder_id") or r.get("transformer_id") or r["alert_code"]),
                            "sourceName": r["title"].split("–")[-1].strip() if "–" in r["title"] else r["title"],
                            "isAcknowledged": bool(r.get("acknowledged_at")),
                            "isResolved": (r["status"] == "RESOLVED"),
                            "isRead": bool(r.get("is_read", False)),
                            "acknowledgedBy": r.get("acknowledged_by"),
                            "resolvedAt": r.get("resolved_at"),
                            "readAt": r.get("read_at")
                        })
            except Exception as e:
                logger.warning("Supabase get_alerts failed (%s); using local memory.", e)

        seen_ids = {a["id"] for a in supabase_alerts}
        local_candidates = [
            copy.deepcopy(a) for a in self.alerts
            if a["id"] not in seen_ids
        ]
        if status == "ACTIVE":
            local_filtered = [a for a in local_candidates if not a["isResolved"]]
        elif status == "RESOLVED":
            local_filtered = [a for a in local_candidates if a["isResolved"]]
        else:
            local_filtered = local_candidates

        return supabase_alerts + local_filtered

    def get_alert_by_id(self, alert_id: str) -> Optional[Dict[str, Any]]:
        alerts = self.get_alerts()
        for a in alerts:
            if a["id"] == alert_id:
                return a
        for a in self.alerts:
            if a["id"] == alert_id:
                return copy.deepcopy(a)
        return None

    def resolve_alert(self, alert_id: str) -> Optional[Dict[str, Any]]:
        now_iso = datetime.now(timezone.utc).isoformat()
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        # Update in-memory fallback
        for a in self.alerts:
            if a["id"] == alert_id:
                a["isResolved"] = True
                a["resolvedAt"] = now_str

        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("alerts").update({
                    "status": "RESOLVED",
                    "resolved_at": now_iso
                }).eq("alert_code", alert_id).execute()
                if res.data:
                    logger.info("Successfully persisted alert resolution in Supabase for %s", alert_id)
            except Exception as e:
                logger.warning("Supabase resolve_alert update failed (%s).", e)

        return self.get_alert_by_id(alert_id)

    def mark_alert_as_read(self, alert_id: str) -> Optional[Dict[str, Any]]:
        now_iso = datetime.now(timezone.utc).isoformat()
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

        for a in self.alerts:
            if a["id"] == alert_id:
                a["isRead"] = True
                a["readAt"] = now_str

        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("alerts").update({
                    "is_read": True,
                    "read_at": now_iso
                }).eq("alert_code", alert_id).execute()
                if res.data:
                    logger.info("Successfully persisted mark_alert_as_read in Supabase for %s", alert_id)
            except Exception as e:
                logger.warning("Supabase mark_alert_as_read update failed (%s).", e)

        return self.get_alert_by_id(alert_id)

    def mark_all_alerts_read(self) -> int:
        now_iso = datetime.now(timezone.utc).isoformat()
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        count = 0
        for a in self.alerts:
            if not a.get("isRead"):
                a["isRead"] = True
                a["readAt"] = now_str
                count += 1

        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("alerts").update({
                    "is_read": True,
                    "read_at": now_iso
                }).eq("is_read", False).execute()
                if res.data:
                    return len(res.data)
            except Exception as e:
                logger.warning("Supabase mark_all_alerts_read update failed (%s).", e)
        return count

    def acknowledge_alert(self, alert_id: str, operator_name: str = "Lead Dispatcher") -> Optional[Dict[str, Any]]:
        now_iso = datetime.now(timezone.utc).isoformat()
        for a in self.alerts:
            if a["id"] == alert_id:
                a["isAcknowledged"] = True
                a["acknowledgedBy"] = operator_name

        supabase = get_supabase_client()
        if supabase:
            try:
                supabase.table("alerts").update({
                    "acknowledged_at": now_iso,
                    "acknowledged_by": operator_name
                }).eq("alert_code", alert_id).execute()
            except Exception as e:
                logger.warning("Supabase acknowledge_alert update failed (%s).", e)

        return self.get_alert_by_id(alert_id)

    # Recommendations Operations
    def get_recommendations(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("transfer_recommendations").select("*").order("created_at", desc=True).execute()
                if res.data:
                    recs = []
                    for i, r in enumerate(res.data):
                        recs.append({
                            "id": f"REC-0{i+1}",
                            "db_id": str(r["id"]),
                            "timestamp": r["created_at"],
                            "surplusLocality": "Green Energy Agro Park" if i == 0 else "Tech Park Cyber Corridor",
                            "surplusFeeder": "FDR-06 (Solar Agri Feeder)" if i == 0 else "FDR-01 (Tech Park Primary)",
                            "availableSurplusKw": float(r["source_surplus_kw"]),
                            "shortageLocality": "Heavy Industrial Estate" if i == 0 else "Downtown Commercial Center",
                            "shortageFeeder": "FDR-03 (Heavy Industrial Line)" if i == 0 else "FDR-02 (Commercial Ring)",
                            "shortageDemandKw": float(r["destination_deficit_kw"]),
                            "recommendedTransferKw": float(r["recommended_transfer_kw"]),
                            "transferRoute": r["route"],
                            "tieLineCapacityKw": 600.0,
                            "estimatedLossIncreaseKw": float(r["estimated_losses_kw"]),
                            "voltageImpactDeltaV": 0.05,
                            "thermalHeadroomPercent": 38.0,
                            "status": r["operator_status"],
                            "deficitResolution": r["deficit_resolution_status"],
                            "remainingDeficitKw": max(0.0, float(r["destination_deficit_kw"]) - float(r["recommended_transfer_kw"])),
                            "approvedBy": r.get("approved_by"),
                            "approvedAt": r.get("approved_at")
                        })
                    return recs
            except Exception as e:
                logger.warning("Supabase get_recommendations query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.transfer_recommendations)

    def get_recommendation_by_id(self, rec_id: str) -> Optional[Dict[str, Any]]:
        recs = self.get_recommendations()
        for r in recs:
            if r["id"] == rec_id or r.get("db_id") == rec_id:
                return r
        return None

    def update_recommendation_status(
        self,
        rec_id: str,
        status: str,
        operator_name: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        now_iso = datetime.now(timezone.utc).isoformat()
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        # Update in-memory
        for r in self.transfer_recommendations:
            if r["id"] == rec_id:
                r["status"] = status
                if operator_name:
                    r["approvedBy"] = operator_name
                    r["approvedAt"] = now_str

        supabase = get_supabase_client()
        if supabase:
            try:
                updates = {"operator_status": status, "updated_at": now_iso}
                if operator_name:
                    updates["approved_by"] = operator_name
                    updates["approved_at"] = now_iso
                supabase.table("transfer_recommendations").update(updates).neq("route", "").execute()
                logger.info("Successfully persisted recommendation status %s on Supabase", status)
            except Exception as e:
                logger.warning("Supabase update_recommendation_status failed (%s).", e)

        return self.get_recommendation_by_id(rec_id)

    # Simulation History Persistence
    def add_simulation_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        self.simulation_history.insert(0, record)
        supabase = get_supabase_client()
        if supabase:
            try:
                supabase.table("simulation_history").insert({
                    "user_id": record.get("userId", "Dispatcher-Lead"),
                    "scenario_name": record.get("scenarioName", "What-If Sandbox Scenario"),
                    "input_parameters": record.get("inputParams", {}),
                    "output_results": record.get("outputResults", {})
                }).execute()
                logger.info("Successfully persisted What-If simulation record in Supabase")
            except Exception as e:
                logger.warning("Supabase add_simulation_record failed (%s).", e)
        return record

    def get_simulation_history(self) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("simulation_history").select("*").order("created_at", desc=True).limit(20).execute()
                if res.data:
                    return [
                        {
                            "id": str(r["id"])[:8],
                            "scenarioName": r["scenario_name"],
                            "timestamp": r["created_at"],
                            "inputParams": r["input_parameters"],
                            "outputResults": r["output_results"],
                            "userId": r.get("user_id", "Dispatcher-Lead")
                        }
                        for r in res.data
                    ]
            except Exception as e:
                logger.warning("Supabase get_simulation_history query failed (%s); using in-memory store.", e)
        return copy.deepcopy(self.simulation_history)

    # Telemetry Ingest & Query
    def save_telemetry_reading(self, reading: Dict[str, Any]) -> bool:
        supabase = get_supabase_client()
        if supabase:
            try:
                supabase.table("grid_telemetry").insert(reading).execute()
                return True
            except Exception as e:
                logger.warning("Supabase save_telemetry_reading failed (%s).", e)
        return False

    def get_telemetry_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("grid_telemetry").select("*").order("timestamp", desc=True).limit(limit).execute()
                if res.data:
                    return res.data
            except Exception as e:
                logger.warning("Supabase get_telemetry_history failed (%s).", e)
        return []

    # Demand Prediction Persistence
    def save_demand_prediction(self, prediction: Dict[str, Any]) -> bool:
        supabase = get_supabase_client()
        if supabase:
            try:
                supabase.table("demand_predictions").insert(prediction).execute()
                return True
            except Exception as e:
                logger.warning("Supabase save_demand_prediction failed (%s).", e)
        return False

    def get_demand_predictions(self, limit: int = 10) -> List[Dict[str, Any]]:
        supabase = get_supabase_client()
        if supabase:
            try:
                res = supabase.table("demand_predictions").select("*").order("prediction_timestamp", desc=True).limit(limit).execute()
                if res.data:
                    return res.data
            except Exception as e:
                logger.warning("Supabase get_demand_predictions failed (%s).", e)
        return []


# Singleton instance
grid_repo = GridRepository()
