"""
GRIDMIND AI — AI-Driven Active Distribution Grid Monitoring & Optimization
FastAPI Backend Application Entrypoint
Hackathon Theme: BESCOM AI-Driven Active Distribution Grid
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.api.routes import (
    dashboard,
    consumption,
    telemetry,
    feeders,
    transformers,
    substations,
    demand_prediction,
    anomalies,
    surplus_management,
    bess,
    simulator,
    alerts,
    history
)
from app.database.connection import get_supabase_client
from app.ml.demand_model import demand_predictor
from app.ml.anomaly_model import anomaly_detector
import logging

logging.basicConfig(
    level=settings.LOG_LEVEL,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("gridmind.main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing GRIDMIND AI backend...")
    # Initialize Supabase client if configured
    get_supabase_client()
    # Ensure ML models are loaded / trained
    if demand_predictor.model is None:
        logger.info("Training initial Random Forest demand model...")
        demand_predictor.train_and_save()
    if anomaly_detector.model is None:
        logger.info("Training initial Isolation Forest anomaly detector...")
        anomaly_detector.train_and_save()
    logger.info("GRIDMIND AI backend successfully initialized and ready for operations.")
    yield
    logger.info("Shutting down GRIDMIND AI backend.")


app = FastAPI(
    title=settings.PROJECT_NAME,
    description="BESCOM Theme: AI-Driven Active Distribution Grid Monitoring, Demand Prediction, Surplus Management & Optimization",
    version="2.4.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Configuration for Frontend Development & Testing
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_origin_regex=r"https://.*\.vercel\.app",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount all API Routers under /api/v1
app.include_router(dashboard.router, prefix=settings.API_V1_STR)
app.include_router(consumption.router, prefix=settings.API_V1_STR)
app.include_router(telemetry.router, prefix=settings.API_V1_STR)
app.include_router(feeders.router, prefix=settings.API_V1_STR)
app.include_router(transformers.router, prefix=settings.API_V1_STR)
app.include_router(substations.router, prefix=settings.API_V1_STR)
app.include_router(demand_prediction.router, prefix=settings.API_V1_STR)
app.include_router(anomalies.router, prefix=settings.API_V1_STR)
app.include_router(surplus_management.router, prefix=settings.API_V1_STR)
app.include_router(bess.router, prefix=settings.API_V1_STR)
app.include_router(simulator.router, prefix=settings.API_V1_STR)
app.include_router(alerts.router, prefix=settings.API_V1_STR)
app.include_router(history.router, prefix=settings.API_V1_STR)


@app.get("/", tags=["Health"])
def root():
    return {
        "project": "GRIDMIND AI",
        "theme": "BESCOM AI-Driven Active Distribution Grid",
        "status": "OPERATIONAL",
        "version": "2.4.0",
        "docs_url": "/docs",
        "api_v1_prefix": settings.API_V1_STR
    }


@app.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "HEALTHY",
        "system": "GRIDMIND Active Distribution Grid Core",
        "ml_models": {
            "random_forest_demand": "ACTIVE",
            "isolation_forest_anomaly": "ACTIVE"
        }
    }
