"""
GRIDMIND AI - Substations Monitoring API Routes
"""
from fastapi import APIRouter
from typing import List, Dict, Any
from app.database.repositories.grid_repository import grid_repo

router = APIRouter(prefix="/substations", tags=["Substations"])


@router.get("", response_model=List[Dict[str, Any]])
def list_substations():
    return grid_repo.get_substations()
