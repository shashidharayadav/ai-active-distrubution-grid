import React, { useState } from 'react';
import {
  GitBranch,
  Zap,
  Activity,
  AlertTriangle,
  ShieldCheck,
} from 'lucide-react';
import { Card } from '../components/common/Card';
import { MetricCard } from '../components/common/MetricCard';
import { StatusBadge } from '../components/common/StatusBadge';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { mockFeeders } from '../data/mockData';
import type { FeederItem } from '../types';

export const Feeders: React.FC = () => {
  const [feeders, setFeeders] = useState<FeederItem[]>(mockFeeders);
  const [toggleModalFeeder, setToggleModalFeeder] = useState<FeederItem | null>(null);

  // Breaker switch action simulation
  const handleToggleBreaker = () => {
    if (!toggleModalFeeder) return;
    setFeeders((prev) =>
      prev.map((f) => {
        if (f.id === toggleModalFeeder.id) {
          const newBreakerState = f.breakerState === 'CLOSED' ? 'OPEN' : 'CLOSED';
          const newStatus = newBreakerState === 'CLOSED' ? 'ONLINE' : 'STANDBY';
          return {
            ...f,
            breakerState: newBreakerState,
            status: newStatus,
            demandKw: newBreakerState === 'CLOSED' ? 450 : 0,
            feederLoadingPercentage: newBreakerState === 'CLOSED' ? 35 : 0,
          };
        }
        return f;
      })
    );
    setToggleModalFeeder(null);
  };

  const totalDemand = feeders.reduce((acc, curr) => acc + curr.demandKw, 0);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#F8FAFC]">
            Distribution Feeder Operations & Load Balancing
          </h2>
          <p className="text-xs text-[#A9B8C8] mt-1">
            Real-time 11kV radial line demand, vacuum circuit breaker states, and tie-switch control
          </p>
        </div>
      </div>

      {/* Summary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Feeder Demand"
          value={totalDemand.toLocaleString()}
          unit="kW"
          icon={Zap}
          subtitle="Sum of active distribution lines"
          accent="teal"
        />
        <MetricCard
          title="Active Operational Feeders"
          value={`${feeders.filter((f) => f.status === 'ONLINE').length}/${feeders.length}`}
          unit="Online"
          icon={GitBranch}
          subtitle="1 Standby Tie-Feeder Available"
          accent="emerald"
        />
        <MetricCard
          title="Peak Loaded Feeder"
          value="FDR-03"
          unit="81.3%"
          icon={AlertTriangle}
          subtitle="Heavy Industrial Belt Line"
          accent="amber"
        />
        <MetricCard
          title="Average Feeder Power Factor"
          value="0.98"
          unit="Lagging"
          icon={Activity}
          subtitle="High efficiency power factor"
          accent="teal"
        />
      </div>

      {/* Feeder Comparison Table & Breaker Control */}
      <Card
        title="11kV Distribution Feeders Roster"
        subtitle="Live voltage, current draw, breaker position, and protection status"
        highlight="teal"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-[#34495E] text-[#A9B8C8] text-[11px] uppercase">
                <th className="pb-3 font-medium">Feeder Identifier</th>
                <th className="pb-3 font-medium">Connected Locality</th>
                <th className="pb-3 font-medium">Voltage (kV)</th>
                <th className="pb-3 font-medium">Current (A)</th>
                <th className="pb-3 font-medium">Active Load (kW)</th>
                <th className="pb-3 font-medium">Loading (%)</th>
                <th className="pb-3 font-medium">Power Factor</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium text-right">Breaker Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#34495E]/60">
              {feeders.map((fdr) => (
                <tr key={fdr.id} className="hover:bg-[#263B50]/30 transition-colors">
                  <td className="py-3 font-mono font-bold text-[#20A99E]">{fdr.id}</td>
                  <td className="py-3 font-medium text-[#F8FAFC]">
                    <div>{fdr.locality}</div>
                    <span className="text-[10px] text-[#A9B8C8]">{fdr.substation}</span>
                  </td>
                  <td className="py-3 font-mono text-[#F8FAFC]">{fdr.voltageKv} kV</td>
                  <td className="py-3 font-mono text-[#F8FAFC]">{fdr.currentA} A</td>
                  <td className="py-3 font-semibold text-[#20A99E]">{fdr.demandKw} kW</td>
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-[#152538] rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            fdr.feederLoadingPercentage >= 80
                              ? 'bg-[#F5B942]'
                              : 'bg-[#35C99A]'
                          }`}
                          style={{ width: `${fdr.feederLoadingPercentage}%` }}
                        />
                      </div>
                      <span className="text-[11px] font-semibold text-[#F8FAFC]">
                        {fdr.feederLoadingPercentage}%
                      </span>
                    </div>
                  </td>
                  <td className="py-3 text-[#A9B8C8] font-mono">{fdr.powerFactor}</td>
                  <td className="py-3">
                    <StatusBadge
                      status={fdr.status === 'ONLINE' ? 'normal' : 'warning'}
                      label={fdr.status}
                      size="sm"
                    />
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => setToggleModalFeeder(fdr)}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-all ${
                        fdr.breakerState === 'CLOSED'
                          ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/40 hover:bg-[#35C99A]/25'
                          : 'bg-[#A9B8C8]/15 text-[#A9B8C8] border-[#A9B8C8]/30 hover:bg-[#A9B8C8]/25'
                      }`}
                    >
                      <span>{fdr.breakerState === 'CLOSED' ? 'CB CLOSED' : 'CB OPEN'}</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Feeder Load Balancing Visual */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card
          title="Feeder Load Distribution"
          subtitle="Relative demand comparison among active feeders"
        >
          <div className="space-y-3">
            {feeders.slice(0, 5).map((f) => (
              <div key={f.id} className="p-2.5 rounded-lg bg-[#152538] border border-[#34495E]">
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="text-[#F8FAFC] font-semibold">{f.id} — {f.locality}</span>
                  <span className="text-[#20A99E] font-bold">{f.demandKw} kW</span>
                </div>
                <div className="h-1.5 w-full bg-[#101C2C] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#20A99E] rounded-full"
                    style={{ width: `${(f.demandKw / 1500) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card
          title="Breaker Interlock & Protection Status"
          subtitle="IEC 61850 GOOSE trip signals & automated islanding safety"
        >
          <div className="space-y-3 text-xs text-[#A9B8C8]">
            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#35C99A]" />
                <span className="text-[#F8FAFC] font-medium">Overcurrent (50/51) Protection:</span>
              </div>
              <span className="text-[#35C99A] font-semibold">ALL ARMED</span>
            </div>

            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#35C99A]" />
                <span className="text-[#F8FAFC] font-medium">Earth Fault (51N) Relay:</span>
              </div>
              <span className="text-[#35C99A] font-semibold">ENABLED</span>
            </div>

            <div className="p-3 rounded-lg bg-[#152538] border border-[#34495E] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#35C99A]" />
                <span className="text-[#F8FAFC] font-medium">Automated Tie-Switch Interlock:</span>
              </div>
              <span className="text-[#20A99E] font-semibold">READY</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Breaker Switch Safety Confirmation Modal */}
      {toggleModalFeeder && (
        <Modal
          isOpen={!!toggleModalFeeder}
          onClose={() => setToggleModalFeeder(null)}
          title={`Confirm Breaker Switch: ${toggleModalFeeder.id}`}
          subtitle={`Line: ${toggleModalFeeder.name} (${toggleModalFeeder.locality})`}
          maxWidth="md"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3.5 rounded-xl bg-[#F5B942]/15 border border-[#F5B942]/30 text-[#F5B942] flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Manual SCADA Switching Command</span>
                <p className="text-[11px] text-[#A9B8C8] mt-1">
                  You are about to simulate changing circuit breaker state from{' '}
                  <strong className="text-[#F8FAFC]">{toggleModalFeeder.breakerState}</strong> to{' '}
                  <strong className="text-[#F8FAFC]">
                    {toggleModalFeeder.breakerState === 'CLOSED' ? 'OPEN' : 'CLOSED'}
                  </strong>
                  . This will {toggleModalFeeder.breakerState === 'CLOSED' ? 'de-energize' : 'energize'} the
                  downstream distribution circuit.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="ghost" size="sm" onClick={() => setToggleModalFeeder(null)}>
                Cancel
              </Button>
              <Button
                variant={toggleModalFeeder.breakerState === 'CLOSED' ? 'danger' : 'primary'}
                size="sm"
                onClick={handleToggleBreaker}
              >
                Execute {toggleModalFeeder.breakerState === 'CLOSED' ? 'Trip / Open' : 'Close / Energize'}
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
