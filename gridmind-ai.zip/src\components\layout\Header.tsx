import React, { useState, useEffect } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import {
  Menu,
  Bell,
  Sparkles,
  Clock,
  LogOut,
  ChevronDown,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Info
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useAlerts } from '../../context/AlertsContext';
import { mockGridSummary } from '../../data/mockData';

interface HeaderProps {
  onOpenMobile: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMobile }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const [currentTime, setCurrentTime] = useState<string>('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Map route to title & breadcrumbs
  const getPageInfo = () => {
    switch (location.pathname) {
      case '/dashboard':
        return { title: 'Operational Dashboard', breadcrumb: 'Overview' };
      case '/grid-monitoring':
        return { title: 'Grid Monitoring & Telemetry', breadcrumb: 'Distribution Network' };
      case '/consumption':
        return { title: 'Electricity Consumption Analytics', breadcrumb: 'Load Profiles' };
      case '/demand-prediction':
        return { title: 'AI Demand Prediction (Random Forest)', breadcrumb: 'Predictive Intelligence' };
      case '/transformers':
        return { title: 'Transformer Fleet Monitoring', breadcrumb: 'Asset Health' };
      case '/feeders':
        return { title: 'Feeder Operations & Loading', breadcrumb: 'Feeders & Topology' };
      case '/alerts':
        return { title: 'Alerts & Alarm Management', breadcrumb: 'Incident Queue' };
      case '/reports':
        return { title: 'Reports & Export Analytics', breadcrumb: 'System Intelligence' };
      case '/settings':
        return { title: 'System & Threshold Settings', breadcrumb: 'Configuration' };
      default:
        return { title: 'Grid Operations', breadcrumb: 'System' };
    }
  };

  const { title, breadcrumb } = getPageInfo();
  const { alerts, unreadCount, markAsRead, markAllAsRead } = useAlerts();
  const displayAlerts = [...alerts].sort((a, b) => {
    // Show unread first, then unresolved, then by time
    if (!a.isRead && b.isRead) return -1;
    if (a.isRead && !b.isRead) return 1;
    return 0;
  }).slice(0, 4);

  return (
    <header className="sticky top-0 z-20 h-16 bg-[#152538]/95 backdrop-blur-md border-b border-[#34495E] px-4 lg:px-8 flex items-center justify-between">
      {/* Left: Mobile Toggle & Page Title */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onOpenMobile}
          className="lg:hidden p-2 rounded-lg text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] shrink-0"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="min-w-0">
          <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-[11px] text-[#A9B8C8] truncate">
            <Link to="/dashboard" className="hover:text-[#20A99E] transition-colors shrink-0">
              GRIDMIND
            </Link>
            <span>/</span>
            <span className="text-[#20A99E] font-medium truncate">{breadcrumb}</span>
          </div>
          <h1 className="text-sm sm:text-base lg:text-lg font-bold text-[#F8FAFC] tracking-tight truncate">
            {title}
          </h1>
        </div>
      </div>

      {/* Right: Status Telemetry, AI Heartbeat, Notifications, Profile */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Live Grid Metrics Pill (Desktop) */}
        <div className="hidden xl:flex items-center gap-3 px-3 py-1.5 rounded-lg bg-[#101C2C] border border-[#34495E] text-xs">
          <div className="flex items-center gap-1.5 text-[#35C99A]">
            <span className="w-2 h-2 rounded-full bg-[#35C99A] animate-pulse" />
            <span className="font-semibold">{mockGridSummary.frequencyHz} Hz</span>
          </div>
          <div className="h-3 w-px bg-[#34495E]" />
          <div className="text-[#A9B8C8]">
            <span>V: </span>
            <span className="text-[#F8FAFC] font-semibold">{mockGridSummary.voltageKv} kV</span>
          </div>
          <div className="h-3 w-px bg-[#34495E]" />
          <div className="text-[#A9B8C8]">
            <span>PF: </span>
            <span className="text-[#F8FAFC] font-semibold">{mockGridSummary.powerFactor}</span>
          </div>
        </div>

        {/* AI Model Active Tag */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#9585F5]/10 border border-[#9585F5]/30 text-xs text-[#9585F5]">
          <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          <span className="font-semibold text-[11px] tracking-wide">RF-FORECAST v2.4</span>
        </div>

        {/* System Clock */}
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-[#A9B8C8] px-2 py-1 font-mono">
          <Clock className="w-3.5 h-3.5 text-[#20A99E]" />
          <span>{currentTime || '22:50:00'}</span>
        </div>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowUserMenu(false);
            }}
            className="relative p-2 rounded-lg text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] transition-colors"
            title="Grid Alerts & Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-[#F16F75] text-[#F8FAFC] text-[10px] font-bold flex items-center justify-center border-2 border-[#152538] shadow-sm animate-pulse">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-xl bg-[#1D3045] border border-[#34495E] shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-3 border-b border-[#34495E]">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-semibold text-[#F8FAFC]">Alerts & Events</h4>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                    unreadCount > 0 
                      ? 'bg-[#F16F75]/20 text-[#F16F75] border-[#F16F75]/30' 
                      : 'bg-[#35C99A]/20 text-[#35C99A] border-[#35C99A]/30'
                  }`}>
                    {unreadCount > 0 ? `${unreadCount} Unread` : 'All Read'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      onClick={() => markAllAsRead()}
                      className="text-[11px] text-[#20A99E] hover:underline cursor-pointer"
                    >
                      Mark All Read
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setShowNotifications(false);
                      navigate('/alerts');
                    }}
                    className="text-xs text-[#20A99E] hover:underline cursor-pointer"
                  >
                    View All
                  </button>
                </div>
              </div>

              <div className="divide-y divide-[#34495E]/60 my-2 max-h-72 overflow-y-auto">
                {displayAlerts.length === 0 ? (
                  <div className="py-6 text-center text-xs text-[#A9B8C8]">
                    No notifications in queue.
                  </div>
                ) : (
                  displayAlerts.map((alt) => (
                    <div key={alt.id} className="py-2.5 flex items-start gap-2.5">
                      {alt.severity === 'critical' ? (
                        <AlertTriangle className="w-4 h-4 text-[#F16F75] shrink-0 mt-0.5" />
                      ) : alt.severity === 'warning' ? (
                        <AlertTriangle className="w-4 h-4 text-[#F5B942] shrink-0 mt-0.5" />
                      ) : (
                        <Info className="w-4 h-4 text-[#9585F5] shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-xs font-medium text-[#F8FAFC] truncate">{alt.title}</p>
                          {alt.isResolved ? (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#35C99A]/20 text-[#35C99A] border border-[#35C99A]/30">
                              RESOLVED
                            </span>
                          ) : (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-[#F16F75]/20 text-[#F16F75] border border-[#F16F75]/30">
                              ACTIVE
                            </span>
                          )}
                          {!alt.isRead ? (
                            <span className="text-[9px] font-semibold px-1 py-0.2 rounded bg-[#20A99E]/20 text-[#20A99E]">
                              UNREAD
                            </span>
                          ) : (
                            <span className="text-[9px] text-[#A9B8C8]/60">READ</span>
                          )}
                        </div>
                        <p className="text-[11px] text-[#A9B8C8] line-clamp-1 mt-0.5">
                          {alt.description}
                        </p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[10px] text-[#A9B8C8]/70">
                            {alt.timestamp}
                          </span>
                          {/* If alert is resolved and unread, allow marking as read right from header popover */}
                          {alt.isResolved && !alt.isRead && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                markAsRead(alt.id);
                              }}
                              className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#20A99E]/20 text-[#20A99E] hover:bg-[#20A99E] hover:text-[#101C2C] border border-[#20A99E]/30 transition-all cursor-pointer"
                            >
                              Mark as Read
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="pt-2 border-t border-[#34495E]">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    navigate('/alerts');
                  }}
                  className="w-full py-1.5 rounded-lg bg-[#263B50] hover:bg-[#34495E] text-xs font-semibold text-[#20A99E] transition-colors text-center cursor-pointer"
                >
                  Go to Alert Dispatch Queue →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowUserMenu(!showUserMenu);
              setShowNotifications(false);
            }}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-[#263B50] transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#20A99E] to-[#9585F5] p-0.5">
              <div className="w-full h-full rounded-full bg-[#152538] flex items-center justify-center text-xs font-bold text-[#F8FAFC]">
                {user?.name ? user.name.slice(0, 2).toUpperCase() : 'OP'}
              </div>
            </div>
            <div className="hidden md:block text-left">
              <p className="text-xs font-semibold text-[#F8FAFC] leading-tight">
                {user?.name || 'Operator'}
              </p>
              <p className="text-[10px] text-[#A9B8C8] leading-tight">{user?.role || 'Dispatcher'}</p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-[#A9B8C8] hidden md:block" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#1D3045] border border-[#34495E] shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95">
              <div className="px-3 py-2 border-b border-[#34495E] mb-1">
                <p className="text-xs font-semibold text-[#F8FAFC]">{user?.name || 'Operator'}</p>
                <p className="text-[11px] text-[#A9B8C8] truncate">
                  {user?.email || 'operator@gridmind.ai'}
                </p>
                <div className="mt-1 flex items-center gap-1 text-[10px] text-[#35C99A]">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{user?.role || 'Grid Dispatcher'}</span>
                </div>
              </div>

              <Link
                to="/landing"
                onClick={() => setShowUserMenu(false)}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] transition-colors"
              >
                <ExternalLink className="w-4 h-4 text-[#9585F5]" />
                <span>Public Landing Page</span>
              </Link>

              <Link
                to="/settings"
                onClick={() => setShowUserMenu(false)}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-[#A9B8C8] hover:text-[#F8FAFC] hover:bg-[#263B50] transition-colors"
              >
                <CheckCircle2 className="w-4 h-4 text-[#20A99E]" />
                <span>Operational Settings</span>
              </Link>

              <div className="my-1 border-t border-[#34495E]" />

              <button
                onClick={() => {
                  setShowUserMenu(false);
                  logout();
                  navigate('/login');
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-[#F16F75] hover:bg-[#F16F75]/10 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out of Console</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
