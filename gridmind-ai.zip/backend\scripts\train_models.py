"""
GRIDMIND AI - Offline Model Training & Serialization Script
Trains and serializes:
1. RandomForestDemandPredictor -> app/ml/saved_models/random_forest_demand.joblib
2. IsolationForestAnomalyDetector -> app/ml/saved_models/isolation_forest_anomaly.joblib
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.ml.demand_model import demand_predictor
from app.ml.anomaly_model import anomaly_detector
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("gridmind.train")


def main():
    logger.info("Starting training of GRIDMIND AI Machine Learning models...")

    logger.info("1/2 Training Random Forest Demand Regressor...")
    rf_meta = demand_predictor.train_and_save()
    logger.info("Random Forest trained: R2=%.4f, MAE=%.2f kW, MAPE=%.2f%%",
                rf_meta["evaluation_metrics"]["r2_score"],
                rf_meta["evaluation_metrics"]["mae_kw"],
                rf_meta["evaluation_metrics"]["mape_pct"])

    logger.info("2/2 Training Isolation Forest Telemetry Anomaly Detector...")
    iso_res = anomaly_detector.train_and_save()
    logger.info("Isolation Forest trained: Status=%s", iso_res["status"])

    logger.info("All ML models successfully trained and persisted in app/ml/saved_models/.")


if __name__ == "__main__":
    main()
