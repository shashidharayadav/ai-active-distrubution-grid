import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Zap,
  BrainCircuit,
  ShieldCheck,
  Gauge,
  Cpu,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  Radio,
  CheckCircle2,
  ChevronRight,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/common/Button';
import { Modal } from '../components/common/Modal';
import { ElectricityGridCanvas } from '../components/landing/ElectricityGridCanvas';

type OperatorRole = 'Lead Dispatcher' | 'Substation Engineer';

export const LandingLoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  // Selected Role & Form States
  const [selectedRole, setSelectedRole] = useState<OperatorRole>('Lead Dispatcher');
  const [email, setEmail] = useState<string>('dispatcher@gridmind.ai');
  const [password, setPassword] = useState<string>('DemoPass2026!');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [error, setError] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Forgot password modal
  const [forgotModalOpen, setForgotModalOpen] = useState<boolean>(false);
  const [forgotEmail, setForgotEmail] = useState<string>('');
  const [forgotSent, setForgotSent] = useState<boolean>(false);

  // Mouse Parallax Position Normalized [-1, 1]
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Update email automatically when switching role if still default
  const handleRoleSelect = (role: OperatorRole) => {
    setSelectedRole(role);
    if (email === 'dispatcher@gridmind.ai' || email === 'engineer@gridmind.ai' || !email) {
      setEmail(role === 'Lead Dispatcher' ? 'dispatcher@gridmind.ai' : 'engineer@gridmind.ai');
    }
  };

  // Mouse movement parallax tracker
  useEffect(() => {
    let animationFrame: number;
    const handleMouseMove = (e: MouseEvent) => {
      animationFrame = requestAnimationFrame(() => {
        const normX = (e.clientX / window.innerWidth) * 2 - 1;
        const normY = (e.clientY / window.innerHeight) * 2 - 1;
        setMousePos({ x: normX, y: normY });
      });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrame);
    };
  }, []);

  // Form submit handler
  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email) {
      setError('Please provide your operator email address.');
      return;
    }
    if (!password) {
      setError('Please provide your authentication password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      login(email, selectedRole);
      setIsLoading(false);
      // Lead Dispatcher -> Dashboard; Substation Engineer -> Grid Monitoring
      const targetPath = selectedRole === 'Substation Engineer' ? '/grid-monitoring' : '/dashboard';
      navigate(targetPath);
    }, 500);
  };

  // 1-Click Instant Demo Access
  const handleInstantDemo = (role: OperatorRole) => {
    setSelectedRole(role);
    const demoEmail = role === 'Lead Dispatcher' ? 'dispatcher@gridmind.ai' : 'engineer@gridmind.ai';
    setEmail(demoEmail);
    setPassword('DemoPass2026!');
    setIsLoading(true);

    setTimeout(() => {
      login(demoEmail, role);
      setIsLoading(false);
      const targetPath = role === 'Substation Engineer' ? '/grid-monitoring' : '/dashboard';
      navigate(targetPath);
    }, 350);
  };

  return (
    <div className="min-h-screen bg-[#101C2C] text-[#F8FAFC] relative overflow-x-hidden flex flex-col justify-between selection:bg-[#20A99E] selection:text-[#101C2C]">
      {/* 1. Animated Interactive Electricity Grid Canvas Background */}
      <ElectricityGridCanvas mousePos={mousePos} />

      {/* 2. Layered Ambient Glow Orbs with Parallax */}
      <div
        className="absolute -top-32 -left-32 w-[550px] h-[550px] bg-gradient-to-br from-[#20A99E]/18 to-transparent rounded-full blur-[140px] pointer-events-none transition-transform duration-700 ease-out"
        style={{
          transform: `translate3d(${mousePos.x * -25}px, ${mousePos.y * -20}px, 0)`,
        }}
      />
      <div
        className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-gradient-to-bl from-[#9585F5]/16 via-[#35C99A]/10 to-transparent rounded-full blur-[160px] pointer-events-none transition-transform duration-700 ease-out"
        style={{
          transform: `translate3d(${mousePos.x * 30}px, ${mousePos.y * 25}px, 0)`,
        }}
      />
      <div className="absolute inset-0 grid-pattern-bg opacity-30 pointer-events-none" />

      {/* 3. Top Navigation Header */}
      <header className="relative z-20 w-full px-6 lg:px-12 py-5 flex items-center justify-between border-b border-[#34495E]/40 backdrop-blur-sm bg-[#101C2C]/60">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#20A99E] via-[#35C99A] to-[#9585F5] p-0.5 flex items-center justify-center shadow-[0_0_20px_rgba(32,169,158,0.4)]">
            <div className="w-full h-full bg-[#152538] rounded-[10px] flex items-center justify-center">
              <Zap className="w-5 h-5 text-[#20A99E]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-wider text-[#F8FAFC]">
                GRID<span className="text-[#20A99E]">MIND</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#9585F5]/20 text-[#9585F5] border border-[#9585F5]/40 tracking-wider">
                AI
              </span>
            </div>
            <p className="text-[9px] text-[#A9B8C8] tracking-widest uppercase font-medium">
              Active Distribution Grid System
            </p>
          </div>
        </div>

        {/* Center Hackathon Theme Badge (Desktop) */}
        <div className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#152538]/80 border border-[#20A99E]/40 text-xs text-[#20A99E] shadow-[0_0_15px_rgba(32,169,158,0.15)]">
          <Sparkles className="w-3.5 h-3.5 text-[#35C99A] animate-pulse" />
          <span className="font-semibold tracking-wide">POWER HACK 2026 • AI-DRIVEN ACTIVE DISTRIBUTION GRID</span>
        </div>

        {/* Right Live Grid State Ticker */}
        <div className="flex items-center gap-2.5 text-xs">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#35C99A] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#35C99A]" />
          </span>
          <span className="font-mono text-xs text-[#35C99A] font-semibold hidden sm:inline">
            50.02 Hz
          </span>
          <span className="text-[#A9B8C8] hidden sm:inline">•</span>
          <span className="text-[11px] font-medium text-[#A9B8C8] hidden sm:inline">
            11.04 kV Grid Synced
          </span>
        </div>
      </header>

      {/* 4. Split-Screen Main Content */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 lg:py-12 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* ================= LEFT SIDE: BRANDING & FEATURE CARDS ================= */}
          <div
            className="lg:col-span-7 space-y-6 transition-transform duration-500 ease-out"
            style={{
              transform: `translate3d(${mousePos.x * -10}px, ${mousePos.y * -8}px, 0)`,
            }}
          >
            {/* Project Tag */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#20A99E]/10 border border-[#20A99E]/30 text-xs font-semibold text-[#20A99E]">
              <Radio className="w-3.5 h-3.5 animate-pulse text-[#35C99A]" />
              <span>Next-Generation SCADA + Machine Learning</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-[#F8FAFC] leading-tight">
              Predict Demand.{' '}
              <span className="text-[#20A99E]">Monitor the Grid.</span>{' '}
              <br className="hidden sm:inline" />
              <span className="bg-gradient-to-r from-[#20A99E] via-[#35C99A] to-[#9585F5] bg-clip-text text-transparent">
                Power the Future.
              </span>
            </h1>

            {/* Description */}
            <p className="text-sm sm:text-base text-[#A9B8C8] leading-relaxed max-w-2xl">
              An intelligent distribution-grid monitoring platform combining electrical telemetry with
              AI-powered electricity demand prediction to support smarter and more proactive grid operations.
            </p>

            {/* 3 Interactive Feature Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-2">
              {/* Feature 1 */}
              <div className="group p-4 rounded-xl bg-[#1D3045]/80 hover:bg-[#1D3045] border border-[#34495E] hover:border-[#9585F5]/60 transition-all duration-300 shadow-lg hover:shadow-[0_0_20px_rgba(149,133,245,0.2)] transform hover:-translate-y-1">
                <div className="w-9 h-9 rounded-lg bg-[#9585F5]/15 border border-[#9585F5]/30 flex items-center justify-center text-[#9585F5] mb-3 group-hover:scale-110 transition-transform">
                  <BrainCircuit className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-[#F8FAFC] mb-1 flex items-center justify-between">
                  <span>AI Demand Prediction</span>
                  <span className="text-[9px] font-mono text-[#9585F5]">R² 0.978</span>
                </h4>
                <p className="text-[11px] text-[#A9B8C8] leading-snug">
                  Predict electricity consumption 30 minutes ahead using Random Forest Regression.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="group p-4 rounded-xl bg-[#1D3045]/80 hover:bg-[#1D3045] border border-[#34495E] hover:border-[#20A99E]/60 transition-all duration-300 shadow-lg hover:shadow-[0_0_20px_rgba(32,169,158,0.2)] transform hover:-translate-y-1">
                <div className="w-9 h-9 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/30 flex items-center justify-center text-[#20A99E] mb-3 group-hover:scale-110 transition-transform">
                  <Zap className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-[#F8FAFC] mb-1 flex items-center justify-between">
                  <span>Intelligent Monitoring</span>
                  <span className="text-[9px] font-mono text-[#20A99E]">11kV SCADA</span>
                </h4>
                <p className="text-[11px] text-[#A9B8C8] leading-snug">
                  Monitor transformer loading, feeder status, voltage, frequency and power factor.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="group p-4 rounded-xl bg-[#1D3045]/80 hover:bg-[#1D3045] border border-[#34495E] hover:border-[#35C99A]/60 transition-all duration-300 shadow-lg hover:shadow-[0_0_20px_rgba(53,201,154,0.2)] transform hover:-translate-y-1">
                <div className="w-9 h-9 rounded-lg bg-[#35C99A]/15 border border-[#35C99A]/30 flex items-center justify-center text-[#35C99A] mb-3 group-hover:scale-110 transition-transform">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h4 className="text-xs font-bold text-[#F8FAFC] mb-1 flex items-center justify-between">
                  <span>Predictive Insights</span>
                  <span className="text-[9px] font-mono text-[#35C99A]">Zero Trips</span>
                </h4>
                <p className="text-[11px] text-[#A9B8C8] leading-snug">
                  Identify increasing demand and potential equipment loading risks through intelligent monitoring.
                </p>
              </div>
            </div>

            {/* Real-time telemetry indicators ticker */}
            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-[#A9B8C8]">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#20A99E]" />
                <span>18 Transformers Monitored</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#35C99A]" />
                <span>24 Feeders Synchronized</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#9585F5]" />
                <span>150-Tree RF Ensemble</span>
              </div>
            </div>
          </div>

          {/* ================= RIGHT SIDE: PREMIUM INTEGRATED LOGIN PANEL ================= */}
          <div
            className="lg:col-span-5 transition-transform duration-500 ease-out"
            style={{
              transform: `translate3d(${mousePos.x * 8}px, ${mousePos.y * 6}px, 0)`,
            }}
          >
            <div className="rounded-2xl bg-[#1D3045]/90 backdrop-blur-md border border-[#34495E] p-6 sm:p-8 shadow-2xl relative overflow-hidden">
              {/* Corner decorative light */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#20A99E]/20 to-transparent pointer-events-none" />

              {/* Panel Header */}
              <div className="text-left mb-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#F8FAFC]">
                    Welcome to GRIDMIND AI
                  </h2>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30">
                    OPERATIONS CONSOLE
                  </span>
                </div>
                <p className="text-xs text-[#A9B8C8] mt-1">
                  Access your Grid Operations Console
                </p>
              </div>

              {/* A. Operator Role Selection (2 Selectable Interactive Cards) */}
              <div className="mb-5">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#A9B8C8] mb-2.5">
                  Select Operator Role
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Card 1: Lead Dispatcher */}
                  <div
                    onClick={() => handleRoleSelect('Lead Dispatcher')}
                    className={`cursor-pointer rounded-xl p-3.5 border transition-all duration-200 text-left relative ${
                      selectedRole === 'Lead Dispatcher'
                        ? 'bg-[#152538] border-[#20A99E] shadow-[0_0_15px_rgba(32,169,158,0.3)] ring-1 ring-[#20A99E]'
                        : 'bg-[#152538]/60 border-[#34495E] hover:border-[#20A99E]/50 hover:bg-[#152538]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          selectedRole === 'Lead Dispatcher'
                            ? 'bg-[#20A99E]/20 text-[#20A99E]'
                            : 'bg-[#263B50] text-[#A9B8C8]'
                        }`}
                      >
                        <Gauge className="w-4 h-4" />
                      </div>
                      {selectedRole === 'Lead Dispatcher' && (
                        <span className="w-2 h-2 rounded-full bg-[#20A99E] shadow-[0_0_8px_#20A99E]" />
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-[#F8FAFC]">Lead Dispatcher</h4>
                    <p className="text-[10px] text-[#A9B8C8] mt-1 leading-snug line-clamp-3">
                      Monitor the entire distribution network, electricity consumption, AI demand predictions and grid-wide alerts.
                    </p>
                  </div>

                  {/* Card 2: Substation Engineer */}
                  <div
                    onClick={() => handleRoleSelect('Substation Engineer')}
                    className={`cursor-pointer rounded-xl p-3.5 border transition-all duration-200 text-left relative ${
                      selectedRole === 'Substation Engineer'
                        ? 'bg-[#152538] border-[#35C99A] shadow-[0_0_15px_rgba(53,201,154,0.3)] ring-1 ring-[#35C99A]'
                        : 'bg-[#152538]/60 border-[#34495E] hover:border-[#35C99A]/50 hover:bg-[#152538]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          selectedRole === 'Substation Engineer'
                            ? 'bg-[#35C99A]/20 text-[#35C99A]'
                            : 'bg-[#263B50] text-[#A9B8C8]'
                        }`}
                      >
                        <Cpu className="w-4 h-4" />
                      </div>
                      {selectedRole === 'Substation Engineer' && (
                        <span className="w-2 h-2 rounded-full bg-[#35C99A] shadow-[0_0_8px_#35C99A]" />
                      )}
                    </div>
                    <h4 className="text-xs font-bold text-[#F8FAFC]">Substation Engineer</h4>
                    <p className="text-[10px] text-[#A9B8C8] mt-1 leading-snug line-clamp-3">
                      Monitor substation equipment, individual transformers, feeders, voltage, current and electrical operating conditions.
                    </p>
                  </div>
                </div>
              </div>

              {/* Error Alert */}
              {error && (
                <div className="mb-4 p-2.5 rounded-lg bg-[#F16F75]/15 border border-[#F16F75]/30 text-xs text-[#F16F75] flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#F16F75]" />
                  <span>{error}</span>
                </div>
              )}

              {/* B. Login Form Fields */}
              <form onSubmit={handleSignIn} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                    Operator Email Address
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="operator@gridmind.ai"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-xs sm:text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#A9B8C8] mb-1">
                    Authentication Password
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#A9B8C8]">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-9 pr-9 py-2 rounded-xl bg-[#152538] border border-[#34495E] focus:border-[#20A99E] focus:outline-none text-xs sm:text-sm text-[#F8FAFC] placeholder-[#A9B8C8]/50 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#A9B8C8] hover:text-[#F8FAFC]"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-0.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-[#A9B8C8] hover:text-[#F8FAFC]">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded bg-[#152538] border-[#34495E] text-[#20A99E] focus:ring-0"
                    />
                    <span>Remember console</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setForgotModalOpen(true)}
                    className="text-[#20A99E] hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                {/* C. Action Buttons */}
                <div className="pt-2">
                  <Button
                    type="submit"
                    variant="primary"
                    size="md"
                    loading={isLoading}
                    icon={ArrowRight}
                    iconPosition="right"
                    className="w-full text-xs sm:text-sm font-semibold shadow-[0_0_20px_rgba(32,169,158,0.3)]"
                  >
                    Sign In as {selectedRole}
                  </Button>
                </div>
              </form>

              {/* 6. Hackathon Quick Demo Login Bar */}
              <div className="mt-5 pt-4 border-t border-[#34495E]/80">
                <div className="flex items-center justify-between text-[11px] mb-2">
                  <span className="text-[#A9B8C8] font-medium flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-[#20A99E]" />
                    <span>Hackathon Quick 1-Click Access:</span>
                  </span>
                  <span className="text-[10px] text-[#35C99A]">Instant Bypass</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleInstantDemo('Lead Dispatcher')}
                    className="px-2.5 py-1.5 rounded-lg bg-[#152538] hover:bg-[#20A99E]/20 border border-[#34495E] hover:border-[#20A99E]/50 text-[11px] font-semibold text-[#F8FAFC] transition-all text-center flex items-center justify-center gap-1"
                  >
                    <span>Lead Dispatcher</span>
                    <ChevronRight className="w-3 h-3 text-[#20A99E]" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleInstantDemo('Substation Engineer')}
                    className="px-2.5 py-1.5 rounded-lg bg-[#152538] hover:bg-[#35C99A]/20 border border-[#34495E] hover:border-[#35C99A]/50 text-[11px] font-semibold text-[#F8FAFC] transition-all text-center flex items-center justify-center gap-1"
                  >
                    <span>Substation Engineer</span>
                    <ChevronRight className="w-3 h-3 text-[#35C99A]" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 5. Footer Status Strip */}
      <footer className="relative z-20 w-full px-6 py-4 border-t border-[#34495E]/40 bg-[#101C2C]/80 backdrop-blur-sm text-center text-xs text-[#A9B8C8] flex flex-col sm:flex-row items-center justify-between gap-2 max-w-7xl mx-auto">
        <div className="flex items-center gap-2 text-[11px]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#35C99A]" />
          <span>GRIDMIND AI v2.4 • Active Distribution Grid Protocols & IEC 61850 Compliant</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>Theme: AI-Driven Active Distribution Grid</span>
          <span>•</span>
          <span className="text-[#20A99E]">Random Forest Demand Regression</span>
        </div>
      </footer>

      {/* Forgot Password Simulation Modal */}
      <Modal
        isOpen={forgotModalOpen}
        onClose={() => {
          setForgotModalOpen(false);
          setForgotSent(false);
        }}
        title="Reset Operator Password"
        subtitle="Frontend demonstration for operator credential recovery"
        maxWidth="md"
      >
        {forgotSent ? (
          <div className="text-center py-4 space-y-3">
            <div className="w-12 h-12 rounded-full bg-[#35C99A]/20 border border-[#35C99A]/40 flex items-center justify-center mx-auto text-[#35C99A]">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-base font-semibold text-[#F8FAFC]">Password Reset Token Dispatched</h4>
            <p className="text-xs text-[#A9B8C8]">
              A temporary authentication reset token has been simulated for{' '}
              <span className="text-[#20A99E] font-medium">{forgotEmail || 'your email'}</span>.
            </p>
            <Button
              variant="secondary"
              size="md"
              onClick={() => {
                setForgotModalOpen(false);
                setForgotSent(false);
              }}
              className="mt-4 w-full"
            >
              Back to Sign In
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-xs text-[#A9B8C8]">
              Enter your registered utility dispatcher or engineering email address to receive secure OTP
              reset instructions.
            </p>
            <div>
              <label className="block text-xs font-medium text-[#A9B8C8] mb-1">Operator Email</label>
              <input
                type="email"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="operator@gridmind.ai"
                className="w-full px-3 py-2 rounded-lg bg-[#152538] border border-[#34495E] text-sm text-[#F8FAFC] focus:border-[#20A99E] focus:outline-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setForgotModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => setForgotSent(true)}
              >
                Send Reset Link
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
