import React, { useState } from 'react';
import {
  BatteryCharging,
  TrendingUp,
  TrendingDown,
  Clock,
  Sliders,
  CheckCircle2,
  Play
} from 'lucide-react';
import { mockBessState, mockBessHistory } from '../data/mockData';
import type { BessSystemState, BessHistoryEvent } from '../types';
import { useAuth } from '../context/AuthContext';

export const BessMonitoring: React.FC = () => {
  const { user } = useAuth();
  const [bessState, setBessState] = useState<BessSystemState>(mockBessState);
  const [history, setHistory] = useState<BessHistoryEvent[]>(mockBessHistory);
  const [manualPowerInput, setManualPowerInput] = useState<number>(0);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  // Available grid surplus from active SCADA audit
  const availableGridSurplusKw = 472;
  const efficiencyMultiplier = bessState.efficiencyPct / 100; // 0.938

  // 1. Intelligent Surplus Charge Simulation
  // Power: 400 kW (Respects available surplus 472 kW and 2,500 kW charge limit)
  // Duration: 0.5 hr (30 mins) -> Energy transferred: 200 kWh -> Stored energy added: 200 * 0.938 = 187.6 kWh
  const handleSimulateCharge = (powerKw = 400, durationHours = 0.5) => {
    if (powerKw > availableGridSurplusKw) {
      setFeedback(`ERROR: Charge power (${powerKw} kW) exceeds active grid surplus (${availableGridSurplusKw} kW).`);
      return;
    }

    setIsSimulating(true);
    setTimeout(() => {
      const gridEnergyTransferredKwh = Math.round(powerKw * durationHours); // 200 kWh
      const netStoredEnergyKwh = Math.round(gridEnergyTransferredKwh * efficiencyMultiplier); // ~188 kWh
      const oldEnergy = bessState.currentEnergyKwh;
      const newEnergyKwh = Math.min(bessState.totalCapacityKwh, oldEnergy + netStoredEnergyKwh);
      const oldSoc = bessState.stateOfChargePct;
      const newSoc = parseFloat(((newEnergyKwh / bessState.totalCapacityKwh) * 100).toFixed(1));

      const newEvent: BessHistoryEvent = {
        id: `BESS-SIM-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        event: 'Simulated Grid Surplus Absorption',
        type: 'CHARGE',
        powerKw: powerKw,
        durationMinutes: Math.round(durationHours * 60),
        energyKwh: gridEnergyTransferredKwh,
        initialSocPct: oldSoc,
        finalSocPct: newSoc,
        dispatcher: `${user?.name || 'Operator'} (Interactive Sim)`,
      };

      setBessState((prev) => ({
        ...prev,
        currentEnergyKwh: newEnergyKwh,
        stateOfChargePct: newSoc,
        currentPowerKw: -powerKw, // Negative = Charging
        operatingMode: 'AUTO_AI',
      }));

      setHistory((prev) => [newEvent, ...prev]);
      setIsSimulating(false);
      setFeedback(`Charged ${gridEnergyTransferredKwh} kWh from surplus (${powerKw} kW × ${durationHours}h). Net stored: +${netStoredEnergyKwh} kWh at 93.8% efficiency. SOC: ${oldSoc}% → ${newSoc}%.`);
      setTimeout(() => setFeedback(null), 5000);
    }, 600);
  };

  // 2. Intelligent Peak Shaving Discharge Simulation
  // Power: 500 kW (Within 2,500 kW discharge limit)
  // Duration: 0.5 hr (30 mins) -> Energy supplied to grid: 250 kWh -> Stored energy extracted: 250 / 0.938 = 267 kWh
  const handleSimulateDischarge = (powerKw = 500, durationHours = 0.5) => {
    setIsSimulating(true);
    setTimeout(() => {
      const energyDeliveredKwh = Math.round(powerKw * durationHours); // 250 kWh
      const energyDrawnFromBatteryKwh = Math.round(energyDeliveredKwh / efficiencyMultiplier); // ~267 kWh
      const minReserveKwh = Math.round(bessState.totalCapacityKwh * 0.15); // 15% minimum reserve SOC
      const oldEnergy = bessState.currentEnergyKwh;
      const newEnergyKwh = Math.max(minReserveKwh, oldEnergy - energyDrawnFromBatteryKwh);
      const oldSoc = bessState.stateOfChargePct;
      const newSoc = parseFloat(((newEnergyKwh / bessState.totalCapacityKwh) * 100).toFixed(1));

      const newEvent: BessHistoryEvent = {
        id: `BESS-SIM-${Date.now().toString().slice(-4)}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        event: 'Simulated Peak Shaving Feed',
        type: 'DISCHARGE',
        powerKw: powerKw,
        durationMinutes: Math.round(durationHours * 60),
        energyKwh: energyDeliveredKwh,
        initialSocPct: oldSoc,
        finalSocPct: newSoc,
        dispatcher: `${user?.name || 'Operator'} (Peak Shaving Sim)`,
      };

      setBessState((prev) => ({
        ...prev,
        currentEnergyKwh: newEnergyKwh,
        stateOfChargePct: newSoc,
        currentPowerKw: powerKw, // Positive = Discharging
        operatingMode: 'AUTO_AI',
      }));

      setHistory((prev) => [newEvent, ...prev]);
      setIsSimulating(false);
      setFeedback(`Discharged ${energyDeliveredKwh} kWh to relieve feeder peak (${powerKw} kW × ${durationHours}h). Battery draw: -${energyDrawnFromBatteryKwh} kWh. SOC: ${oldSoc}% → ${newSoc}%.`);
      setTimeout(() => setFeedback(null), 5000);
    }, 600);
  };

  // 3. Apply Manual Setpoint
  const handleApplyManualDispatch = () => {
    const power = manualPowerInput;
    setBessState((prev) => ({
      ...prev,
      currentPowerKw: power,
      operatingMode: power < 0 ? 'MANUAL_CHARGE' : power > 0 ? 'MANUAL_DISCHARGE' : 'STANDBY',
    }));

    setFeedback(`Manual dispatch setpoint applied: ${power > 0 ? `Discharging +${power} kW` : power < 0 ? `Charging ${power} kW` : 'Standby (0 kW)'}`);
    setTimeout(() => setFeedback(null), 4000);
  };

  // 4. Simulate 30-Min Run at Current Setpoint
  const handleSimulateManualRun = () => {
    const power = bessState.currentPowerKw;
    if (power === 0) {
      setFeedback('BESS is currently in Standby (0 kW). Set a charge or discharge setpoint first.');
      return;
    }
    if (power < 0) {
      handleSimulateCharge(Math.abs(power), 0.5);
    } else {
      handleSimulateDischarge(power, 0.5);
    }
  };

  const isCharging = bessState.currentPowerKw < 0;
  const isDischarging = bessState.currentPowerKw > 0;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/30 text-[#20A99E]">
              <BatteryCharging className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-[#F8FAFC] tracking-tight">
                BATTERY ENERGY STORAGE SYSTEM (BESS)
              </h1>
              <p className="text-xs text-[#A9B8C8]">
                10 MWh Substation LiFePO4 Unit • Consistent Power (kW) & Energy (kWh) Telemetry Simulation
              </p>
            </div>
          </div>
        </div>

        {/* State Badges */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-[#101C2C] border border-[#34495E] flex items-center gap-2 text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#35C99A] opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#35C99A]" />
            </span>
            <span className="text-[#A9B8C8]">BMS Status:</span>
            <span className="font-semibold text-[#35C99A]">{bessState.inverterStatus}</span>
          </div>

          <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#20A99E]/15 text-[#20A99E] border border-[#20A99E]/30">
            SIMULATED TELEMETRY
          </span>
        </div>
      </div>

      {/* Notification Toast */}
      {feedback && (
        <div className="p-3.5 rounded-lg bg-[#20A99E]/15 border border-[#20A99E]/40 text-xs text-[#F8FAFC] flex items-center justify-between shadow-lg animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#20A99E] shrink-0" />
            <span className="font-medium">{feedback}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-[#A9B8C8] hover:text-[#F8FAFC] text-sm font-bold px-1 cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {/* Primary Overview: SOC Gauge & Battery Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: State of Charge (SOC) Large Meter Card */}
        <div className="bg-[#152538] border border-[#34495E] rounded-xl p-6 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-[#A9B8C8] uppercase tracking-wider">
                State of Charge (SOC)
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                  isCharging
                    ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                    : isDischarging
                    ? 'bg-[#9585F5]/15 text-[#9585F5] border-[#9585F5]/30'
                    : 'bg-[#A9B8C8]/15 text-[#A9B8C8] border-[#A9B8C8]/30'
                }`}
              >
                {isCharging ? 'CHARGING' : isDischarging ? 'DISCHARGING' : 'STANDBY'}
              </span>
            </div>

            {/* Circular SVG Ring Gauge */}
            <div className="flex flex-col items-center justify-center my-4 py-2">
              <div className="relative w-40 h-40 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    stroke="#1D3045"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    stroke={
                      bessState.stateOfChargePct > 50
                        ? '#35C99A'
                        : bessState.stateOfChargePct > 20
                        ? '#F5B942'
                        : '#F16F75'
                    }
                    strokeWidth="10"
                    strokeDasharray={264}
                    strokeDashoffset={264 - (264 * bessState.stateOfChargePct) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                    className="transition-all duration-700 ease-out"
                  />
                </svg>

                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-3xl font-extrabold font-mono text-[#F8FAFC]">
                    {bessState.stateOfChargePct}%
                  </span>
                  <span className="text-[11px] text-[#A9B8C8] font-medium">SOC AVAILABLE</span>
                </div>
              </div>
            </div>

            {/* Capacity Numerical Breakdown (Power vs Energy Consistency) */}
            <div className="bg-[#101C2C] p-3.5 rounded-lg border border-[#34495E] space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Stored Usable Energy:</span>
                <span className="font-mono font-bold text-[#F8FAFC]">
                  {(bessState.currentEnergyKwh / 1000).toFixed(2)} MWh ({bessState.currentEnergyKwh.toLocaleString()} kWh)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Nameplate Battery Capacity:</span>
                <span className="font-mono font-semibold text-[#A9B8C8]">
                  {(bessState.totalCapacityKwh / 1000).toFixed(1)} MWh (10,000 kWh)
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">State of Health (SOH):</span>
                <span className="font-mono font-bold text-[#35C99A]">
                  {bessState.stateOfHealthPct}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#A9B8C8]">Round-Trip Efficiency:</span>
                <span className="font-mono font-semibold text-[#20A99E]">
                  {bessState.efficiencyPct}%
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#34495E] flex items-center justify-between text-xs text-[#A9B8C8]">
            <span>Cycle Count: {bessState.cycleCount}</span>
            <span>Reserve Limit: 15% SOC</span>
          </div>
        </div>

        {/* Right 2 Columns: Live Power Flow & Interactive Simulator Cards */}
        <div className="lg:col-span-2 space-y-6">
          {/* Real-time Telemetry Metrics Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#1D3045] p-3.5 rounded-xl border border-[#34495E]">
              <span className="text-[11px] text-[#A9B8C8] font-semibold uppercase">Active Power Rate</span>
              <div className="mt-1 flex items-baseline gap-1 font-mono">
                <span
                  className={`text-xl font-bold ${
                    isCharging ? 'text-[#35C99A]' : isDischarging ? 'text-[#9585F5]' : 'text-[#A9B8C8]'
                  }`}
                >
                  {isCharging ? `${bessState.currentPowerKw}` : isDischarging ? `+${bessState.currentPowerKw}` : '0'}
                </span>
                <span className="text-xs text-[#A9B8C8]">kW</span>
              </div>
              <div className="text-[10px] text-[#A9B8C8] mt-1">
                {isCharging ? 'Surplus Absorption' : isDischarging ? 'Peak Grid Support' : 'Standing By'}
              </div>
            </div>

            <div className="bg-[#1D3045] p-3.5 rounded-xl border border-[#34495E]">
              <span className="text-[11px] text-[#A9B8C8] font-semibold uppercase">Pack Temperature</span>
              <div className="mt-1 flex items-baseline gap-1 font-mono">
                <span className="text-xl font-bold text-[#35C99A]">{bessState.cellTemperatureC}°C</span>
              </div>
              <div className="text-[10px] text-[#A9B8C8] mt-1">Liquid Cooled Enclosure</div>
            </div>

            <div className="bg-[#1D3045] p-3.5 rounded-xl border border-[#34495E]">
              <span className="text-[11px] text-[#A9B8C8] font-semibold uppercase">Max Power Rating</span>
              <div className="mt-1 flex items-baseline gap-1 font-mono">
                <span className="text-xl font-bold text-[#F8FAFC]">2.5</span>
                <span className="text-xs text-[#A9B8C8]">MW</span>
              </div>
              <div className="text-[10px] text-[#A9B8C8] mt-1">±2,500 kW Inverter</div>
            </div>

            <div className="bg-[#1D3045] p-3.5 rounded-xl border border-[#34495E]">
              <span className="text-[11px] text-[#A9B8C8] font-semibold uppercase">Operating Mode</span>
              <div className="mt-1 font-mono">
                <span className="text-xs font-bold text-[#20A99E]">{bessState.operatingMode}</span>
              </div>
              <div className="text-[10px] text-[#A9B8C8] mt-1">Sign: (-) Charge, (+) Discharge</div>
            </div>
          </div>

          {/* Interactive Simulation Action Cards (Respecting Surplus and Power limits) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Quick Charge Action Card */}
            <div className="bg-[#152538] border border-[#35C99A]/40 rounded-xl p-4.5 flex flex-col justify-between shadow-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#35C99A]/10 rounded-full blur-2xl pointer-events-none" />
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-[#35C99A] uppercase tracking-wider mb-2">
                  <TrendingUp className="w-4 h-4" />
                  Intelligent Surplus Charge
                </div>
                <p className="text-xs text-[#A9B8C8] leading-relaxed mb-3">
                  Grid balance currently detects <strong className="text-[#35C99A] font-mono">+{availableGridSurplusKw} kW</strong> distribution surplus. Absorb 400 kW power (within surplus limit) into cells.
                </p>
                <div className="text-[11px] text-[#A9B8C8] mb-3 bg-[#101C2C] p-2 rounded border border-[#34495E]">
                  Energy: 400 kW × 0.5h = 200 kWh. Net stored: +188 kWh (≈ +1.9% SOC).
                </div>
              </div>

              <button
                onClick={() => handleSimulateCharge(400, 0.5)}
                disabled={isSimulating || bessState.stateOfChargePct >= 99}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#35C99A] hover:bg-[#2db589] text-[#101C2C] font-bold text-xs transition-colors shadow-md disabled:opacity-50 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Simulate Charge (400 kW • 30m)</span>
              </button>
            </div>

            {/* Quick Discharge Action Card */}
            <div className="bg-[#152538] border border-[#9585F5]/40 rounded-xl p-4.5 flex flex-col justify-between shadow-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#9585F5]/10 rounded-full blur-2xl pointer-events-none" />
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-[#9585F5] uppercase tracking-wider mb-2">
                  <TrendingDown className="w-4 h-4" />
                  Peak Shaving Discharge
                </div>
                <p className="text-xs text-[#A9B8C8] leading-relaxed mb-3">
                  AI predicts upcoming evening peak load. Discharge 500 kW to inject power into distribution busbar and shave peak.
                </p>
                <div className="text-[11px] text-[#A9B8C8] mb-3 bg-[#101C2C] p-2 rounded border border-[#34495E]">
                  Energy: 500 kW × 0.5h = 250 kWh delivered. Battery draw: -267 kWh (≈ -2.7% SOC).
                </div>
              </div>

              <button
                onClick={() => handleSimulateDischarge(500, 0.5)}
                disabled={isSimulating || bessState.stateOfChargePct <= 16}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#9585F5] hover:bg-[#8271e8] text-[#101C2C] font-bold text-xs transition-colors shadow-md disabled:opacity-50 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Simulate Discharge (500 kW • 30m)</span>
              </button>
            </div>
          </div>

          {/* Manual Setpoint Slider Panel */}
          <div className="bg-[#152538] border border-[#34495E] rounded-xl p-4.5 shadow-md">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-[#F8FAFC] flex items-center gap-2 uppercase tracking-wider">
                <Sliders className="w-4 h-4 text-[#20A99E]" />
                Interactive Dispatch Setpoint Controller (kW)
              </h3>
              <span className="text-[10px] text-[#A9B8C8] font-mono">±2,500 kW INVERTER RATING</span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#35C99A]">Charge (-2,500 kW)</span>
                <span className="font-bold text-[#F8FAFC] text-sm">
                  {manualPowerInput > 0
                    ? `Discharge +${manualPowerInput.toLocaleString()} kW`
                    : manualPowerInput < 0
                    ? `Charge ${manualPowerInput.toLocaleString()} kW`
                    : '0 kW (Idle Standby)'}
                </span>
                <span className="text-[#9585F5]">Discharge (+2,500 kW)</span>
              </div>

              <input
                type="range"
                min="-2500"
                max="2500"
                step="50"
                value={manualPowerInput}
                onChange={(e) => setManualPowerInput(Number(e.target.value))}
                className="w-full h-2 bg-[#101C2C] rounded-lg appearance-none cursor-pointer accent-[#20A99E]"
              />

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="text-[11px] text-[#A9B8C8]">
                  Sign Convention: <strong>Negative = Charging</strong>, <strong>Positive = Discharging</strong>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setManualPowerInput(0)}
                    className="px-3 py-1.5 rounded-lg bg-[#101C2C] text-[#A9B8C8] hover:text-[#F8FAFC] text-xs border border-[#34495E] transition-colors cursor-pointer"
                  >
                    Reset Zero
                  </button>
                  <button
                    onClick={handleApplyManualDispatch}
                    className="px-3.5 py-1.5 rounded-lg bg-[#20A99E] hover:bg-[#1b8e85] text-[#101C2C] font-bold text-xs transition-colors cursor-pointer"
                  >
                    Apply Setpoint
                  </button>
                  <button
                    onClick={handleSimulateManualRun}
                    disabled={isSimulating || bessState.currentPowerKw === 0}
                    className="px-3.5 py-1.5 rounded-lg bg-[#9585F5] hover:bg-[#8271e8] text-[#101C2C] font-bold text-xs transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Simulate 30m Run
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Historical Operations Log with Consistent Power & Energy Units */}
      <div className="bg-[#152538] border border-[#34495E] rounded-xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-[#F8FAFC] flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#20A99E]" />
              BESS Operational History & Dispatch Log
            </h2>
            <p className="text-xs text-[#A9B8C8]">
              Audit trail of automated and simulated charge/discharge cycles (Energy = Power × Time)
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#A9B8C8]">
            <thead className="bg-[#101C2C] text-[#F8FAFC] uppercase text-[10px] tracking-wider border-y border-[#34495E]">
              <tr>
                <th className="py-3 px-3">Log ID / Time</th>
                <th className="py-3 px-3">Operational Event</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Power Rate (kW)</th>
                <th className="py-3 px-3">Duration</th>
                <th className="py-3 px-3">Energy Transferred (kWh)</th>
                <th className="py-3 px-3">SOC Delta</th>
                <th className="py-3 px-3">Dispatcher / Authority</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#34495E]/50">
              {history.map((evt) => (
                <tr key={evt.id} className="hover:bg-[#1D3045]/60 transition-colors">
                  <td className="py-3 px-3">
                    <span className="font-mono text-[#20A99E] font-semibold">{evt.id}</span>
                    <div className="text-[10px] text-[#A9B8C8]">{evt.timestamp}</div>
                  </td>
                  <td className="py-3 px-3 font-medium text-[#F8FAFC]">{evt.event}</td>
                  <td className="py-3 px-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                        evt.type === 'CHARGE'
                          ? 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30'
                          : 'bg-[#9585F5]/15 text-[#9585F5] border-[#9585F5]/30'
                      }`}
                    >
                      {evt.type}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-[#F8FAFC] font-semibold">
                    {evt.powerKw.toLocaleString()} kW
                  </td>
                  <td className="py-3 px-3 font-mono text-[#A9B8C8]">{evt.durationMinutes} mins</td>
                  <td className="py-3 px-3 font-mono font-semibold text-[#F8FAFC]">{evt.energyKwh.toLocaleString()} kWh</td>
                  <td className="py-3 px-3 font-mono">
                    <span className="text-[#A9B8C8]">{evt.initialSocPct}%</span>
                    <span className="text-[#F8FAFC] mx-1">→</span>
                    <span className="text-[#35C99A] font-bold">{evt.finalSocPct}%</span>
                  </td>
                  <td className="py-3 px-3 text-[#A9B8C8]">{evt.dispatcher}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
