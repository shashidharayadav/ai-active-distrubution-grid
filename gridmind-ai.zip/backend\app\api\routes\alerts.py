"""
GRIDMIND AI - Alerts & Alarm Management API Routes
Strictly maintains the decoupled alert lifecycle:
ACTIVE -> RESOLVED -> READ
"""
from fastapi import APIRouter, HTTPException
from typing import List, Dict, Any
from app.services.alert_service import alert_service
from app.schemas.grid_schemas import AlertSchema

router = APIRouter(prefix="/alerts", tags=["Alerts"])


@router.get("", response_model=List[AlertSchema])
def list_all_alerts():
    return [AlertSchema(**a) for a in alert_service.get_all_alerts()]


@router.get("/active", response_model=List[AlertSchema])
def list_active_alerts():
    return [AlertSchema(**a) for a in alert_service.get_active_alerts()]


@router.get("/resolved", response_model=List[AlertSchema])
def list_resolved_alerts():
    return [AlertSchema(**a) for a in alert_service.get_resolved_alerts()]


@router.get("/unread", response_model=List[AlertSchema])
def list_unread_alerts():
    return [AlertSchema(**a) for a in alert_service.get_unread_alerts()]


@router.get("/unread-count")
def get_unread_count() -> Dict[str, int]:
    return {"unread_count": alert_service.get_unread_count()}


@router.get("/metrics")
def get_alert_metrics() -> Dict[str, int]:
    return alert_service.get_alert_metrics()


@router.patch("/{alert_id}/resolve", response_model=AlertSchema)
def resolve_alert(alert_id: str):
    """
    Resolves the problem status (moves to RESOLVED).
    Does NOT mark as read.
    """
    updated = alert_service.resolve_alert(alert_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Alert '{alert_id}' not found")
    return AlertSchema(**updated)


@router.patch("/{alert_id}/read", response_model=AlertSchema)
def mark_alert_read(alert_id: str):
    """
    Marks notification as read (isRead = True).
    Decrements unread count and preserves alert in history.
    """
    updated = alert_service.mark_as_read(alert_id)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Alert '{alert_id}' not found")
    return AlertSchema(**updated)


@router.post("/read-all")
def mark_all_alerts_read() -> Dict[str, Any]:
    count = alert_service.mark_all_as_read()
    return {"status": "SUCCESS", "marked_read_count": count}


@router.patch("/{alert_id}/acknowledge", response_model=AlertSchema)
def acknowledge_alert(alert_id: str, operator_name: str = "Lead Dispatcher"):
    updated = alert_service.acknowledge_alert(alert_id, operator_name)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Alert '{alert_id}' not found")
    return AlertSchema(**updated)
