import React from 'react';
import type { StatusType } from '../../types';

interface StatusBadgeProps {
  status: StatusType | 'online' | 'standby' | 'tripped' | 'active';
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  dot?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  label,
  size = 'md',
  dot = true,
}) => {
  const normalized = status.toLowerCase();

  let colorClasses = 'bg-[#263B50] text-[#A9B8C8] border-[#34495E]';
  let dotColor = 'bg-[#A9B8C8]';
  let displayLabel = label || status.toUpperCase();

  if (normalized === 'normal' || normalized === 'online' || normalized === 'active') {
    colorClasses = 'bg-[#35C99A]/15 text-[#35C99A] border-[#35C99A]/30';
    dotColor = 'bg-[#35C99A] shadow-[0_0_8px_#35C99A]';
    displayLabel = label || 'NORMAL';
  } else if (normalized === 'warning' || normalized === 'standby') {
    colorClasses = 'bg-[#F5B942]/15 text-[#F5B942] border-[#F5B942]/30';
    dotColor = 'bg-[#F5B942] shadow-[0_0_8px_#F5B942]';
    displayLabel = label || 'WARNING';
  } else if (normalized === 'critical' || normalized === 'tripped') {
    colorClasses = 'bg-[#F16F75]/15 text-[#F16F75] border-[#F16F75]/30 animate-pulse';
    dotColor = 'bg-[#F16F75] shadow-[0_0_8px_#F16F75]';
    displayLabel = label || 'CRITICAL';
  } else if (normalized === 'info') {
    colorClasses = 'bg-[#9585F5]/15 text-[#9585F5] border-[#9585F5]/30';
    dotColor = 'bg-[#9585F5] shadow-[0_0_8px_#9585F5]';
    displayLabel = label || 'INFO';
  }

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-xs font-medium px-2.5 py-1',
    lg: 'text-sm font-semibold px-3 py-1.5',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border transition-all ${colorClasses} ${sizeClasses}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />}
      <span>{displayLabel}</span>
    </span>
  );
};
