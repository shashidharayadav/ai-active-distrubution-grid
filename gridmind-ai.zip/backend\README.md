# GRIDMIND AI — Backend Architecture & API Specification

**BESCOM Hackathon Theme:** *AI-Driven Active Distribution Grid – Developing intelligent AI solutions to predict electricity demand, detect grid anomalies, and improve distribution-grid monitoring and operational efficiency.*

---

## 1. System Overview

GRIDMIND AI provides an enterprise-grade FastAPI backend for active distribution grid monitoring, forecasting, and optimization. It integrates electrical physics calculations, 13 Supabase PostgreSQL relational tables, Scikit-learn machine learning, and an 8-point graph constraint validation engine.

### Key Capabilities
1. **Centralized Energy Balance**: Net Grid Demand = Consumer Demand − Solar PV; Net Available Balance = Supply − Net Grid Demand − Losses ($5,400 - 4,470 - 93 = +837\text{ kW}$ surplus).
2. **Multi-Horizon AI Forecasting**: Chronologically evaluated Scikit-learn `RandomForestRegressor` lookaheads (+15m, +30m, +1h, +2h, +6h, +24h) with genuine held-out metrics ($R^2$, MAE, RMSE, MAPE).
3. **Multivariate Anomaly Detection**: `IsolationForest` detecting atypical active power, voltage deviations, frequency instability, and harmonic spikes (THD%).
4. **Surplus & Deficit Management**: BFS graph topology routing, 8-point physical constraint checks, and net delivered power calculations ($Delivered = Sending - Losses$).
5. **10 MWh Utility BESS Management**: Efficiency-corrected SOC tracking ($93.8\%$), surplus charging bounds, peak shaving setpoints.
6. **What-If Grid Sandbox**: Physical load categorization (residential cooling sensitivity, industrial shift factors, solar PV infeed, BESS dispatch).
7. **Decoupled Alert Lifecycle**: `ACTIVE` $\rightarrow$ `RESOLVED` $\rightarrow$ `READ` with zero automated conflation between physical resolution and operator acknowledgement.

---

## 2. Directory Structure

```
backend/
├── app/
│   ├── main.py                     # FastAPI application entrypoint & lifespan
│   ├── api/
│   │   └── routes/                 # Modular API routers
│   │       ├── dashboard.py        # /api/v1/dashboard/overview
│   │       ├── consumption.py      # /api/v1/consumption/*
│   │       ├── feeders.py          # /api/v1/feeders/*
│   │       ├── transformers.py     # /api/v1/transformers/*
│   │       ├── substations.py      # /api/v1/substations/*
│   │       ├── telemetry.py        # /api/v1/telemetry/*
│   │       ├── demand_prediction.py# /api/v1/predictions/*
│   │       ├── anomalies.py        # /api/v1/anomalies/*
│   │       ├── surplus_management.py # /api/v1/surplus/*
│   │       ├── bess.py             # /api/v1/bess/*
│   │       ├── simulator.py        # /api/v1/simulator/*
│   │       ├── alerts.py           # /api/v1/alerts/*
│   │       └── history.py          # /api/v1/history/*
│   ├── core/
│   │   ├── config.py               # Pydantic Settings & environment variables
│   │   └── security.py             # Operator session & JWT authentication
│   ├── database/
│   │   ├── connection.py           # Supabase client manager & fallback
│   │   └── repositories/
│   │       └── grid_repository.py  # Equipment, telemetry, and alert state store
│   ├── ml/
│   │   ├── demand_model.py         # Random Forest Regressor & evaluation
│   │   ├── anomaly_model.py        # Isolation Forest telemetry detector
│   │   └── saved_models/           # Serialized joblib artifacts
│   ├── schemas/
│   │   └── grid_schemas.py         # Pydantic v2 request & response schemas
│   └── services/
│       ├── energy_calculations.py  # Core electrical formulas (kW, kWh, losses, BESS)
│       ├── surplus_service.py      # Graph topology & 8-point constraint validation
│       ├── bess_service.py         # 10 MWh BESS state & dispatch logic
│       ├── simulator_service.py    # What-If simulator engine & 5 presets
│       └── alert_service.py        # Decoupled alert lifecycle management
├── scripts/
│   ├── create_schema.sql           # Complete Supabase DDL for 13 tables
│   ├── seed_demo_data.py           # Data seeding script
│   └── train_models.py             # Offline ML model training script
├── tests/
│   └── test_calculations.py        # 10 automated Pytest verification tests
├── requirements.txt
├── .env.example
├── .env
└── README.md
```

---

## 3. Supabase Database Schema

The backend uses a separate Supabase project (`scripts/create_schema.sql`) covering:
1. `substations`: Code, name, location, nominal voltage (11.0 kV), capacity.
2. `feeders`: Feeder codes, ratings (kW, A), nominal voltage, breaker state.
3. `transformers`: Rated kVA, voltage, cooling type, tap position, status.
4. `localities`: Sectors, feeder/transformer links, consumer categories.
5. `grid_telemetry`: Time-series $P$, $Q$, $S$, $V$, $I$, $f$, $PF$, THD%, 3-phase currents, solar.
6. `energy_readings`: Interval energy ($kWh = kW \times h$) & cumulative meter indices.
7. `bess_units`: 10 MWh capacity, current SOC%, charge/discharge efficiency ($93.8\%$).
8. `bess_events`: Charge/discharge audit logs with previous & updated SOC.
9. `alerts`: Code, severity, source equipment, status (`ACTIVE`/`RESOLVED`), `is_read`.
10. `transfer_recommendations`: Inter-feeder transfer proposals, constraints, delivery metrics.
11. `grid_topology`: Physical network nodes, branches, line resistance, and tie switches.
12. `demand_predictions`: Multi-horizon ML forecasts with error metrics ($|Actual - Predicted|$).
13. `simulation_history`: Serialized What-If sandbox inputs and calculated outputs.

### Setting up Supabase
1. Create a new Supabase Project named **GRIDMIND AI** at [https://supabase.com](https://supabase.com).
2. Open the **SQL Editor** in the Supabase Dashboard.
3. Paste and run the entire contents of `backend/scripts/create_schema.sql`.
4. Copy your **Project URL**, **Anon Key**, and **Service Role Key** from *Project Settings -> API*.
5. Paste them into `backend/.env`.

---

## 4. Electrical & Mathematical Formulas

- **Interval Energy:**
  $$\text{Energy (kWh)} = \text{Average Power (kW)} \times \text{Duration (hours)}$$
- **Net Grid Demand:**
  $$\text{Net Grid Demand} = \text{Consumer Demand} - \text{Solar Generation}$$
- **Energy Balance:**
  $$\text{Net Available Balance} = \text{Supply} - (\text{Net Demand} + P_{\text{BESS,chg}} - P_{\text{BESS,dis}}) - P_{\text{loss}}$$
- **Three-Phase Line Losses:**
  $$I = \frac{P}{\sqrt{3} \times V_{LL} \times \text{PF}}, \quad P_{\text{loss}} = 3 \times I^2 \times R_{\text{phase}}$$
- **Transformer Loading:**
  $$S = \sqrt{P^2 + Q^2}, \quad \text{Loading (\%)} = \frac{S}{S_{\text{rated}}} \times 100$$
- **BESS Stored Energy:**
  $$\text{Charging: } E_{\text{new}} = E_{\text{curr}} + (P_{\text{chg}} \times t \times \eta_{\text{chg}})$$
  $$\text{Discharging: } E_{\text{new}} = E_{\text{curr}} - \frac{P_{\text{dis}} \times t}{\eta_{\text{dis}}}$$
- **Inter-Feeder Net Delivered Power & Remaining Deficit:**
  $$P_{\text{delivered}} = P_{\text{sending}} - P_{\text{loss}}, \quad \text{Deficit}_{\text{remaining}} = \max(0, \text{Deficit}_{\text{orig}} - P_{\text{delivered}})$$

---

## 5. Running the Backend

### Prerequisites
- Python 3.10+ (tested on Python 3.14)
- Windows PowerShell or Bash

### Steps
```powershell
# 1. Navigate to backend directory
cd backend

# 2. Activate virtual environment
.\venv\Scripts\Activate.ps1

# 3. (Optional) Run tests
pytest tests/test_calculations.py -v

# 4. Start the FastAPI server
uvicorn app.main:app --reload --port 8000
```

Once running:
- **API Base URL:** `http://127.0.0.1:8000`
- **Interactive Swagger Docs:** `http://127.0.0.1:8000/docs`
- **ReDoc Documentation:** `http://127.0.0.1:8000/redoc`
- **Health Endpoint:** `http://127.0.0.1:8000/health`
