"""
GRIDMIND AI - Comprehensive Supabase Seeding Script
Populates all 13 Supabase PostgreSQL tables with standard BESCOM 11kV distribution data:
1. substations
2. feeders
3. transformers
4. localities
5. grid_topology
6. bess_units
7. bess_events
8. alerts
9. transfer_recommendations
10. grid_telemetry (24 hours of 15-min intervals)
11. energy_readings (interval & cumulative kWh)
12. demand_predictions
13. simulation_history
"""
import sys
import os
from datetime import datetime, timezone, timedelta
import random

# Add backend directory to sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.database.connection import get_supabase_client
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("gridmind.seed_complete")


def run_seed():
    supabase = get_supabase_client()
    if not supabase:
        logger.error("Supabase client is not available! Verify backend/.env credentials.")
        sys.exit(1)

    logger.info("Starting comprehensive seeding of 13 tables on Supabase...")

    # -------------------------------------------------------------------------
    # 1. SUBSTATIONS
    # -------------------------------------------------------------------------
    logger.info("Seeding substations...")
    substations_data = [
        {
            "substation_code": "BESCOM-110-N",
            "substation_name": "North Distribution Hub (110kV/11kV)",
            "location": "North Division Grid Sector 4",
            "nominal_voltage_kv": 11.04,
            "incoming_capacity_kw": 12000.0,
            "operational_status": "OPERATIONAL"
        },
        {
            "substation_code": "BESCOM-66-CYBER",
            "substation_name": "Cyber Corridor Substation (66kV/11kV)",
            "location": "Tech Park Industrial Corridor",
            "nominal_voltage_kv": 10.98,
            "incoming_capacity_kw": 8000.0,
            "operational_status": "OPERATIONAL"
        }
    ]
    for sub in substations_data:
        supabase.table("substations").upsert(sub, on_conflict="substation_code").execute()

    # Map substation_code -> UUID
    subs_db = supabase.table("substations").select("id, substation_code").execute().data
    sub_map = {s["substation_code"]: s["id"] for s in subs_db}
    logger.info("Substations mapped: %s", list(sub_map.keys()))

    # -------------------------------------------------------------------------
    # 2. FEEDERS
    # -------------------------------------------------------------------------
    logger.info("Seeding feeders...")
    feeders_data = [
        {
            "feeder_code": "FDR-01",
            "feeder_name": "Feeder FDR-01 (Tech Park Primary)",
            "substation_id": sub_map["BESCOM-110-N"],
            "locality_name": "Tech Park Cyber Corridor",
            "rated_capacity_kw": 2000.0,
            "rated_current_a": 105.0,
            "nominal_voltage_kv": 11.02,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        },
        {
            "feeder_code": "FDR-02",
            "feeder_name": "Feeder FDR-02 (Commercial Ring)",
            "substation_id": sub_map["BESCOM-110-N"],
            "locality_name": "Downtown Commercial Center",
            "rated_capacity_kw": 1500.0,
            "rated_current_a": 78.7,
            "nominal_voltage_kv": 10.96,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        },
        {
            "feeder_code": "FDR-03",
            "feeder_name": "Feeder FDR-03 (Heavy Industrial Line)",
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "locality_name": "Heavy Industrial Estate",
            "rated_capacity_kw": 1500.0,
            "rated_current_a": 78.7,
            "nominal_voltage_kv": 10.88,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        },
        {
            "feeder_code": "FDR-04",
            "feeder_name": "Feeder FDR-04 (Residential Valley)",
            "substation_id": sub_map["BESCOM-110-N"],
            "locality_name": "North Residential Valley",
            "rated_capacity_kw": 1200.0,
            "rated_current_a": 63.0,
            "nominal_voltage_kv": 11.04,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        },
        {
            "feeder_code": "FDR-05",
            "feeder_name": "Feeder FDR-05 (Metro Transit Grid)",
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "locality_name": "Metro Rail Transit Line",
            "rated_capacity_kw": 1000.0,
            "rated_current_a": 52.5,
            "nominal_voltage_kv": 10.95,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        },
        {
            "feeder_code": "FDR-06",
            "feeder_name": "Feeder FDR-06 (Solar Agri Feeder)",
            "substation_id": sub_map["BESCOM-110-N"],
            "locality_name": "Green Energy Agro Park",
            "rated_capacity_kw": 800.0,
            "rated_current_a": 42.0,
            "nominal_voltage_kv": 11.06,
            "operational_status": "ONLINE",
            "breaker_state": "CLOSED"
        }
    ]
    for f in feeders_data:
        supabase.table("feeders").upsert(f, on_conflict="feeder_code").execute()

    feeders_db = supabase.table("feeders").select("id, feeder_code").execute().data
    feeder_map = {f["feeder_code"]: f["id"] for f in feeders_db}
    logger.info("Feeders mapped: %s", list(feeder_map.keys()))

    # -------------------------------------------------------------------------
    # 3. TRANSFORMERS
    # -------------------------------------------------------------------------
    logger.info("Seeding transformers...")
    transformers_data = [
        {
            "transformer_code": "TX-01",
            "transformer_name": "Tech Park Substation Transformer 1",
            "feeder_id": feeder_map["FDR-01"],
            "substation_id": sub_map["BESCOM-110-N"],
            "rated_capacity_kva": 2000.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAN",
            "tap_position": 4,
            "operational_status": "NORMAL"
        },
        {
            "transformer_code": "TX-02",
            "transformer_name": "Tech Park Substation Transformer 2",
            "feeder_id": feeder_map["FDR-01"],
            "substation_id": sub_map["BESCOM-110-N"],
            "rated_capacity_kva": 1500.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAN",
            "tap_position": 4,
            "operational_status": "NORMAL"
        },
        {
            "transformer_code": "TX-03",
            "transformer_name": "Commercial Core Step-Down TX-3",
            "feeder_id": feeder_map["FDR-02"],
            "substation_id": sub_map["BESCOM-110-N"],
            "rated_capacity_kva": 1200.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAN",
            "tap_position": 3,
            "operational_status": "NORMAL"
        },
        {
            "transformer_code": "TX-04",
            "transformer_name": "Industrial High-Duty TX-4",
            "feeder_id": feeder_map["FDR-03"],
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "rated_capacity_kva": 1500.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAF",
            "tap_position": 5,
            "operational_status": "WARNING"
        },
        {
            "transformer_code": "TX-05",
            "transformer_name": "Residential Step-Down TX-5",
            "feeder_id": feeder_map["FDR-04"],
            "substation_id": sub_map["BESCOM-110-N"],
            "rated_capacity_kva": 1000.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAN",
            "tap_position": 4,
            "operational_status": "NORMAL"
        },
        {
            "transformer_code": "TX-06",
            "transformer_name": "Transit Line Auxiliary TX-6",
            "feeder_id": feeder_map["FDR-05"],
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "rated_capacity_kva": 800.0,
            "rated_voltage_kv": 11.0,
            "cooling_type": "ONAN",
            "tap_position": 4,
            "operational_status": "NORMAL"
        }
    ]
    for tx in transformers_data:
        supabase.table("transformers").upsert(tx, on_conflict="transformer_code").execute()

    tx_db = supabase.table("transformers").select("id, transformer_code").execute().data
    tx_map = {t["transformer_code"]: t["id"] for t in tx_db}
    logger.info("Transformers mapped: %s", list(tx_map.keys()))

    # -------------------------------------------------------------------------
    # 4. LOCALITIES
    # -------------------------------------------------------------------------
    logger.info("Seeding localities...")
    localities_data = [
        {
            "locality_code": "LOC-01",
            "locality_name": "Tech Park Cyber Corridor",
            "feeder_id": feeder_map["FDR-01"],
            "transformer_id": tx_map["TX-01"],
            "consumer_category": "COMMERCIAL",
            "contracted_demand_kw": 1800.0
        },
        {
            "locality_code": "LOC-02",
            "locality_name": "Downtown Commercial Center",
            "feeder_id": feeder_map["FDR-02"],
            "transformer_id": tx_map["TX-03"],
            "consumer_category": "COMMERCIAL",
            "contracted_demand_kw": 1100.0
        },
        {
            "locality_code": "LOC-03",
            "locality_name": "Heavy Industrial Estate",
            "feeder_id": feeder_map["FDR-03"],
            "transformer_id": tx_map["TX-04"],
            "consumer_category": "INDUSTRIAL",
            "contracted_demand_kw": 1400.0
        },
        {
            "locality_code": "LOC-04",
            "locality_name": "North Residential Valley",
            "feeder_id": feeder_map["FDR-04"],
            "transformer_id": tx_map["TX-05"],
            "consumer_category": "RESIDENTIAL",
            "contracted_demand_kw": 950.0
        },
        {
            "locality_code": "LOC-05",
            "locality_name": "Metro Rail Transit Line",
            "feeder_id": feeder_map["FDR-05"],
            "transformer_id": tx_map["TX-06"],
            "consumer_category": "TRANSIT",
            "contracted_demand_kw": 750.0
        },
        {
            "locality_code": "LOC-06",
            "locality_name": "Green Energy Agro Park",
            "feeder_id": feeder_map["FDR-06"],
            "transformer_id": None,
            "consumer_category": "AGRICULTURAL",
            "contracted_demand_kw": 400.0
        }
    ]
    for loc in localities_data:
        supabase.table("localities").upsert(loc, on_conflict="locality_code").execute()

    loc_db = supabase.table("localities").select("id, locality_code").execute().data
    loc_map = {l["locality_code"]: l["id"] for l in loc_db}
    logger.info("Localities mapped: %s", list(loc_map.keys()))

    # -------------------------------------------------------------------------
    # 5. GRID TOPOLOGY
    # -------------------------------------------------------------------------
    logger.info("Seeding grid topology...")
    top_existing = supabase.table("grid_topology").select("count", count="exact").execute().count
    if top_existing == 0:
        topology_edges = [
            {"from_node": "FDR-01", "to_node": "FDR-02", "connection_type": "TIE_SWITCH", "equipment_code": "T-1", "operational_status": "ONLINE", "rated_capacity_kw": 500.0, "resistance_ohm": 0.12, "length_km": 1.1},
            {"from_node": "FDR-02", "to_node": "FDR-03", "connection_type": "TIE_SWITCH", "equipment_code": "T-2", "operational_status": "ONLINE", "rated_capacity_kw": 450.0, "resistance_ohm": 0.15, "length_km": 1.4},
            {"from_node": "FDR-06", "to_node": "FDR-03", "connection_type": "TIE_SWITCH", "equipment_code": "T-3", "operational_status": "ONLINE", "rated_capacity_kw": 400.0, "resistance_ohm": 0.18, "length_km": 1.8},
            {"from_node": "FDR-04", "to_node": "FDR-05", "connection_type": "DISTRIBUTION_LINE", "equipment_code": "L-14", "operational_status": "ONLINE", "rated_capacity_kw": 600.0, "resistance_ohm": 0.10, "length_km": 0.9},
            {"from_node": "FDR-01", "to_node": "TX-01", "connection_type": "TRANSFORMER_LINK", "equipment_code": "TR-1", "operational_status": "ONLINE", "rated_capacity_kw": 2000.0, "resistance_ohm": 0.04, "length_km": 0.1},
            {"from_node": "FDR-03", "to_node": "TX-04", "connection_type": "TRANSFORMER_LINK", "equipment_code": "TR-4", "operational_status": "ONLINE", "rated_capacity_kw": 1500.0, "resistance_ohm": 0.05, "length_km": 0.1}
        ]
        supabase.table("grid_topology").insert(topology_edges).execute()

    # -------------------------------------------------------------------------
    # 6. BESS UNITS
    # -------------------------------------------------------------------------
    logger.info("Seeding BESS units...")
    bess_existing = supabase.table("bess_units").select("id, bess_name").execute().data
    if not bess_existing:
        bess_row = {
            "bess_name": "Central BESS Hub Alpha",
            "location": "North Substation Energy Storage Bay 1",
            "capacity_kwh": 10000.0,
            "current_soc_percent": 68.4,
            "minimum_soc_percent": 15.0,
            "maximum_soc_percent": 95.0,
            "maximum_charge_power_kw": 2000.0,
            "maximum_discharge_power_kw": 2000.0,
            "charge_efficiency": 0.9380,
            "discharge_efficiency": 0.9380,
            "state_of_health_percent": 99.1,
            "operating_mode": "AUTO_AI",
            "temperature_c": 27.4
        }
        res_bess = supabase.table("bess_units").insert(bess_row).execute()
        bess_id = res_bess.data[0]["id"]
    else:
        bess_id = bess_existing[0]["id"]

    # -------------------------------------------------------------------------
    # 7. BESS EVENTS
    # -------------------------------------------------------------------------
    logger.info("Seeding BESS events...")
    bess_events_cnt = supabase.table("bess_events").select("count", count="exact").execute().count
    if bess_events_cnt == 0:
        now = datetime.now(timezone.utc)
        events = [
            {"bess_id": bess_id, "event_type": "CHARGE", "power_kw": -850.0, "energy_kwh": 425.0, "previous_soc": 59.9, "updated_soc": 68.4, "duration_minutes": 30.0, "timestamp": (now - timedelta(hours=1)).isoformat(), "event_source": "AI_SOLAR_CAPTURE", "event_status": "COMPLETED"},
            {"bess_id": bess_id, "event_type": "DISCHARGE", "power_kw": 620.0, "energy_kwh": 310.0, "previous_soc": 66.1, "updated_soc": 59.9, "duration_minutes": 30.0, "timestamp": (now - timedelta(hours=4)).isoformat(), "event_source": "PEAK_SHAVING_DISPATCH", "event_status": "COMPLETED"},
            {"bess_id": bess_id, "event_type": "CHARGE", "power_kw": -1100.0, "energy_kwh": 550.0, "previous_soc": 55.1, "updated_soc": 66.1, "duration_minutes": 30.0, "timestamp": (now - timedelta(hours=8)).isoformat(), "event_source": "AI_SOLAR_CAPTURE", "event_status": "COMPLETED"}
        ]
        supabase.table("bess_events").insert(events).execute()

    # -------------------------------------------------------------------------
    # 8. ALERTS
    # -------------------------------------------------------------------------
    logger.info("Seeding alerts...")
    alerts_data = [
        {
            "alert_code": "ALT-8821",
            "alert_type": "FEEDER_OVERLOAD",
            "severity": "critical",
            "title": "Feeder Overload – Feeder FDR-03",
            "description": "Feeder FDR-03 loading reached 81.3% (1220 kW / 1500 kW rated). Approaching thermal dispatch limit.",
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "feeder_id": feeder_map["FDR-03"],
            "transformer_id": tx_map["TX-04"],
            "locality_id": loc_map["LOC-03"],
            "status": "ACTIVE",
            "is_read": False,
            "detected_at": (datetime.now(timezone.utc) - timedelta(minutes=14)).isoformat()
        },
        {
            "alert_code": "ALT-8819",
            "alert_type": "TRANSFORMER_OVERHEAT",
            "severity": "warning",
            "title": "Transformer Temperature Elevated – TX-04",
            "description": "Transformer TX-04 winding temperature is 78.4 C (warning threshold: 75.0 C). Forced air cooling engaged.",
            "substation_id": sub_map["BESCOM-66-CYBER"],
            "feeder_id": feeder_map["FDR-03"],
            "transformer_id": tx_map["TX-04"],
            "locality_id": loc_map["LOC-03"],
            "status": "ACTIVE",
            "is_read": False,
            "detected_at": (datetime.now(timezone.utc) - timedelta(minutes=32)).isoformat()
        },
        {
            "alert_code": "ALT-8815",
            "alert_type": "VOLTAGE_DEVIATION",
            "severity": "warning",
            "title": "Voltage Deviation – Feeder FDR-02",
            "description": "Bus voltage measured at 10.78 kV (-2.0% of nominal 11.0 kV). Within statutory band (+/-6%) but drifting downward.",
            "substation_id": sub_map["BESCOM-110-N"],
            "feeder_id": feeder_map["FDR-02"],
            "transformer_id": tx_map["TX-03"],
            "locality_id": loc_map["LOC-02"],
            "status": "ACTIVE",
            "is_read": False,
            "detected_at": (datetime.now(timezone.utc) - timedelta(minutes=48)).isoformat()
        },
        {
            "alert_code": "ALT-8798",
            "alert_type": "ANOMALY",
            "severity": "info",
            "title": "Solar Generation Spike Detected – FDR-06",
            "description": "Distributed solar PV reverse feed measured at +180 kW. Power factor shifted to 0.99 leading.",
            "substation_id": sub_map["BESCOM-110-N"],
            "feeder_id": feeder_map["FDR-06"],
            "transformer_id": None,
            "locality_id": loc_map["LOC-06"],
            "status": "ACTIVE",
            "is_read": False,
            "detected_at": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
        },
        {
            "alert_code": "ALT-8750",
            "alert_type": "VOLTAGE_DEVIATION",
            "severity": "info",
            "title": "Transient Phase Imbalance Resolved – TX-05",
            "description": "Phase current imbalance normalized back to 3.2% after residential air conditioning cycles stabilised.",
            "substation_id": sub_map["BESCOM-110-N"],
            "feeder_id": feeder_map["FDR-04"],
            "transformer_id": tx_map["TX-05"],
            "locality_id": loc_map["LOC-04"],
            "status": "RESOLVED",
            "is_read": False,
            "detected_at": (datetime.now(timezone.utc) - timedelta(hours=4)).isoformat(),
            "resolved_at": (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        }
    ]
    for alt in alerts_data:
        supabase.table("alerts").upsert(alt, on_conflict="alert_code").execute()

    # -------------------------------------------------------------------------
    # 9. TRANSFER RECOMMENDATIONS
    # -------------------------------------------------------------------------
    logger.info("Seeding transfer recommendations...")
    rec_existing = supabase.table("transfer_recommendations").select("count", count="exact").execute().count
    if rec_existing == 0:
        recs = [
            {
                "source_feeder_id": feeder_map["FDR-06"],
                "destination_feeder_id": feeder_map["FDR-03"],
                "source_surplus_kw": 320.0,
                "destination_deficit_kw": 300.0,
                "recommended_transfer_kw": 250.0,
                "estimated_losses_kw": 4.8,
                "estimated_delivered_power_kw": 245.2,
                "route": "FDR-06 (Agro Solar) -> Tie Switch T-3 -> FDR-03 (Heavy Industrial)",
                "constraint_status": "ALL_CONSTRAINTS_SATISFIED",
                "operator_status": "PENDING_APPROVAL",
                "deficit_resolution_status": "PARTIALLY_RESOLVED"
            },
            {
                "source_feeder_id": feeder_map["FDR-01"],
                "destination_feeder_id": feeder_map["FDR-02"],
                "source_surplus_kw": 650.0,
                "destination_deficit_kw": 200.0,
                "recommended_transfer_kw": 200.0,
                "estimated_losses_kw": 3.1,
                "estimated_delivered_power_kw": 196.9,
                "route": "FDR-01 (Tech Park Primary) -> Tie Switch T-1 -> FDR-02 (Commercial Ring)",
                "constraint_status": "ALL_CONSTRAINTS_SATISFIED",
                "operator_status": "APPROVED",
                "deficit_resolution_status": "FULLY_RESOLVED",
                "approved_by": "Lead Dispatcher",
                "approved_at": (datetime.now(timezone.utc) - timedelta(minutes=45)).isoformat()
            }
        ]
        supabase.table("transfer_recommendations").insert(recs).execute()

    # -------------------------------------------------------------------------
    # 10. GRID TELEMETRY (24 hours of 15-minute intervals for all feeders)
    # -------------------------------------------------------------------------
    logger.info("Seeding grid telemetry time-series records...")
    telem_cnt = supabase.table("grid_telemetry").select("count", count="exact").execute().count
    if telem_cnt == 0:
        telemetry_rows = []
        now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        # 24 hours = 96 15-minute points
        for i in range(96):
            t_point = now - timedelta(minutes=15 * (95 - i))
            hour = t_point.hour + t_point.minute / 60.0

            # Base solar profile (bell curve peaked at 13:00)
            solar_factor = max(0.0, -1.0 * ((hour - 13.0) / 4.0) ** 2 + 1.0) if 7.0 <= hour <= 19.0 else 0.0

            for code, f_id in feeder_map.items():
                if code == "FDR-01":
                    base_p = 1100.0 + 350.0 * (1.0 if 9 <= hour <= 18 else 0.4) + random.uniform(-20, 20)
                    v_kv = 11.02 + random.uniform(-0.04, 0.04)
                    solar_kw = 50.0 * solar_factor
                elif code == "FDR-02":
                    base_p = 750.0 + 200.0 * (1.0 if 10 <= hour <= 21 else 0.3) + random.uniform(-15, 15)
                    v_kv = 10.96 + random.uniform(-0.05, 0.05)
                    solar_kw = 25.0 * solar_factor
                elif code == "FDR-03":
                    base_p = 1150.0 + 100.0 * (1.0 if 8 <= hour <= 20 else 0.6) + random.uniform(-30, 30)
                    v_kv = 10.88 + random.uniform(-0.06, 0.03)
                    solar_kw = 10.0 * solar_factor
                elif code == "FDR-04":
                    base_p = 500.0 + 250.0 * (1.0 if (6 <= hour <= 9 or 18 <= hour <= 23) else 0.3) + random.uniform(-15, 15)
                    v_kv = 11.04 + random.uniform(-0.03, 0.03)
                    solar_kw = 80.0 * solar_factor
                elif code == "FDR-05":
                    base_p = 450.0 + 200.0 * (1.0 if (7 <= hour <= 11 or 17 <= hour <= 21) else 0.4) + random.uniform(-10, 10)
                    v_kv = 10.95 + random.uniform(-0.04, 0.04)
                    solar_kw = 15.0 * solar_factor
                else: # FDR-06
                    base_p = 250.0 + random.uniform(-10, 10)
                    v_kv = 11.06 + random.uniform(-0.02, 0.04)
                    solar_kw = 180.0 * solar_factor

                current_a = base_p / (1.73205 * v_kv * 0.98)
                q_kvar = base_p * 0.14
                s_kva = (base_p**2 + q_kvar**2) ** 0.5

                telemetry_rows.append({
                    "substation_id": sub_map["BESCOM-110-N"] if code in ["FDR-01", "FDR-02", "FDR-04", "FDR-06"] else sub_map["BESCOM-66-CYBER"],
                    "feeder_id": f_id,
                    "timestamp": t_point.isoformat(),
                    "active_power_kw": round(base_p, 2),
                    "reactive_power_kvar": round(q_kvar, 2),
                    "apparent_power_kva": round(s_kva, 2),
                    "voltage_kv": round(v_kv, 3),
                    "current_a": round(current_a, 2),
                    "frequency_hz": round(50.0 + random.uniform(-0.08, 0.08), 2),
                    "power_factor": 0.98,
                    "thd_percent": round(2.1 + random.uniform(-0.2, 0.3), 2),
                    "phase_a_current": round(current_a * 1.01, 2),
                    "phase_b_current": round(current_a * 0.99, 2),
                    "phase_c_current": round(current_a * 1.00, 2),
                    "solar_generation_kw": round(solar_kw, 2),
                    "source_type": "SIMULATED"
                })

        # Batch insert 50 at a time
        logger.info("Inserting %d telemetry records in batches...", len(telemetry_rows))
        for batch_i in range(0, len(telemetry_rows), 50):
            batch = telemetry_rows[batch_i:batch_i + 50]
            supabase.table("grid_telemetry").insert(batch).execute()

    # -------------------------------------------------------------------------
    # 11. ENERGY READINGS
    # -------------------------------------------------------------------------
    logger.info("Seeding energy readings (kWh)...")
    energy_cnt = supabase.table("energy_readings").select("count", count="exact").execute().count
    if energy_cnt == 0:
        energy_rows = []
        now = datetime.now(timezone.utc)
        cumulative_meter = 145000.0
        for i in range(24): # 24 hourly readings
            t_pt = now - timedelta(hours=23 - i)
            # Energy = avg 4800 kW * 1 hr = 4800 kWh
            kwh = round(4600.0 + random.uniform(100, 400), 2)
            cumulative_meter += kwh
            energy_rows.append({
                "feeder_id": feeder_map["FDR-01"],
                "timestamp": t_pt.isoformat(),
                "energy_kwh": kwh,
                "meter_reading_kwh": round(cumulative_meter, 2),
                "reading_type": "HOURLY"
            })
        supabase.table("energy_readings").insert(energy_rows).execute()

    # -------------------------------------------------------------------------
    # 12. DEMAND PREDICTIONS
    # -------------------------------------------------------------------------
    logger.info("Seeding demand predictions...")
    pred_cnt = supabase.table("demand_predictions").select("count", count="exact").execute().count
    if pred_cnt == 0:
        preds = []
        now = datetime.now(timezone.utc)
        horizons = ["+15M", "+30M", "+1H", "+2H", "+4H", "+6H", "+12H", "+24H"]
        base_demand = 4820.0
        for h in horizons:
            mins = int(h.replace("+", "").replace("M", "")) if "M" in h else int(h.replace("+", "").replace("H", "")) * 60
            t_forecast = now + timedelta(minutes=mins)
            predicted = round(base_demand + random.uniform(-120, 180), 2)
            preds.append({
                "feeder_id": feeder_map["FDR-01"],
                "prediction_timestamp": t_forecast.isoformat(),
                "forecast_horizon": h,
                "predicted_demand_kw": predicted,
                "confidence_lower_kw": round(predicted * 0.965, 2),
                "confidence_upper_kw": round(predicted * 1.035, 2),
                "model_version": "RF_V2.4"
            })
        supabase.table("demand_predictions").insert(preds).execute()

    # -------------------------------------------------------------------------
    # 13. SIMULATION HISTORY
    # -------------------------------------------------------------------------
    logger.info("Seeding simulation history...")
    sim_cnt = supabase.table("simulation_history").select("count", count="exact").execute().count
    if sim_cnt == 0:
        sims = [
            {
                "user_id": "Dispatcher-01",
                "scenario_name": "Peak Summer Heatwave (+4.5 C)",
                "input_parameters": {
                    "consumer_demand_pct": 115.0,
                    "rooftop_solar_offset_kw": 350.0,
                    "industrial_activity_pct": 100.0,
                    "ambient_temperature_c": 37.5,
                    "incoming_feed_kw": 5400.0,
                    "bess_dispatch_kw": 800.0
                },
                "output_results": {
                    "net_grid_demand_kw": 5093.0,
                    "available_balance_kw": 307.0,
                    "system_status": "STRESSED",
                    "estimated_losses_kw": 118.0
                }
            },
            {
                "user_id": "Dispatcher-01",
                "scenario_name": "Maximum Solar Noon Offset",
                "input_parameters": {
                    "consumer_demand_pct": 95.0,
                    "rooftop_solar_offset_kw": 750.0,
                    "industrial_activity_pct": 85.0,
                    "ambient_temperature_c": 31.0,
                    "incoming_feed_kw": 5400.0,
                    "bess_dispatch_kw": -1200.0
                },
                "output_results": {
                    "net_grid_demand_kw": 3829.0,
                    "available_balance_kw": 1571.0,
                    "system_status": "SURPLUS",
                    "estimated_losses_kw": 76.5
                }
            }
        ]
        supabase.table("simulation_history").insert(sims).execute()

    logger.info("============================================================")
    logger.info("SUCCESS: All 13 tables on Supabase seeded and verified!")
    logger.info("============================================================")


if __name__ == "__main__":
    run_seed()
