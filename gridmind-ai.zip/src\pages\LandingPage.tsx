import React from 'react';
import { Link } from 'react-router-dom';
import {
  Zap,
  Activity,
  BrainCircuit,
  Cpu,
  GitBranch,
  ShieldAlert,
  ArrowRight,
  CheckCircle,
  BarChart3,
  TrendingUp,
  Sparkles,
  Lock
} from 'lucide-react';
import { Button } from '../components/common/Button';

export const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#101C2C] text-[#F8FAFC] selection:bg-[#20A99E] selection:text-[#101C2C]">
      {/* 1. Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-[#152538]/90 backdrop-blur-md border-b border-[#34495E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#20A99E] via-[#35C99A] to-[#9585F5] p-0.5 flex items-center justify-center shadow-[0_0_20px_rgba(32,169,158,0.4)]">
              <div className="w-full h-full bg-[#152538] rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-[#20A99E]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-wider text-[#F8FAFC]">
                  GRID<span className="text-[#20A99E]">MIND</span>
                </span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-[#9585F5]/20 text-[#9585F5] border border-[#9585F5]/40">
                  AI
                </span>
              </div>
              <p className="text-[10px] text-[#A9B8C8] tracking-widest uppercase font-medium">
                Active Distribution Grid System
              </p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-[#A9B8C8]">
            <a href="#features" className="hover:text-[#20A99E] transition-colors">
              Core Capabilities
            </a>
            <a href="#how-it-works" className="hover:text-[#20A99E] transition-colors">
              System Pipeline
            </a>
            <a href="#ai-prediction" className="hover:text-[#9585F5] transition-colors flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#9585F5]" />
              Random Forest AI
            </a>
            <a href="#impact" className="hover:text-[#35C99A] transition-colors">
              Grid Impact
            </a>
          </div>

          <div className="flex items-center gap-3">
            <Link to="/login">
              <Button variant="secondary" size="sm" icon={Lock}>
                Sign In
              </Button>
            </Link>
            <Link to="/login">
              <Button variant="primary" size="sm" icon={ArrowRight} iconPosition="right">
                Launch Console
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* 2. Hero Section */}
      <section className="relative pt-16 pb-24 lg:pt-24 lg:pb-32 overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-gradient-to-r from-[#20A99E]/15 via-[#35C99A]/10 to-[#9585F5]/20 blur-[120px] pointer-events-none rounded-full" />
        <div className="absolute inset-0 grid-pattern-bg opacity-35 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          {/* Hackathon Theme Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1D3045] border border-[#20A99E]/40 text-xs font-semibold text-[#20A99E] mb-6 shadow-[0_0_20px_rgba(32,169,158,0.2)]">
            <Sparkles className="w-3.5 h-3.5 text-[#35C99A]" />
            <span>HACKATHON THEME: AI-DRIVEN ACTIVE DISTRIBUTION GRID</span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#F8FAFC] max-w-4xl mx-auto leading-tight sm:leading-none">
            Intelligent Active Grid Monitoring &{' '}
            <span className="bg-gradient-to-r from-[#20A99E] via-[#35C99A] to-[#9585F5] bg-clip-text text-transparent">
              AI Demand Prediction
            </span>
          </h1>

          {/* Description */}
          <p className="mt-6 text-base sm:text-lg text-[#A9B8C8] max-w-3xl mx-auto leading-relaxed">
            GRIDMIND AI empowers distribution system operators with real-time SCADA telemetry,
            dynamic transformer thermal monitoring, and predictive load forecasting powered by{' '}
            <span className="text-[#9585F5] font-semibold">Random Forest Regression</span> to prevent
            blackouts and optimize power flow.
          </p>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/login">
              <Button variant="primary" size="lg" icon={Zap}>
                Enter Operations Console
              </Button>
            </Link>
            <Link to="/login">
              <Button variant="ai" size="lg" icon={BrainCircuit}>
                Explore AI Prediction Engine
              </Button>
            </Link>
          </div>

          {/* Live Stat Badges Ticker */}
          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
            <div className="p-4 rounded-xl bg-[#1D3045]/80 border border-[#34495E] backdrop-blur-sm">
              <div className="flex items-center gap-2 text-xs font-medium text-[#A9B8C8] mb-1">
                <TrendingUp className="w-3.5 h-3.5 text-[#20A99E]" />
                <span>Current Ingested Load</span>
              </div>
              <p className="text-2xl font-bold text-[#F8FAFC]">4,820 kW</p>
              <span className="text-[10px] text-[#35C99A] font-semibold">Real-time Telemetry</span>
            </div>

            <div className="p-4 rounded-xl bg-[#1D3045]/80 border border-[#9585F5]/30 backdrop-blur-sm">
              <div className="flex items-center gap-2 text-xs font-medium text-[#A9B8C8] mb-1">
                <BrainCircuit className="w-3.5 h-3.5 text-[#9585F5]" />
                <span>Predicted 30m Demand</span>
              </div>
              <p className="text-2xl font-bold text-[#9585F5]">5,140 kW</p>
              <span className="text-[10px] text-[#9585F5] font-semibold">+6.6% Expected Surge</span>
            </div>

            <div className="p-4 rounded-xl bg-[#1D3045]/80 border border-[#34495E] backdrop-blur-sm">
              <div className="flex items-center gap-2 text-xs font-medium text-[#A9B8C8] mb-1">
                <Cpu className="w-3.5 h-3.5 text-[#35C99A]" />
                <span>Monitored Assets</span>
              </div>
              <p className="text-2xl font-bold text-[#F8FAFC]">18 TR / 24 FDR</p>
              <span className="text-[10px] text-[#35C99A] font-semibold">100% Online & Synced</span>
            </div>

            <div className="p-4 rounded-xl bg-[#1D3045]/80 border border-[#34495E] backdrop-blur-sm">
              <div className="flex items-center gap-2 text-xs font-medium text-[#A9B8C8] mb-1">
                <Sparkles className="w-3.5 h-3.5 text-[#20A99E]" />
                <span>Model Accuracy</span>
              </div>
              <p className="text-2xl font-bold text-[#35C99A]">R² = 0.978</p>
              <span className="text-[10px] text-[#A9B8C8]">Random Forest Regression</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Feature Highlights */}
      <section id="features" className="py-20 bg-[#152538] border-y border-[#34495E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <span className="text-xs font-bold text-[#20A99E] uppercase tracking-wider">
              System Capabilities
            </span>
            <h2 className="text-3xl font-bold text-[#F8FAFC] mt-2">
              Engineered for Modern Active Distribution Grids
            </h2>
            <p className="text-sm text-[#A9B8C8] mt-3">
              Traditional distribution networks operate blindly. GRIDMIND AI brings bi-directional
              transparency, thermal protection, and predictive intelligence to 11kV distribution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E] hover:border-[#20A99E]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#20A99E]/10 border border-[#20A99E]/30 flex items-center justify-center text-[#20A99E] mb-5 group-hover:scale-110 transition-transform">
                <Activity className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                Active Grid & Telemetry Monitoring
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Sub-second sampling of voltage levels (11kV), 3-phase currents, power factor, and
                harmonics across primary substations and ring-main distribution nodes.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#9585F5]/40 hover:border-[#9585F5] transition-all group shadow-[0_0_25px_-5px_rgba(149,133,245,0.15)]">
              <div className="w-12 h-12 rounded-xl bg-[#9585F5]/15 border border-[#9585F5]/30 flex items-center justify-center text-[#9585F5] mb-5 group-hover:scale-110 transition-transform">
                <BrainCircuit className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2 flex items-center gap-2">
                <span>Random Forest Demand Prediction</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#9585F5]/20 text-[#9585F5]">
                  AI Core
                </span>
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Trained on ambient meteorological signals, solar PV generation patterns, and historical
                load lags to generate accurate 30-minute, 1-hour, and 24-hour demand curves.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E] hover:border-[#35C99A]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#35C99A]/10 border border-[#35C99A]/30 flex items-center justify-center text-[#35C99A] mb-5 group-hover:scale-110 transition-transform">
                <Cpu className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                Transformer Thermal & Loading Fleet
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Live monitoring of oil and winding temperatures, cooling fan stages, and load ratios to
                detect hotspots and prevent insulation degradation before irreversible damage occurs.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E] hover:border-[#20A99E]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#20A99E]/10 border border-[#20A99E]/30 flex items-center justify-center text-[#20A99E] mb-5 group-hover:scale-110 transition-transform">
                <GitBranch className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                Feeder Balancing & Switching
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Locality-level feeder load breakdown with breaker telemetry. Simulates tie-switch
                operations to reroute loads away from overloaded lines.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E] hover:border-[#F5B942]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#F5B942]/10 border border-[#F5B942]/30 flex items-center justify-center text-[#F5B942] mb-5 group-hover:scale-110 transition-transform">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                Intelligent Tri-Level Alerts
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Categorized Critical, Warning, and Informational alerts with operator acknowledgement
                and dispatch response workflows.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E] hover:border-[#20A99E]/50 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#20A99E]/10 border border-[#20A99E]/30 flex items-center justify-center text-[#20A99E] mb-5 group-hover:scale-110 transition-transform">
                <BarChart3 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                Comprehensive Analytics & Export
              </h3>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Historical peak records, locality consumption comparisons, and one-click CSV export
                for regulatory compliance and grid planning.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. How the System Works (4-Stage Pipeline) */}
      <section id="how-it-works" className="py-20 bg-[#101C2C]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold text-[#35C99A] uppercase tracking-wider">
              Operational Workflow
            </span>
            <h2 className="text-3xl font-bold text-[#F8FAFC] mt-2">
              How GRIDMIND AI Operates
            </h2>
            <p className="text-sm text-[#A9B8C8] mt-3">
              A closed-loop architecture connecting distribution edge hardware to advanced machine
              learning regression models.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            {/* Step 1 */}
            <div className="relative p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="w-10 h-10 rounded-full bg-[#20A99E]/20 text-[#20A99E] font-bold flex items-center justify-center mb-4 text-sm border border-[#20A99E]/40">
                01
              </div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Edge Telemetry Ingestion</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Smart meters, RTUs, and digital protective relays stream active kW, reactive kVAR,
                voltage, and oil temperatures across 24 distribution feeders.
              </p>
            </div>

            {/* Step 2 */}
            <div className="relative p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="w-10 h-10 rounded-full bg-[#35C99A]/20 text-[#35C99A] font-bold flex items-center justify-center mb-4 text-sm border border-[#35C99A]/40">
                02
              </div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Grid State Synchronization</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Centralized SCADA module filters harmonic noise, performs state estimation, and flags
                substation assets approaching thermal warning thresholds.
              </p>
            </div>

            {/* Step 3 */}
            <div className="relative p-6 rounded-2xl bg-[#1D3045] border border-[#9585F5]/40 shadow-[0_0_20px_-5px_rgba(149,133,245,0.2)]">
              <div className="w-10 h-10 rounded-full bg-[#9585F5]/20 text-[#9585F5] font-bold flex items-center justify-center mb-4 text-sm border border-[#9585F5]/40">
                03
              </div>
              <h4 className="text-base font-semibold text-[#9585F5] mb-2">Random Forest Regression</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Ensemble of 150 decision trees combines historical 24h load lags with ambient weather
                data to predict demand with 95% confidence intervals.
              </p>
            </div>

            {/* Step 4 */}
            <div className="relative p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="w-10 h-10 rounded-full bg-[#20A99E]/20 text-[#20A99E] font-bold flex items-center justify-center mb-4 text-sm border border-[#20A99E]/40">
                04
              </div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Automated Dispatch Advisory</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Alerts operators ahead of time to engage battery storage systems (BESS), adjust tap
                changers, or re-route feeder paths before overloads occur.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Dedicated AI Prediction Showcase */}
      <section id="ai-prediction" className="py-20 bg-[#152538] border-t border-[#34495E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#9585F5]/15 border border-[#9585F5]/30 text-xs font-semibold text-[#9585F5] mb-4">
                <BrainCircuit className="w-3.5 h-3.5" />
                <span>PREDICTIVE MACHINE LEARNING</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#F8FAFC] leading-tight">
                Accurate Electricity Demand Prediction Using Random Forest Regression
              </h2>
              <p className="mt-4 text-sm text-[#A9B8C8] leading-relaxed">
                Unlike simple linear moving averages, our Random Forest Regressor captures non-linear
                demand spikes caused by air conditioning loads, EV charging cycles, and manufacturing shifts.
              </p>

              <div className="mt-6 space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#35C99A] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-sm font-semibold text-[#F8FAFC]">Multi-Horizon Forecasting</h5>
                    <p className="text-xs text-[#A9B8C8]">
                      Provides 30-minute lookahead (+6.6% surge), 1-hour trend, and 24-hour diurnal
                      demand projections.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#35C99A] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-sm font-semibold text-[#F8FAFC]">Meteorological Correlation</h5>
                    <p className="text-xs text-[#A9B8C8]">
                      Factor in ambient temperature, solar irradiation loss, and humidity indices to
                      pinpoint peak cooling demand hours.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-[#35C99A] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-sm font-semibold text-[#F8FAFC]">Fast 14.2 ms Inference</h5>
                    <p className="text-xs text-[#A9B8C8]">
                      Ready for sub-minute real-time dispatch cycle without high GPU computation costs.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Link to="/login">
                  <Button variant="ai" size="md" icon={ArrowRight} iconPosition="right">
                    View Real-time Forecast Dashboard
                  </Button>
                </Link>
              </div>
            </div>

            {/* Model Card Visual Showcase */}
            <div className="rounded-2xl bg-[#1D3045] border border-[#9585F5]/40 p-6 shadow-2xl relative">
              <div className="flex items-center justify-between pb-4 border-b border-[#34495E]">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="w-5 h-5 text-[#9585F5]" />
                  <h4 className="text-base font-bold text-[#F8FAFC]">RF-Regressor Model Spec</h4>
                </div>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-[#35C99A]/20 text-[#35C99A] border border-[#35C99A]/30">
                  TRAINED & VALIDATED
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 my-5">
                <div className="p-3 rounded-xl bg-[#152538] border border-[#34495E]">
                  <span className="text-[10px] text-[#A9B8C8] uppercase font-medium">Determination (R²)</span>
                  <p className="text-xl font-bold text-[#35C99A]">0.978</p>
                  <span className="text-[10px] text-[#A9B8C8]">Variance Explained</span>
                </div>
                <div className="p-3 rounded-xl bg-[#152538] border border-[#34495E]">
                  <span className="text-[10px] text-[#A9B8C8] uppercase font-medium">Root Mean Sq. Error</span>
                  <p className="text-xl font-bold text-[#20A99E]">28.4 kW</p>
                  <span className="text-[10px] text-[#A9B8C8]">Avg Residual Deviation</span>
                </div>
              </div>

              <h5 className="text-xs font-semibold text-[#A9B8C8] uppercase tracking-wider mb-2">
                Top Model Feature Weights
              </h5>
              <div className="space-y-2.5 text-xs">
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#F8FAFC]">Historical 24-hr Lagged Load (kW)</span>
                    <span className="text-[#20A99E] font-semibold">34.5%</span>
                  </div>
                  <div className="h-1.5 w-full bg-[#152538] rounded-full overflow-hidden">
                    <div className="h-full bg-[#20A99E] rounded-full" style={{ width: '34.5%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#F8FAFC]">Ambient Dry-Bulb Temperature (°C)</span>
                    <span className="text-[#35C99A] font-semibold">24.2%</span>
                  </div>
                  <div className="h-1.5 w-full bg-[#152538] rounded-full overflow-hidden">
                    <div className="h-full bg-[#35C99A] rounded-full" style={{ width: '24.2%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#F8FAFC]">Diurnal Harmonic Time-of-Day</span>
                    <span className="text-[#9585F5] font-semibold">18.1%</span>
                  </div>
                  <div className="h-1.5 w-full bg-[#152538] rounded-full overflow-hidden">
                    <div className="h-full bg-[#9585F5] rounded-full" style={{ width: '18.1%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#F8FAFC]">Solar PV Infeed Offset (kW)</span>
                    <span className="text-[#F5B942] font-semibold">12.4%</span>
                  </div>
                  <div className="h-1.5 w-full bg-[#152538] rounded-full overflow-hidden">
                    <div className="h-full bg-[#F5B942] rounded-full" style={{ width: '12.4%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Benefits & Grid Impact */}
      <section id="impact" className="py-20 bg-[#101C2C]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <span className="text-xs font-bold text-[#20A99E] uppercase tracking-wider">
              Quantifiable Impact
            </span>
            <h2 className="text-3xl font-bold text-[#F8FAFC] mt-2">
              Modernizing Distribution Grid Operations
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="text-3xl font-extrabold text-[#20A99E] mb-2">-38%</div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Unplanned Outages</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Early predictive alerts on overloaded transformers give field dispatchers sufficient
                time to shift feeder ties before circuit breakers trip.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="text-3xl font-extrabold text-[#35C99A] mb-2">+22%</div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Transformer Asset Life</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Continuous thermal modeling prevents excessive hot-spot temperatures, significantly
                reducing paper winding insulation degradation.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#1D3045] border border-[#34495E]">
              <div className="text-3xl font-extrabold text-[#9585F5] mb-2">97.8%</div>
              <h4 className="text-base font-semibold text-[#F8FAFC] mb-2">Peak Forecast Precision</h4>
              <p className="text-xs text-[#A9B8C8] leading-relaxed">
                Empowers utilities to deploy expensive peaking generation and battery storage with
                surgical precision, saving thousands in diesel and peak market tariffs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. CTA Banner */}
      <section className="py-16 bg-gradient-to-b from-[#152538] to-[#101C2C] border-t border-[#34495E] relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl font-bold text-[#F8FAFC]">
            Ready to Experience GRIDMIND AI in Action?
          </h2>
          <p className="text-sm text-[#A9B8C8] mt-3 max-w-2xl mx-auto">
            Test the complete active grid monitoring console, inspect transformers, and interact with
            the Random Forest demand prediction interface.
          </p>
          <div className="mt-8 flex justify-center gap-4">
            <Link to="/login">
              <Button variant="primary" size="lg" icon={Zap}>
                Sign In to Operator Console
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* 8. Footer */}
      <footer className="bg-[#101C2C] border-t border-[#34495E] py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#20A99E]/20 border border-[#20A99E]/40 flex items-center justify-center">
              <Zap className="w-4 h-4 text-[#20A99E]" />
            </div>
            <span className="font-bold text-sm tracking-wider text-[#F8FAFC]">
              GRID<span className="text-[#20A99E]">MIND</span> AI
            </span>
            <span className="text-xs text-[#A9B8C8] ml-2">
              • AI-Driven Active Distribution Grid Project
            </span>
          </div>

          <div className="flex items-center gap-6 text-xs text-[#A9B8C8]">
            <span>Theme: AI-Driven Active Distribution Grid</span>
            <Link to="/login" className="hover:text-[#20A99E]">
              Console Login
            </Link>
            <Link to="/register" className="hover:text-[#20A99E]">
              Register
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
};
