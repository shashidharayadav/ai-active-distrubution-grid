"""
GRIDMIND AI - Alert & Notification Management Service
Strictly implements the decoupled alert lifecycle:
- ACTIVE: The underlying physical problem is still occurring
- RESOLVED: The underlying grid issue has cleared / been resolved by the operator
- UNREAD: Notification has not been reviewed by the operator
- READ: Operator has explicitly marked the notification as read

Resolving an alert does NOT automatically mark it as read or clear it from notification history.
"""
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
from app.database.repositories.grid_repository import grid_repo
import logging

logger = logging.getLogger("gridmind.services.alerts")


class AlertService:
    def get_all_alerts(self) -> List[Dict[str, Any]]:
        return grid_repo.get_alerts()

    def get_active_alerts(self) -> List[Dict[str, Any]]:
        return grid_repo.get_alerts(status="ACTIVE")

    def get_resolved_alerts(self) -> List[Dict[str, Any]]:
        return grid_repo.get_alerts(status="RESOLVED")

    def get_unread_alerts(self) -> List[Dict[str, Any]]:
        return [a for a in grid_repo.get_alerts() if not a.get("isRead")]

    def get_unread_count(self) -> int:
        return len(self.get_unread_alerts())

    def get_alert_metrics(self) -> Dict[str, int]:
        alerts = grid_repo.get_alerts()
        active = [a for a in alerts if not a["isResolved"]]
        return {
            "total_alerts": len(alerts),
            "active_count": len(active),
            "critical_count": len([a for a in active if a.get("severity") == "critical"]),
            "warning_count": len([a for a in active if a.get("severity") == "warning"]),
            "info_count": len([a for a in active if a.get("severity") == "info"]),
            "unread_count": len([a for a in alerts if not a.get("isRead")]),
            "resolved_count": len([a for a in alerts if a.get("isResolved")]),
            "unacknowledged_count": len([a for a in active if not a.get("isAcknowledged")])
        }

    def resolve_alert(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """
        Resolves the alert problem:
        Sets isResolved = True, adds resolvedAt timestamp.
        Does NOT change isRead (remains unread until operator marks as read).
        """
        return grid_repo.resolve_alert(alert_id)

    def mark_as_read(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """
        Marks notification as read:
        Sets isRead = True, adds readAt timestamp, decrements unread counter.
        Preserves alert in history.
        """
        return grid_repo.mark_alert_as_read(alert_id)

    def mark_all_as_read(self) -> int:
        return grid_repo.mark_all_alerts_read()

    def acknowledge_alert(self, alert_id: str, operator_name: str = "Lead Dispatcher") -> Optional[Dict[str, Any]]:
        return grid_repo.acknowledge_alert(alert_id, operator_name)


# Singleton instance
alert_service = AlertService()
