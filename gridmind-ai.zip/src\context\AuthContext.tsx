import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, role?: User['role']) => boolean;
  register: (name: string, email: string, role?: User['role']) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('gridmind_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    return null;
  });

  const isAuthenticated = !!user;

  useEffect(() => {
    if (user) {
      localStorage.setItem('gridmind_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('gridmind_user');
    }
  }, [user]);

  const login = (email: string, role: User['role'] = 'Grid Dispatcher'): boolean => {
    const defaultName = email.split('@')[0].replace('.', ' ');
    const formattedName = defaultName.charAt(0).toUpperCase() + defaultName.slice(1);
    const newUser: User = {
      id: 'USR-8821',
      name: formattedName || 'Grid Operator',
      email: email || 'operator@gridmind.ai',
      role: role || 'Grid Dispatcher',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    };
    setUser(newUser);
    return true;
  };

  const register = (name: string, email: string, role: User['role'] = 'Grid Dispatcher'): boolean => {
    const newUser: User = {
      id: `USR-${Math.floor(1000 + Math.random() * 9000)}`,
      name: name || 'Operations Dispatcher',
      email: email || 'operator@gridmind.ai',
      role: role || 'Grid Dispatcher',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    };
    setUser(newUser);
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
