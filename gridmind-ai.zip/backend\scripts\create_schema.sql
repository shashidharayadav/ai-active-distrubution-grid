-- =============================================================================
-- GRIDMIND AI — Active Distribution Grid & Demand Prediction System
-- Supabase PostgreSQL Schema Definition
-- Hackathon Theme: BESCOM AI-Driven Active Distribution Grid
-- =============================================================================

-- Enable UUID extension if not already present
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================================
-- 1. SUBSTATIONS
-- =============================================================================
CREATE TABLE IF NOT EXISTS substations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    substation_code VARCHAR(50) UNIQUE NOT NULL,
    substation_name VARCHAR(150) NOT NULL,
    location VARCHAR(200) NOT NULL,
    nominal_voltage_kv NUMERIC(6, 2) NOT NULL DEFAULT 11.0,
    incoming_capacity_kw NUMERIC(10, 2) NOT NULL DEFAULT 10000.0,
    operational_status VARCHAR(50) NOT NULL DEFAULT 'OPERATIONAL', -- OPERATIONAL, MAINTENANCE, DEGRADED, OFFLINE
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 2. FEEDERS
-- =============================================================================
CREATE TABLE IF NOT EXISTS feeders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    feeder_code VARCHAR(50) UNIQUE NOT NULL,
    feeder_name VARCHAR(150) NOT NULL,
    substation_id UUID REFERENCES substations(id) ON DELETE CASCADE,
    locality_name VARCHAR(150),
    rated_capacity_kw NUMERIC(10, 2) NOT NULL DEFAULT 2000.0,
    rated_current_a NUMERIC(8, 2) NOT NULL DEFAULT 120.0,
    nominal_voltage_kv NUMERIC(6, 2) NOT NULL DEFAULT 11.0,
    operational_status VARCHAR(50) NOT NULL DEFAULT 'ONLINE', -- ONLINE, STANDBY, TRIPPED
    breaker_state VARCHAR(20) NOT NULL DEFAULT 'CLOSED', -- CLOSED, OPEN
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 3. TRANSFORMERS
-- =============================================================================
CREATE TABLE IF NOT EXISTS transformers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transformer_code VARCHAR(50) UNIQUE NOT NULL,
    transformer_name VARCHAR(150) NOT NULL,
    feeder_id UUID REFERENCES feeders(id) ON DELETE CASCADE,
    substation_id UUID REFERENCES substations(id) ON DELETE SET NULL,
    rated_capacity_kva NUMERIC(10, 2) NOT NULL DEFAULT 1000.0,
    rated_voltage_kv NUMERIC(6, 2) NOT NULL DEFAULT 11.0,
    cooling_type VARCHAR(20) NOT NULL DEFAULT 'ONAN', -- ONAN, ONAF, OFAF
    tap_position INT NOT NULL DEFAULT 4,
    operational_status VARCHAR(50) NOT NULL DEFAULT 'NORMAL', -- NORMAL, WARNING, CRITICAL, OFFLINE
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 4. LOCALITIES
-- =============================================================================
CREATE TABLE IF NOT EXISTS localities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    locality_code VARCHAR(50) UNIQUE NOT NULL,
    locality_name VARCHAR(150) NOT NULL,
    feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    transformer_id UUID REFERENCES transformers(id) ON DELETE SET NULL,
    consumer_category VARCHAR(50) NOT NULL DEFAULT 'MIXED', -- RESIDENTIAL, COMMERCIAL, INDUSTRIAL, MIXED, HEALTHCARE, TRANSIT
    contracted_demand_kw NUMERIC(10, 2) NOT NULL DEFAULT 1000.0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 5. GRID TELEMETRY (Time-Series Electrical Measurements)
-- =============================================================================
CREATE TABLE IF NOT EXISTS grid_telemetry (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    substation_id UUID REFERENCES substations(id) ON DELETE CASCADE,
    feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    transformer_id UUID REFERENCES transformers(id) ON DELETE SET NULL,
    locality_id UUID REFERENCES localities(id) ON DELETE SET NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    active_power_kw NUMERIC(10, 2) NOT NULL,
    reactive_power_kvar NUMERIC(10, 2) NOT NULL DEFAULT 0.0,
    apparent_power_kva NUMERIC(10, 2) NOT NULL DEFAULT 0.0,
    voltage_kv NUMERIC(6, 3) NOT NULL,
    current_a NUMERIC(8, 2) NOT NULL,
    frequency_hz NUMERIC(5, 2) NOT NULL DEFAULT 50.00,
    power_factor NUMERIC(4, 3) NOT NULL DEFAULT 0.98,
    thd_percent NUMERIC(5, 2) NOT NULL DEFAULT 2.1,
    phase_a_current NUMERIC(8, 2) NOT NULL DEFAULT 0.0,
    phase_b_current NUMERIC(8, 2) NOT NULL DEFAULT 0.0,
    phase_c_current NUMERIC(8, 2) NOT NULL DEFAULT 0.0,
    solar_generation_kw NUMERIC(10, 2) NOT NULL DEFAULT 0.0,
    source_type VARCHAR(50) NOT NULL DEFAULT 'SIMULATED', -- SIMULATED, SCADA_RTU, SMART_METER
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for efficient time-series range queries
CREATE INDEX IF NOT EXISTS idx_telemetry_timestamp ON grid_telemetry (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_feeder ON grid_telemetry (feeder_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_transformer ON grid_telemetry (transformer_id, timestamp DESC);

-- =============================================================================
-- 6. ENERGY READINGS (Cumulative & Interval Consumption kWh)
-- =============================================================================
CREATE TABLE IF NOT EXISTS energy_readings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    transformer_id UUID REFERENCES transformers(id) ON DELETE SET NULL,
    locality_id UUID REFERENCES localities(id) ON DELETE SET NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    energy_kwh NUMERIC(12, 3) NOT NULL, -- Interval energy (kW * hours)
    meter_reading_kwh NUMERIC(14, 3) NOT NULL, -- Cumulative meter index
    reading_type VARCHAR(50) NOT NULL DEFAULT '15_MIN_INTERVAL', -- 15_MIN_INTERVAL, HOURLY, DAILY, MONTHLY
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_energy_timestamp ON energy_readings (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_energy_locality ON energy_readings (locality_id, timestamp DESC);

-- =============================================================================
-- 7. BESS UNITS (Battery Energy Storage System Fleet)
-- =============================================================================
CREATE TABLE IF NOT EXISTS bess_units (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bess_name VARCHAR(150) NOT NULL,
    location VARCHAR(200) NOT NULL,
    capacity_kwh NUMERIC(10, 2) NOT NULL DEFAULT 10000.0, -- 10 MWh = 10,000 kWh
    current_soc_percent NUMERIC(5, 2) NOT NULL DEFAULT 68.4,
    minimum_soc_percent NUMERIC(5, 2) NOT NULL DEFAULT 15.0,
    maximum_soc_percent NUMERIC(5, 2) NOT NULL DEFAULT 95.0,
    maximum_charge_power_kw NUMERIC(8, 2) NOT NULL DEFAULT 2000.0,
    maximum_discharge_power_kw NUMERIC(8, 2) NOT NULL DEFAULT 2000.0,
    charge_efficiency NUMERIC(5, 4) NOT NULL DEFAULT 0.9380, -- 93.8%
    discharge_efficiency NUMERIC(5, 4) NOT NULL DEFAULT 0.9380, -- 93.8%
    state_of_health_percent NUMERIC(5, 2) NOT NULL DEFAULT 99.1,
    operating_mode VARCHAR(50) NOT NULL DEFAULT 'AUTO_AI', -- AUTO_AI, MANUAL_CHARGE, MANUAL_DISCHARGE, STANDBY
    temperature_c NUMERIC(5, 2) NOT NULL DEFAULT 27.4,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 8. BESS EVENTS (Charge / Discharge / Setpoint Logs)
-- =============================================================================
CREATE TABLE IF NOT EXISTS bess_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bess_id UUID REFERENCES bess_units(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL, -- CHARGE, DISCHARGE, STANDBY, SETPOINT_UPDATE
    power_kw NUMERIC(8, 2) NOT NULL, -- Negative for charge, Positive for discharge
    energy_kwh NUMERIC(10, 3) NOT NULL,
    previous_soc NUMERIC(5, 2) NOT NULL,
    updated_soc NUMERIC(5, 2) NOT NULL,
    duration_minutes NUMERIC(8, 2) NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    event_source VARCHAR(100) NOT NULL DEFAULT 'AI_DISPATCHER', -- AI_DISPATCHER, MANUAL_OPERATOR, SCHEDULED
    event_status VARCHAR(50) NOT NULL DEFAULT 'COMPLETED'
);

CREATE INDEX IF NOT EXISTS idx_bess_events_timestamp ON bess_events (timestamp DESC);

-- =============================================================================
-- 9. ALERTS & INCIDENT QUEUE
-- =============================================================================
CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    alert_code VARCHAR(50) UNIQUE NOT NULL,
    alert_type VARCHAR(100) NOT NULL, -- FEEDER_OVERLOAD, TRANSFORMER_OVERHEAT, VOLTAGE_DEVIATION, ANOMALY, etc.
    severity VARCHAR(20) NOT NULL DEFAULT 'warning', -- critical, warning, info
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    substation_id UUID REFERENCES substations(id) ON DELETE SET NULL,
    feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    transformer_id UUID REFERENCES transformers(id) ON DELETE SET NULL,
    locality_id UUID REFERENCES localities(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, RESOLVED
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by VARCHAR(100),
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts (status, is_read);
CREATE INDEX IF NOT EXISTS idx_alerts_detected ON alerts (detected_at DESC);

-- =============================================================================
-- 10. TRANSFER RECOMMENDATIONS (Inter-Feeder Load Balancing)
-- =============================================================================
CREATE TABLE IF NOT EXISTS transfer_recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    destination_feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    source_surplus_kw NUMERIC(10, 2) NOT NULL,
    destination_deficit_kw NUMERIC(10, 2) NOT NULL,
    recommended_transfer_kw NUMERIC(10, 2) NOT NULL,
    estimated_losses_kw NUMERIC(8, 2) NOT NULL DEFAULT 0.0,
    estimated_delivered_power_kw NUMERIC(10, 2) NOT NULL,
    route VARCHAR(300) NOT NULL,
    constraint_status VARCHAR(50) NOT NULL DEFAULT 'ALL_CONSTRAINTS_SATISFIED',
    operator_status VARCHAR(50) NOT NULL DEFAULT 'PENDING_APPROVAL', -- PENDING_APPROVAL, APPROVED, TRANSFER_INITIATED, ACTIVE_TRANSFER, COMPLETED, REJECTED
    deficit_resolution_status VARCHAR(50) NOT NULL DEFAULT 'PARTIALLY_RESOLVED', -- FULLY_RESOLVED, PARTIALLY_RESOLVED, UNRESOLVED
    approved_by VARCHAR(100),
    approved_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 11. GRID TOPOLOGY (Graph Nodes & Edges)
-- =============================================================================
CREATE TABLE IF NOT EXISTS grid_topology (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    from_node VARCHAR(100) NOT NULL,
    to_node VARCHAR(100) NOT NULL,
    connection_type VARCHAR(50) NOT NULL DEFAULT 'DISTRIBUTION_LINE', -- DISTRIBUTION_LINE, BREAKER, TIE_SWITCH, TRANSFORMER_LINK
    equipment_code VARCHAR(100) NOT NULL,
    operational_status VARCHAR(50) NOT NULL DEFAULT 'ONLINE',
    rated_capacity_kw NUMERIC(10, 2) NOT NULL DEFAULT 2000.0,
    resistance_ohm NUMERIC(8, 4) NOT NULL DEFAULT 0.1500,
    length_km NUMERIC(6, 2) NOT NULL DEFAULT 1.2,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================================================
-- 12. DEMAND PREDICTIONS (Random Forest Forecasts)
-- =============================================================================
CREATE TABLE IF NOT EXISTS demand_predictions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    feeder_id UUID REFERENCES feeders(id) ON DELETE SET NULL,
    locality_id UUID REFERENCES localities(id) ON DELETE SET NULL,
    prediction_timestamp TIMESTAMPTZ NOT NULL,
    forecast_horizon VARCHAR(20) NOT NULL DEFAULT '+30M', -- +15M, +30M, +1H, +2H, +6H, +24H
    predicted_demand_kw NUMERIC(10, 2) NOT NULL,
    actual_demand_kw NUMERIC(10, 2),
    absolute_error_kw NUMERIC(8, 2),
    percentage_error NUMERIC(5, 2),
    confidence_lower_kw NUMERIC(10, 2),
    confidence_upper_kw NUMERIC(10, 2),
    model_version VARCHAR(50) NOT NULL DEFAULT 'RF_V2.4',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_predictions_timestamp ON demand_predictions (prediction_timestamp DESC);

-- =============================================================================
-- 13. SIMULATION HISTORY (What-If Sandbox Scenarios)
-- =============================================================================
CREATE TABLE IF NOT EXISTS simulation_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id VARCHAR(100),
    scenario_name VARCHAR(150) NOT NULL,
    input_parameters JSONB NOT NULL,
    output_results JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_simulation_history_created ON simulation_history (created_at DESC);
